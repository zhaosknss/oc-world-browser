"""结算层：简单动作由规则结算，复杂行动用批次结果按序应用。

世界事实与角色获知分开：
- event 记录「发生了什么」（世界事实），带 witnesses（本次结算的感知范围）；
- observation 记录「某个角色知道了什么」，带来源类型、来源事件、来源人物。
一条消息的发送是事实；消息里的说法以 reliable=0 的观察记入收件人，不并入世界事实。
公开说出的话（`settle_speak(..., public=True)`，只有场景里显式打开 story_loop 的包会用）
同地点的在场者都听得到；听到的仍然是「某人对某人说了什么」这句说法，不是已证实的事实。
"""
from __future__ import annotations

from .models import ProviderSchemaError


def co_located(staging: dict, location_id: str, exclude: str | None = None) -> list[str]:
    return sorted(
        cid for cid, ch in staging["characters"].items()
        if ch["location_id"] == location_id and cid != exclude
    )


def _event(tick: int, seq: int, kind: str, text: str, *, success: bool = True,
           reason: str = "", actor_id: str | None = None, target_id: str | None = None,
           location_id: str | None = None, witnesses: list[str] | None = None,
           external_event_id: int | None = None, observations: list[dict] | None = None) -> dict:
    return {
        "tick": tick, "seq": seq, "kind": kind, "actor_id": actor_id, "target_id": target_id,
        "location_id": location_id, "text": text, "success": bool(success), "reason": reason,
        "witnesses": sorted(set(witnesses or [])), "external_event_id": external_event_id,
        "observations": observations or [],
    }


def _obs(owner_id: str, tick: int, content: str, source_type: str, *,
         source_actor_id: str | None = None, first_hand: bool = True,
         reliable: bool = True) -> dict:
    return {
        "owner_id": owner_id, "tick": tick, "content": content, "source_type": source_type,
        "source_actor_id": source_actor_id, "first_hand": 1 if first_hand else 0,
        "reliable": 1 if reliable else 0,
    }


def apply_event(staging: dict, event: dict) -> None:
    """把一条已结算事件写入暂存世界，并分发观察。"""
    staging["new_events"].append(event)
    for ob in event["observations"]:
        # 观察记住来源事件本身，供下一轮构造上下文时按角色范围取用。
        ob["source_event"] = {
            "event_id": event.get("event_id"),
            "tick": event["tick"],
            "kind": event["kind"],
            "actor_id": event["actor_id"],
            "text": event["text"],
            "witnesses": list(event["witnesses"]),
        }
        staging["observations"].setdefault(ob["owner_id"], []).append(ob)


def check_requires(staging: dict, clauses: list[dict]) -> list[str]:
    """按当时的暂存状态复核前置条件，返回不成立的说明（空列表表示全部成立）。"""
    failures: list[str] = []
    for clause in clauses:
        if clause["type"] == "resource_state":
            resource = staging["resources"].get(clause["resource_id"])
            if resource is None:
                failures.append(f"资源 {clause['resource_id']} 不存在")
                continue
            if "holder_id" in clause and resource["holder_id"] != clause["holder_id"]:
                holder = resource["holder_id"]
                if clause["holder_id"] is None and holder is not None:
                    failures.append(
                        f"{resource['name']}已经被"
                        f"{staging['characters'].get(holder, {}).get('name', holder)}取走")
                else:
                    failures.append(f"{resource['name']}的持有状态与预期不符")
            if "location_id" in clause and resource["location_id"] != clause["location_id"]:
                failures.append(f"{resource['name']}已不在预期地点")
        elif clause["type"] == "location_state":
            location = staging["locations"].get(clause["location_id"])
            if location is None:
                failures.append(f"地点 {clause['location_id']} 不存在")
            elif location["state_description"] != clause["equals"]:
                failures.append(
                    f"{location['name']}的现场状态已不是「{clause['equals']}」")
    return failures


def check_resource_actions(staging: dict, actions: list[dict], actor_id: str) -> list[str]:
    """只读复核结构化资源动作，返回不成立的说明。

    资源语义由引擎在这里保证，不依赖模型声明的 patch：唯一物件只有在
    「未被取走且就在本人所在地点」时才可能被取走，因此同一 tick 里第二个
    取得动作一定失败，不会覆盖前一个成功。同一批内的先后动作按顺序叠加。
    """
    actor = staging["characters"][actor_id]
    failures: list[str] = []
    holder: dict[str, str | None] = {}
    place: dict[str, str | None] = {}
    for item in actions:
        rid = item["resource_id"]
        resource = staging["resources"][rid]
        cur_holder = holder[rid] if rid in holder else resource["holder_id"]
        cur_place = place[rid] if rid in place else resource["location_id"]
        if item["action"] == "take":
            if cur_holder is not None:
                name = staging["characters"].get(cur_holder, {}).get("name", cur_holder)
                failures.append(f"{resource['name']}已经被{name}取走")
                continue
            if cur_place != actor["location_id"]:
                failures.append(f"{resource['name']}不在{actor['name']}所在的地点")
                continue
            holder[rid] = actor_id
            place[rid] = None
        else:  # drop
            if cur_holder != actor_id:
                failures.append(f"{actor['name']}手里并没有{resource['name']}")
                continue
            holder[rid] = None
            place[rid] = actor["location_id"]
    return failures


def apply_resource_actions(staging: dict, actions: list[dict], actor_id: str,
                           tick: int) -> list[str]:
    """应用已经通过复核的资源动作；返回可展示的变化说明。"""
    actor = staging["characters"][actor_id]
    notes: list[str] = []
    for item in actions:
        resource = staging["resources"][item["resource_id"]]
        if item["action"] == "take":
            resource["holder_id"] = actor_id
            resource["location_id"] = None
            notes.append(f"{actor['name']}取走了{resource['name']}")
        else:
            resource["holder_id"] = None
            resource["location_id"] = actor["location_id"]
            notes.append(f"{actor['name']}放下了{resource['name']}")
        resource["updated_tick"] = tick
    return notes


def settle_wait(staging: dict, intent: dict, tick: int, seq: int) -> dict:
    actor = staging["characters"][intent["actor_id"]]
    return _event(tick, seq, "wait", f"{actor['name']}按兵不动，只是留神听着周围的动静。",
                  reason="本轮没有采取行动", actor_id=actor["id"],
                  location_id=actor["location_id"])


def settle_move(staging: dict, intent: dict, tick: int, seq: int) -> dict:
    actor = staging["characters"][intent["actor_id"]]
    actor_id = actor["id"]
    origin = staging["locations"][actor["location_id"]]
    dest_id = intent["target"]
    dest = staging["locations"][dest_id]
    if dest_id not in origin["connections"]:
        reason = f"移动失败：{origin['name']}无法直接前往{dest['name']}，条件不成立"
        # 世界内失败也是一次真实经历：给本人留一条带原因的观察，他下一轮才会知道
        # 这次没去成、当时为什么没去成。感知范围就是他自己（别人并没有看到他离开）。
        return _event(
            tick, seq, "move",
            f"{actor['name']}想立刻前往{dest['name']}，但{dest['name']}并不相连。",
            success=False, reason=reason,
            actor_id=actor_id, target_id=dest_id, location_id=origin["id"],
            witnesses=[actor_id],
            observations=[_obs(actor_id, tick,
                               f"我想前往{dest['name']}，但没有去成：{origin['name']}"
                               f"无法直接前往{dest['name']}。", "direct")])
    origin_present = co_located(staging, origin["id"])
    dest_present = co_located(staging, dest_id)
    witnesses = sorted(set(origin_present) | set(dest_present) | {actor_id})
    observations = [_obs(actor_id, tick, f"我离开{origin['name']}，来到{dest['name']}。", "direct")]
    for other in origin_present:
        observations.append(_obs(
            other, tick, f"{actor['name']}离开了{origin['name']}，往{dest['name']}去了。", "direct"))
    for other in dest_present:
        observations.append(_obs(
            other, tick, f"{actor['name']}从{origin['name']}来到{dest['name']}。", "direct"))
    actor["location_id"] = dest_id
    return _event(tick, seq, "move", f"{actor['name']}从{origin['name']}前往{dest['name']}。",
                  reason="已抵达", actor_id=actor_id, target_id=dest_id, location_id=dest_id,
                  witnesses=witnesses, observations=observations)


def settle_speak(staging: dict, intent: dict, tick: int, seq: int,
                 public: bool = False) -> dict:
    """一次说话。`public=True` 表示这是一句**公开说出**的话（新三人包启用）。

    两种模式的差别只在**谁能得到观察**，不在事实语义：

    - 默认（旧路径）：只有说话者与指定收件人得到观察，同场的第三人听不见；
    - public：结算当时**同地点的所有人**都得到一条观察，因此同刻后行动的人
      可以在自己的决策输入里读到；说话者与指定收件人的那两条保持不变。

    无论哪种模式，听到的都只是「某人对某人说了什么」——内容是**说法**，不是世界事实：
    收件人那条是 reliable=0 的转述，旁听者是本人亲耳听到（first_hand=1）但同样
    reliable=0。个人 state、未被感知的事件与世界回合的规划都不因此公开。
    跨地点说话仍然失败，话不投递给远方的收件人，也不给同场旁人（当时确实没人听见）。
    """
    actor = staging["characters"][intent["actor_id"]]
    target = staging["characters"][intent["target"]]
    message = intent["text"]
    if target["location_id"] != actor["location_id"]:
        here = staging["locations"][actor["location_id"]]["name"]
        # 话没送出去也是一次真实经历：本人留下带原因的观察（目标并不在场，听不到，
        # 所以不进他的认知）；他下一轮能看出「上次那句话没送到」。
        return _event(
            tick, seq, "speak",
            f"{actor['name']}想对{target['name']}说话，但{target['name']}不在{here}。",
            success=False,
            reason=f"说话失败：{target['name']}不在同一地点，话没有送到",
            actor_id=actor["id"], target_id=target["id"], location_id=actor["location_id"],
            witnesses=[actor["id"]],
            observations=[_obs(actor["id"], tick,
                               f"我想对{target['name']}说「{message}」，但{target['name']}"
                               f"不在{here}，话没有送到。", "direct")])
    observations = [
        # 收到消息：内容本身是说法，不是已证实的世界事实。
        _obs(target["id"], tick, message, "message", source_actor_id=actor["id"],
             first_hand=False, reliable=False),
        _obs(actor["id"], tick, f"我告诉{target['name']}：「{message}」", "direct"),
    ]
    witnesses = [actor["id"], target["id"]]
    if public:
        here = staging.get("locations", {}).get(actor["location_id"], {}).get("name", "这里")
        for other in co_located(staging, actor["location_id"]):
            if other in witnesses:
                continue
            witnesses.append(other)
            # 本人亲耳听到这句话，但听到的内容仍然是说话者的说法（reliable=0），
            # 不因为多人在场就变成已证实的世界事实。
            observations.append(_obs(
                other, tick, f"{actor['name']}对{target['name']}说：「{message}」",
                "message", source_actor_id=actor["id"], first_hand=True, reliable=False))
        if len(witnesses) > 2:
            reason = f"消息已送达（{here}在场的人都听到了）"
        else:
            reason = "消息已送达"
    else:
        reason = "消息已送达"
    return _event(tick, seq, "speak", f"{actor['name']}对{target['name']}说：「{message}」",
                  reason=reason, actor_id=actor["id"], target_id=target["id"],
                  location_id=actor["location_id"],
                  witnesses=witnesses, observations=observations)


def settle_complex(staging: dict, intent: dict, result: dict, tick: int, seq: int,
                   intent_location: str) -> dict:
    """应用一次批次结算结果。

    应用前按当时的暂存状态复核三件事：
    1. 行动者是否仍在提出意图时的地点；
    2. 结算声明的观察范围是否仍在现场；
    3. 结算声明的显式前置条件（资源状态 / 地点状态）是否仍成立。
    任一条不成立都记为带原因的世界内失败。资源语义另由引擎保证（见
    apply_resource_actions），任何 patch 都绕不过这一层检查。

    失败结算必须无副作用：success=false 时不应用资源动作、角色变更与地点变更，
    只留下失败原因与世界内失败事件。矛盾输出（失败却带变更）在校验层
    （models.validate_settlement）已被拒绝；这里再兜一层，保证执行路径本身
    不会把变更写进失败结果。

    三类复核不通过都会给行动者留下一条带原因的失败观察，让他下一轮知道自己
    这次没成——否则失败只在事件日志里，角色自己的认知会与事实脱节。
    """
    actor = staging["characters"][intent["actor_id"]]
    actor_id = actor["id"]

    def failure(text: str, reason: str, location: str) -> dict:
        return _event(
            tick, seq, "act", text, success=False, reason=reason, actor_id=actor_id,
            location_id=location,
            observations=[_obs(actor_id, tick,
                               f"我{intent['target']}，但没有成功：{reason}", "direct")])

    if actor["location_id"] != intent_location:
        return failure(
            f"{actor['name']}打算{intent['target']}，但前面的结算已经改变了现场。",
            "行动条件不成立：提出意图之后，本人已不在原地点，动作无法按原条件执行",
            actor["location_id"])

    allowed_now = set(co_located(staging, actor["location_id"])) | {actor_id}
    stale = sorted(set(result["witnesses"]) - allowed_now)
    if stale:
        return failure(
            f"{actor['name']}打算{intent['target']}，但现场已经变化。",
            f"行动条件不成立：结算给出的观察范围已不在现场 {stale}",
            actor["location_id"])

    broken = check_requires(staging, result["requires"])
    broken += check_resource_actions(staging, result["resource_actions"], actor_id)
    if broken:
        return failure(
            f"{actor['name']}打算{intent['target']}，但条件已经不成立。",
            "行动条件不成立：" + "；".join(broken),
            actor["location_id"])

    if result["success"]:
        resource_notes = apply_resource_actions(staging, result["resource_actions"],
                                               actor_id, tick)
    else:
        # 执行层的兜底复核：正常路径上矛盾输出已在校验层被拒。
        conflicts = [key for key, value in
                     (("resource_actions", result["resource_actions"]),
                      ("actor_changes", result["actor_changes"]),
                      ("location_changes", result["location_changes"])) if value]
        if conflicts:
            raise ProviderSchemaError(
                "结算声明失败却附带变更：" + "、".join(conflicts))
        resource_notes = []

    text = result["fact_text"].replace("{name}", actor["name"])
    if not result["success"]:
        text = f"{actor['name']}尝试{intent['target']}，但没有成功。"
    observations = []
    if result["success"]:
        for witness in result["witnesses"]:
            content = (f"我{intent['target']}，完成了。"
                       if witness == actor_id else text)
            observations.append(_obs(witness, tick, content, "direct"))
    else:
        observations.append(_obs(actor_id, tick, f"我{intent['target']}，但没有成功：{result['reason']}",
                                 "direct"))

    if result["success"]:
        # 只有成功的结算才改动世界状态；失败结果只保留原因与失败事件。
        for key, value in result["actor_changes"].items():
            actor[key] = value
        location = staging["locations"][result["target_location"]]
        for key, value in result["location_changes"].items():
            location[key] = value

    # 资源动作造成的可见变化写成直接观察，避免"拿走了钥匙"只留在世界状态里。
    # 事件正文已经说明过的变化不重复写（避免同一条认知出现两次）。
    if result["success"] and resource_notes:
        for witness in result["witnesses"]:
            if witness == actor_id:
                continue
            known = {ob["content"] for ob in observations if ob["owner_id"] == witness}
            for note in resource_notes:
                line = f"{note}。"
                if line in known:
                    continue
                observations.append(_obs(witness, tick, line, "direct"))

    return _event(tick, seq, "act", text, success=result["success"],
                  reason=result["reason"], actor_id=actor_id,
                  target_id=result["target_location"], location_id=result["target_location"],
                  witnesses=result["witnesses"], observations=observations)


def settle_external(staging: dict, ext: dict, payload: dict, tick: int, seq: int,
                    witnesses: list[str]) -> dict:
    """外部事件按范围在暂存世界生效，并只给范围内的角色生成观察。"""
    description = ext["description"]
    claim = payload.get("claim")
    observations = []
    if claim:
        for owner in witnesses:
            observations.append(_obs(owner, tick, claim, "message",
                                     source_actor_id=payload.get("claim_source_actor"),
                                     first_hand=False, reliable=False))
    elif payload.get("direct_observation", True):
        for owner in witnesses:
            observations.append(_obs(owner, tick, description, "direct"))
    for loc_id, changes in (payload.get("location_changes") or {}).items():
        location = staging["locations"].get(loc_id)
        if location is not None:
            for key, value in changes.items():
                if key in ("state_description", "moment"):
                    location[key] = value
    text = description if not claim else f"{description}（其中的说法：{claim}）"
    return _event(tick, seq, "external", text, reason="外部事件按范围生效",
                  location_id=None, witnesses=witnesses,
                  external_event_id=ext["event_id"], observations=observations)
