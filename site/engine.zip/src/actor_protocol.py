"""Validate a whole actor response before actions run; repair structure once.

The caller still validates each intention against the live world when executing
it. This module neither executes actions nor reads world state or provider config.
"""
from __future__ import annotations

from copy import deepcopy

from . import chapter_protocol as protocol
from . import notes
from .models import ProviderInvalidOutput, ProviderSchemaError, validate_intent


def _actor_output(raw, actor_id: str, character_ids: set[str],
                  location_ids: set[str]) -> tuple[list[dict], dict]:
    if not isinstance(raw, dict):
        raise ProviderSchemaError("人物返回必须是一个对象，包含 actions 和可选 state")
    actions = raw.get("actions")
    if not isinstance(actions, list) or not 1 <= len(actions) <= 6:
        raise ProviderSchemaError("人物表演 actions 需要一组 1–6 个连续动作")
    state = raw.get("state")
    if state is None:
        state = {}
    if not isinstance(state, dict):
        raise ProviderSchemaError("人物 state 必须是对象")
    note = deepcopy(state)
    if "clear_state" in raw:
        note["clear"] = deepcopy(raw["clear_state"])
    try:
        update, _ = notes.normalize(note)
    except ValueError as exc:
        raise ProviderSchemaError(f"人物 state 不合法：{exc}") from exc

    checked = deepcopy(actions)
    for index, action in enumerate(checked):
        try:
            if not isinstance(action, dict):
                raise ProviderSchemaError("意图必须是对象")
            # Guard types before validators use membership/default operations.
            if not isinstance(action.get("action"), str):
                raise ProviderSchemaError("action 必须是 move、speak、act 或 wait 字符串")
            if action.get("tone") is not None and not isinstance(action["tone"], str):
                raise ProviderSchemaError("tone 必须是字符串")
            if (action["action"] == "act" and not action.get("target")
                    and isinstance(action.get("text"), str) and action["text"].strip()):
                action["target"] = action["text"]
            # Only validate references/shape here. A -> B -> A is valid although
            # A equals the position before the batch; live checks remain required.
            validate_intent(action, actor_id, character_ids, location_ids, {})
        except ProviderSchemaError as exc:
            raise ProviderSchemaError(f"actions[{index}] 不合法：{exc}") from exc
    return checked, update


def actor_result(provider, context: dict, lease, call_fn, *, actor_id: str,
                 tick: int, character_ids: set[str], location_ids: set[str]) -> tuple[list[dict], dict]:
    """Return the complete actions and one normalized private state update.

    ``call_fn`` has the signature of chapters.call and returns parsed JSON. Only
    malformed JSON with its original content, or parsed schema/reference errors,
    get one directed correction. Transport/empty/truncation/lease failures pass
    through. No action from either response has run when this function returns.
    """
    original = deepcopy(context)
    correction = None
    for attempt in range(2):
        payload = deepcopy(original)
        if correction is not None:
            invalid, reason = correction
            payload["invalid_proposal"] = deepcopy(invalid)
            payload["correction_notes"] = (
                reason + "。保持原返回的同一行动意图、对象、次序和个人状态内容，"
                "只修正 JSON、字段、引用或状态格式；不重演、不换新选择、"
                "不宣称动作已经执行。返回一个包含完整 actions 与可选 state、"
                "clear_state 的 JSON 对象。"
            )
        try:
            raw = call_fn(provider, "actor_perform", protocol.ACTOR, payload,
                          lease, tick=tick, actor_id=actor_id)
        except ProviderInvalidOutput as exc:
            invalid = getattr(exc, "invalid_content", None)
            if attempt or not isinstance(invalid, str) or not invalid.strip():
                raise
            correction = (invalid, "上一返回不是可解析的 JSON 对象")
            continue
        try:
            return _actor_output(raw, actor_id, character_ids, location_ids)
        except ProviderSchemaError as exc:
            if attempt:
                raise
            correction = (deepcopy(raw), str(exc))
    raise AssertionError("actor correction exhausted without a result")
