"""受限上下文构建。

角色输入通过受限数据对象构建：本人设定/状态、公开环境、本人观察、本人个人状态与
可检索记忆。不把完整世界对象交给模板再靠提示词隐藏。

来源检索同样按角色范围过滤：观察可以带上来源事件，但只有当本人是那件事件的
感知者时才给出描述；否则只说明「你没有直接感知到这件事」，不给正文。
感知判定与引擎完全一致（src/engine.py::_visibility_note）：witnesses 为空列表
表示**无人感知**，不是「所有人都能感知」。无权感知时只保留协议允许的最小来源
信息——事件引用与类别；正文、事件中的人物身份与发生时间都不进入上下文。
「谁告诉过我」是另一回事：观察自身的 source_actor_id 属于本人已知的转告者，可以保留。

记忆取回分两段（都是本人记录，不引入向量检索或在线服务）：

1. 近期观察：最近若干条（`RECENT_WINDOW`，可用场景 `demo.recent_memory_limit` 调整）；
2. 相关回忆：近期窗口之外的本人记录里，与**当前处境**（在场的人、所在地点、
   看得见的物品）或**本人写下的在意的事与目标**有关的那几条，按相关度取前若干条。
   每条都带上它属于直接经历、听来的说法还是自己的推测。

本人的尝试结果另走 `my_attempts`：那是 event 表里本人真正做过、已经结算过的事
（含没做成的和当时的原因），不靠角色自己回忆，也不受近期窗口限制。
"""
from __future__ import annotations

import json
import re

MEMORY_LIMIT = 6        # 显式传入 memory_limit 时的默认窗口（兼容旧调用）
RECENT_WINDOW = 12      # 近期观察窗口：完整事件仍在 event 表，不做摘要压缩
CLAIM_LIMIT = 20        # 收到的消息/转告作为持久认知保留（首版上限，不做摘要压缩）
RECALL_LIMIT = 6        # 较早但相关的本人经历，最多带回几条
RECALL_MIN_SCORE = 3    # 相关度下限：低于它不进「相关回忆」
ATTEMPT_LIMIT = 8       # 本人已结算尝试最多带回几条
KEYWORD_LIMIT = 40      # 从本人写下的话里最多取几个词，避免上下文膨胀

SOURCE_LABELS = {
    "direct": "本人直接经历",
    "message": "收到说法（可能是转述或传言）",
    "inference": "本人推测",
}
UNRELIABLE_NOTE = "这只是别人或别处传来的说法，不等于世界事实；不要把它当成已经发生的事实。"
MUTED_SOURCE = "你没有直接感知到这件事，只知道有这么一条说法。"

# 个人状态的语义说明：写进上下文，避免模型把自己的主观判断当成世界真相。
STATE_NOTE = (
    "这四项是你自己写下的，不是世界事实，也不保证正确；空字符串表示你还没写下这一项。"
    "focus=你此刻在意的事或短期打算（还没做，不等于已经做成）；"
    "situation=你对当前处境的判断（可能看错）；"
    "lessons=你试过什么、什么有用什么没用；pending=你还没做完的事。"
    "它是你自己的想法，别人并不知道。"
)
# 情境线索：运行包给这个人的一小段「利益受损时可能做什么、什么条件下可以让步」。
# 它是**选择空间**，不是每刻必做的清单，也不是世界事实。
CUES_NOTE = (
    "这是你自己的处境线索：利益受损时你可能试什么、什么情况会让你让步或愿意搭手、"
    "说话是什么路数。它只是几种可能的走向，不是每刻都要照做一遍；"
    "当下怎么做仍然看你自己的处境与知道的事。"
)
RECALL_NOTE = (
    "从你自己的记录里取回的、与当前处境有关的过往（不含本刻的近期观察）。"
    "source_label 说明每一条是本人直接经历、听到的说法，还是你自己的推测；"
    "说法与推测都可能与事实不符。"
)
ATTEMPT_NOTE = (
    "你自己做过、已经结算过的事，按时间顺序；success=false 表示这件事没做成，"
    "reason 是当时为什么没成。这是已经发生过的结果，下次打算可以先看它。"
)

_HAN_RUN = re.compile(r"[\u4e00-\u9fff]{2,}")


def public_character(ch: dict) -> dict:
    """同地点在场者只暴露公开信息：姓名与描述。"""
    return {"id": ch["id"], "name": ch["name"], "description": ch["description"]}


def recent_window(staging: dict) -> int:
    """近期观察窗口：短篇演示可以放宽，用场景里的 demo.recent_memory_limit 声明。"""
    demo = (staging.get("scenario") or {}).get("demo") or {}
    try:
        value = int(demo.get("recent_memory_limit"))
    except (TypeError, ValueError):
        return RECENT_WINDOW
    return value if value > 0 else RECENT_WINDOW


def _observation_view(ob: dict, owner_id: str, staging: dict) -> dict:
    view = {
        "tick": ob["tick"],
        "content": ob["content"],
        "source_type": ob["source_type"],
        "source_label": SOURCE_LABELS.get(ob["source_type"], ob["source_type"]),
        "source_actor_id": ob.get("source_actor_id"),
        "source_actor_name": _character_name(staging, ob.get("source_actor_id")),
        "first_hand": bool(ob.get("first_hand", 1)),
        "reliable": bool(ob.get("reliable", 1)),
        "source_event_id": ob.get("source_event_id"),
        "source_event": _source_event_view(ob, owner_id, staging),
    }
    if not view["reliable"]:
        view["claim_note"] = UNRELIABLE_NOTE
    return view


def _source_event_view(ob: dict, owner_id: str, staging: dict) -> dict | None:
    """按本人是否感知过滤来源事件。

    有权感知：给出事件时间、人物与正文。
    无权感知：只保留事件引用（event_id）与类别（kind）这类协议允许的最小字段，
    正文置空、人物身份与事件时间不出现，并附上「只知道有这么一条说法」的说明。
    空 witness 列表按引擎语义处理为「无人感知」。
    """
    event = ob.get("source_event")
    if event is None:
        event_id = ob.get("source_event_id")
        if event_id is None:
            return None
        event = staging.get("event_index", {}).get(event_id)
        if event is None:
            return None
    view = {"event_id": event.get("event_id"), "kind": event.get("kind")}
    if owner_id in (event.get("witnesses") or []):
        view["tick"] = event.get("tick")
        view["actor_id"] = event.get("actor_id")
        view["actor_name"] = _character_name(staging, event.get("actor_id"))
        view["text"] = event.get("text")
    else:
        view["text"] = None
        view["note"] = MUTED_SOURCE
    return view


def _character_name(staging: dict, actor_id) -> str | None:
    if not actor_id:
        return None
    return staging["characters"].get(actor_id, {}).get("name", actor_id)


def _world_view(staging: dict) -> dict:
    """世界共同背景（公开）。

    展示用的运行包把「这是什么地方、三人为什么在这儿」写在世界总述里；
    没有这一段，角色决策只能看到自己与所在地，容易把三人写成互不相干的单人戏。
    这里只给标题、公开描述与**用语约定**（例如称呼直接用名字），
    不给任何人的目标、倾向或私密标记。
    """
    from . import demo as demo_mod          # 局部导入：避免模块级循环依赖
    scenario = staging.get("scenario") or {}
    world = scenario.get("world") or {}
    return {"title": scenario.get("title", ""),
            "background": world.get("description", ""),
            "conventions": demo_mod.conventions_for(scenario)}


def _visible_resources(staging: dict, actor_id: str, location_id: str) -> list[dict]:
    """本人在场且未被取走的资源；别人身上的东西不进上下文。"""
    out = []
    for resource in staging["resources"].values():
        if resource["location_id"] != location_id or resource["holder_id"] is not None:
            continue
        out.append({"id": resource["id"], "name": resource["name"],
                    "description": resource["description"]})
    out.sort(key=lambda item: item["id"])
    return out


def _carried_resources(staging: dict, actor_id: str) -> list[dict]:
    return sorted(
        ({"id": r["id"], "name": r["name"], "description": r["description"]}
         for r in staging["resources"].values() if r["holder_id"] == actor_id),
        key=lambda item: item["id"])


# --------------------------------------------------------------- 取回相关回忆


def _keywords(text: str) -> list[str]:
    """从本人写下的话里取词：先取连续汉字串，再补 2、3 字片段。

    这是刻意保持轻量的做法：不引入分词依赖，也不做向量检索。取回是「按相关度
    打分排序取前几条」，不是精确匹配，所以 2 字片段带来的噪声由打分与条数上限吸收。
    长词排前面，只保留前 KEYWORD_LIMIT 个，避免上下文膨胀。
    """
    found: set[str] = set()
    for run in _HAN_RUN.findall(text or ""):
        if len(run) <= 4:
            found.add(run)
        for size in (2, 3):
            for index in range(0, len(run) - size + 1):
                found.add(run[index:index + size])
    return sorted(found, key=lambda item: (-len(item), item))[:KEYWORD_LIMIT]


def _situation(staging: dict, actor_id: str, state: dict | None) -> tuple[dict, list[str]]:
    """当前处境里可被指名的东西 → 相关性说明；以及本人关切里的关键词。

    只看本人看得见的东西（同地点在场者、所在地点、看得见的物品），
    以及本人写下的在意的事、没做完的事与稳定目标——不读别人的记录。
    """
    me = staging["characters"][actor_id]
    loc = staging["locations"][me["location_id"]]
    reasons: dict[str, str] = {loc["name"]: f"与你此刻所在的{loc['name']}有关"}
    for other in staging["characters"].values():
        if other["id"] == actor_id or other["location_id"] != me["location_id"]:
            continue
        reasons[other["name"]] = f"与此刻在{loc['name']}的{other['name']}有关"
    for resource in staging["resources"].values():
        if resource["holder_id"] == actor_id or resource["location_id"] == me["location_id"]:
            reasons[resource["name"]] = f"与{resource['name']}有关"
    texts = [str((state or {}).get(key) or "") for key in
             ("focus", "situation", "lessons", "pending")]
    texts.extend(str(goal) for goal in me.get("goals") or [])
    keywords: list[str] = []
    for text in texts:
        for word in _keywords(text):
            if word not in keywords:
                keywords.append(word)
    return reasons, keywords


def _score_observation(ob: dict, reasons: dict, keywords: list[str]) -> tuple[int, list[str]]:
    """给一条旧记录打分并说明为什么被取回。"""
    content = str(ob.get("content") or "")
    if not content:
        return 0, []
    hits: list[str] = []
    score = 0
    for term, reason in reasons.items():
        if term and term in content:
            score += 3
            if reason not in hits:
                hits.append(reason)
    matched = [word for word in keywords if word in content]
    if matched:
        score += min(len(matched), 3)
        top = "、".join(sorted(matched, key=lambda item: (-len(item), item))[:2])
        hits.append(f"与你写下的事有关（{top}）")
    return score, hits


def recall_view(staging: dict, actor_id: str, recent_count: int,
                limit: int = RECALL_LIMIT) -> list[dict]:
    """近期窗口之外、与当前处境有关的本人记录，按相关度取前若干条。

    只在本人的观察里找（owner_id 必须是本人），因此别人的私有记录不会混进来；
    近期窗口里的内容不在这里重复出现。
    """
    own = list(staging.get("observations", {}).get(actor_id) or [])
    if recent_count > 0:
        older = own[:-recent_count]
    else:
        older = own
    if not older:
        return []
    state = (staging.get("notes") or {}).get(actor_id) or {}
    reasons, keywords = _situation(staging, actor_id, state)
    if not reasons and not keywords:
        return []
    scored: list[tuple[int, int, dict, list[str]]] = []
    for ob in older:
        score, hits = _score_observation(ob, reasons, keywords)
        if score >= RECALL_MIN_SCORE and hits:
            scored.append((score, int(ob["tick"]), ob, hits))
    # 先按相关度，再按时间近的优先；同一条记录只出现一次。
    scored.sort(key=lambda item: (-item[0], -item[1]))
    out: list[dict] = []
    for _score, _tick, ob, hits in scored[:limit]:
        view = _observation_view(ob, actor_id, staging)
        view["recall_reason"] = "；".join(hits)
        out.append(view)
    out.sort(key=lambda item: item["tick"])
    return out


ATTEMPT_KINDS = {"act": "行动", "speak": "对话", "move": "移动"}


def attempts_view(staging: dict, actor_id: str, limit: int = ATTEMPT_LIMIT) -> list[dict]:
    """本人做过并已结算的事，含没做成的与当时的原因。

    取自已结算事件（本人是行动者），而不是本次的近期观察窗口：一条早先失败的
    尝试，即使已经滚出窗口，也仍然是角色自己的经历。
    """
    events = (staging.get("own_events") or {}).get(actor_id) or []
    out: list[dict] = []
    for ev in events[-limit:] if limit > 0 else events:
        out.append({
            "tick": ev["tick"],
            "kind": ATTEMPT_KINDS.get(ev["kind"], ev["kind"]),
            "what_happened": ev["text"],
            "success": bool(ev["success"]),
            "reason": (ev.get("reason") or "").strip() or None,
        })
    return out


def build_context(staging: dict, actor_id: str, memory_limit: int | None = None) -> dict:
    me = staging["characters"][actor_id]
    loc = staging["locations"][me["location_id"]]
    presenter = [
        public_character(other)
        for other in staging["characters"].values()
        if other["location_id"] == me["location_id"] and other["id"] != actor_id
    ]
    presenter.sort(key=lambda item: item["id"])
    own = list(staging["observations"].get(actor_id, []))
    window = recent_window(staging) if memory_limit is None else int(memory_limit)
    observations = own[-window:] if window > 0 else own
    # 收到的消息与转告属于持久认知：世界事实不变，但「谁告诉过我什么」不该随窗口滚掉。
    claims = [ob for ob in own if ob["source_type"] == "message"][-CLAIM_LIMIT:]
    notes = staging.get("notes") or {}
    from . import notes as notes_mod          # 局部导入：只用到状态视图与说明文本
    state = notes_mod.state_view(notes.get(actor_id))
    self_view = {
        "id": me["id"],
        "name": me["name"],
        "description": me["description"],
        "goals": list(me["goals"]),
        "current_tendency": me["current_tendency"],
        "change_reason": me["change_reason"],
        "status_text": me["status_text"],
        "location_id": me["location_id"],
        "carried_resources": _carried_resources(staging, actor_id),
        # 会随经历变化的那一层：本人写下的打算与理解，不是世界事实。
        "state": state,
        "state_note": STATE_NOTE,
    }
    # 情境线索来自运行包（场景快照），只进本人这一份输入；旧包没有这个字段就不出现。
    cues = ((staging.get("character_cues") or {}).get(actor_id) or "").strip()
    if cues:
        self_view["situational_cues"] = cues
        self_view["situational_cues_note"] = CUES_NOTE
    return {
        "run": {
            "tick": staging["run"]["tick"],
            "mode": staging["run"]["provider_mode"],
        },
        # 世界共同背景：标题与公开总述。三人共享，不含任何人的目标与倾向。
        "world": _world_view(staging),
        "self": self_view,
        "location": {
            "id": loc["id"],
            "name": loc["name"],
            "description": loc["description"],
            "state_description": loc["state_description"],
            "moment": loc["moment"],
            "resources": _visible_resources(staging, actor_id, loc["id"]),
            "connections": [
                {"id": cid, "name": staging["locations"][cid]["name"]}
                for cid in loc["connections"] if cid in staging["locations"]
            ],
        },
        "present": presenter,
        "observations": [_observation_view(ob, actor_id, staging) for ob in observations],
        "recall": {
            "note": RECALL_NOTE,
            "related": recall_view(staging, actor_id, window),
            "my_attempts_note": ATTEMPT_NOTE,
            "my_attempts": attempts_view(staging, actor_id),
        },
        "known_claims": [_observation_view(ob, actor_id, staging) for ob in claims],
        "rule": ("只能依据本对象列出的信息行动；未列出的人物状态、心理与消息一律视为不知情。"
                 "reliable=false 的内容只是说法，不能当成已经发生的事实。"
                 "self.state 是你自己写下的理解与打算，不是世界事实，别人也不知道；"
                 "recall.my_attempts 里 success=false 的事说明它当时没做成。"),
    }


def forbidden_tokens(staging: dict, actor_id: str) -> list[str]:
    """他人私有信息的判定标记：本人目标/倾向 + 场景声明的私密标记。"""
    tokens: list[str] = []
    for other_id, ch in staging["characters"].items():
        if other_id == actor_id:
            continue
        tokens.extend([g for g in ch["goals"] if g])
        if ch["current_tendency"]:
            tokens.append(ch["current_tendency"])
        tokens.extend(staging.get("private_markers", {}).get(other_id, []))
    return sorted(set(tokens))


def leak_scan(staging: dict, actor_id: str, context: dict) -> list[str]:
    """对该角色的受限上下文做字符串断言，返回命中的他人私有标记。"""
    text = json.dumps(context, ensure_ascii=False)
    return [token for token in forbidden_tokens(staging, actor_id) if token in text]


def serialize_context(context: dict) -> str:
    return json.dumps(context, ensure_ascii=False, indent=2, sort_keys=True)
