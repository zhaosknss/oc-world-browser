"""Storage for published chapters, isolated futures, and owner-checked requests."""
from __future__ import annotations

import hashlib
import json
import uuid

from . import db
from .lease import DEFAULT_LEASE_MS, lease_alive
from .models import EngineError, StepBusy

CORE_TABLES = ("run", "location", "character", "resource", "external_event",
               "event", "observation", "character_note", "story_turn")
PUBLIC_FAILURE = "本章尚未通过生成或核查，阅读节点保持原样；可以重试，已保存的草稿会保留。"

SCHEMA = """
CREATE TABLE IF NOT EXISTS chapter_state (
  id INTEGER PRIMARY KEY CHECK(id=1), revision INTEGER NOT NULL DEFAULT 1,
  cursor INTEGER NOT NULL DEFAULT 0, cutover_tick INTEGER NOT NULL,
  continuity TEXT NOT NULL DEFAULT '', updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS chapter (
  chapter_id INTEGER PRIMARY KEY AUTOINCREMENT, number INTEGER NOT NULL,
  revision INTEGER NOT NULL, status TEXT NOT NULL,
  title TEXT NOT NULL, base_signature TEXT NOT NULL, end_state TEXT NOT NULL,
  projection TEXT NOT NULL, plan TEXT NOT NULL, continuity TEXT NOT NULL DEFAULT '',
  prose TEXT NOT NULL DEFAULT '', reader_digest TEXT NOT NULL DEFAULT '',
  error TEXT, created_at TEXT NOT NULL, published_at TEXT,
  UNIQUE(revision, number)
);
CREATE TABLE IF NOT EXISTS reader_fact (
  event_id INTEGER PRIMARY KEY, chapter_id INTEGER NOT NULL, revealed_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS chapter_request (
  request_id TEXT PRIMARY KEY, tick INTEGER NOT NULL, status TEXT NOT NULL,
  owner_id TEXT, heartbeat_ms INTEGER, result TEXT, error TEXT,
  created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_chapter_status ON chapter(status, revision, number);
CREATE INDEX IF NOT EXISTS idx_chapter_request ON chapter_request(status, heartbeat_ms);
"""


def encode(value) -> str:
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"), sort_keys=True)


def exists(conn) -> bool:
    return conn.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='chapter_state'").fetchone() is not None


def enabled(conn) -> bool:
    return exists(conn) and conn.execute("SELECT 1 FROM chapter_state WHERE id=1").fetchone() is not None


def enable(db_path: str) -> None:
    """Enable at the next checkpoint. Existing prose, facts, and originals stay intact."""
    conn = db.connect(db_path)
    try:
        conn.executescript(SCHEMA)
        with db.write_txn(conn):
            tick = conn.execute("SELECT tick FROM run WHERE run_id=1").fetchone()["tick"]
            conn.execute("INSERT OR IGNORE INTO chapter_state(id,cutover_tick,updated_at) VALUES(1,?,?)",
                         (tick, db.now()))
    finally:
        conn.close()


def snapshot(conn) -> dict:
    return {table: [dict(row) for row in conn.execute(f"SELECT * FROM {table} ORDER BY rowid")]
            for table in CORE_TABLES}


def signature(state: dict) -> str:
    state = dict(state)
    # Diagnostic timing/errors do not alter the fictional checkpoint.
    state["run"] = [{k: v for k, v in row.items()
                     if k not in ("updated_at", "last_error")} for row in state["run"]]
    return hashlib.sha256(encode(state).encode("utf-8")).hexdigest()


def restore(conn, state: dict) -> None:
    """Called inside the publication transaction, never while preparing a future."""
    for table in reversed(CORE_TABLES):
        conn.execute(f"DELETE FROM {table}")
    for table in CORE_TABLES:
        columns = [row["name"] for row in conn.execute(f"PRAGMA table_info({table})")]
        rows = state[table]
        if rows:
            marks = ",".join("?" for _ in columns)
            conn.executemany(f"INSERT INTO {table}({','.join(columns)}) VALUES({marks})",
                             [[row[col] for col in columns] for row in rows])


def state_row(conn) -> dict:
    return dict(conn.execute("SELECT * FROM chapter_state WHERE id=1").fetchone())


def invalidate(conn, reason: str) -> int:
    """An external change only removes unread futures; published canon is untouched."""
    if not enabled(conn):
        return 0
    cur = conn.execute("UPDATE chapter SET status='invalidated',error=?,end_state='' "
                       "WHERE status IN ('draft','prepared','failed')", (reason,))
    conn.execute("UPDATE chapter_state SET revision=revision+1,updated_at=? WHERE id=1", (db.now(),))
    return cur.rowcount


def live_requests(conn) -> list:
    if not exists(conn):
        return []
    return [r for r in conn.execute("SELECT * FROM chapter_request WHERE status='in_progress'")
            if lease_alive(r["heartbeat_ms"], db.now_ms(), DEFAULT_LEASE_MS)]


def claim(conn, request_id: str) -> tuple[str, dict | None]:
    if not isinstance(request_id, str) or not 1 <= len(request_id.strip()) <= 160:
        raise EngineError("继续阅读需要 1–160 字的 request_id")
    owner = uuid.uuid4().hex
    with db.write_txn(conn):
        if conn.execute("SELECT status FROM run WHERE run_id=1").fetchone()["status"] == "ended":
            return owner, {"action": "ended", "message": "这份故事已经结束，可以继续阅读已保存正文",
                           "advanced": None, "prose": None, "accounting": None, "timing": {}}
        row = conn.execute("SELECT * FROM chapter_request WHERE request_id=?", (request_id,)).fetchone()
        if row is not None and row["status"] == "committed":
            result = json.loads(row["result"])
            result["advanced"]["deduped"] = True
            return owner, result
        if live_requests(conn):
            raise StepBusy("这份故事正在准备或展示章节，请等当前请求完成")
        for old in conn.execute("SELECT heartbeat_ms FROM step_request WHERE status='in_progress'"):
            if lease_alive(old["heartbeat_ms"], db.now_ms(), DEFAULT_LEASE_MS):
                raise StepBusy("旧推进仍在处理，不能同时生成章节")
        conn.execute("UPDATE chapter_request SET status='failed',error='生成租约已过期' "
                     "WHERE status='in_progress'")
        tick = conn.execute("SELECT tick FROM run WHERE run_id=1").fetchone()["tick"]
        stamp = db.now()
        conn.execute("INSERT INTO chapter_request(request_id,tick,status,owner_id,heartbeat_ms,created_at,updated_at)"
                     " VALUES(?,?,'in_progress',?,?,?,?) ON CONFLICT(request_id) DO UPDATE SET "
                     "status='in_progress',owner_id=excluded.owner_id,heartbeat_ms=excluded.heartbeat_ms,"
                     "error=NULL,updated_at=excluded.updated_at",
                     (request_id, tick, owner, db.now_ms(), stamp, stamp))
    return owner, None


def check_owner(conn, request_id, owner, revision, anchor) -> None:
    if conn.execute("SELECT status FROM run WHERE run_id=1").fetchone()["status"] == "ended":
        raise EngineError("故事已结束，不能发布新章节")
    row = conn.execute("SELECT status,owner_id FROM chapter_request WHERE request_id=?", (request_id,)).fetchone()
    if row is None or row["status"] != "in_progress" or row["owner_id"] != owner:
        raise EngineError("章节生成所有权已被接管，迟到结果作废")
    if state_row(conn)["revision"] != revision or signature(snapshot(conn)) != anchor:
        raise EngineError("阅读节点已变化，准备中的未来作废；请从当前节点继续")


def segment(row) -> dict:
    projection = json.loads(row["projection"])
    ticks = projection["ticks"]
    return {"seg_id": "chapter-" + str(row["chapter_id"]), "tick": ticks[1],
            "chapter_number": row["number"], "chapter_title": row["title"],
            "status": "committed", "prose": row["prose"], "has_prose": bool(row["prose"]),
            "digest": row["reader_digest"], "pov_actor_id": None,
            "place_names": list(dict.fromkeys(s["place"]["name"] for s in projection["scenes"])),
            "prose_style": "chapter", "checkpoint": True, "created_at": row["created_at"],
            "updated_at": row["published_at"] or row["created_at"]}


def publish(conn, row, request_id, owner, revision, anchor, accounting, started_ms, warning="") -> dict:
    import time
    with db.write_txn(conn):
        check_owner(conn, request_id, owner, revision, anchor)
        if row["base_signature"] != anchor:
            raise EngineError("预备章节与当前事实不一致，不能接续")
        restore(conn, json.loads(row["end_state"]))
        stamp = db.now()
        conn.execute("UPDATE chapter SET status='published',published_at=?,end_state='' WHERE chapter_id=? AND status='prepared'",
                     (stamp, row["chapter_id"]))
        conn.execute("UPDATE chapter_state SET cursor=?,continuity=?,updated_at=? WHERE id=1",
                     (row["number"], row["continuity"], stamp))
        projection = json.loads(row["projection"])
        for eid in projection["reader_event_ids"]:
            conn.execute("INSERT OR IGNORE INTO reader_fact(event_id,chapter_id,revealed_at) VALUES(?,?,?)",
                         (eid, row["chapter_id"], stamp))
        prose = segment({**dict(row), "published_at": stamp})
        result = {"action": "advanced", "advanced": {
            "ok": True, "tick": prose["tick"], "chapter_number": row["number"],
            "request_id": request_id, "deduped": False,
            "events": len(projection["reader_event_ids"])},
            "prose": {"ok": True, "segment": prose}, "recovered": None,
            "accounting": accounting, "advance_accounting": None,
            "engine_mode": "chapters", "checkpoint": True,
            "cache_hit": accounting.get("cache_hit", False),
            "preparation_warning": warning,
            "timing": {"complete_ms": round((time.perf_counter() * 1000 - started_ms), 3)}}
        conn.execute("UPDATE chapter_request SET status='committed',tick=?,result=?,owner_id=NULL,"
                     "heartbeat_ms=NULL,error=NULL,updated_at=? WHERE request_id=? AND owner_id=?",
                     (prose["tick"], encode(result), stamp, request_id, owner))
    return result


def fail(conn, request_id, owner, error: str) -> None:
    with db.write_txn(conn):
        tick = conn.execute("SELECT tick FROM run WHERE run_id=1").fetchone()["tick"]
        conn.execute("INSERT INTO error_log(request_id,tick,stage,error_type,message,created_at) VALUES(?,?,?,?,?,?)",
                     (request_id, tick, "chapter", "chapter_failure", error, db.now()))
        conn.execute("UPDATE chapter_request SET status='failed',error=?,owner_id=NULL,heartbeat_ms=NULL,"
                     "updated_at=? WHERE request_id=? AND owner_id=? AND status='in_progress'",
                     (PUBLIC_FAILURE, db.now(), request_id, owner))
