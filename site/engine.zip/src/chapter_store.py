"""Storage for published chapters, isolated futures, and owner-checked requests."""
from __future__ import annotations

import hashlib
import json
import uuid

from . import db
from .lease import DEFAULT_LEASE_MS, lease_alive
from .models import EngineError, StepBusy

CORE_TABLES = ("run", "location", "character", "resource", "external_event",
               "event", "observation", "character_note", "story_turn")
PUBLIC_FAILURE = "本章尚未通过生成或核查，阅读节点保持原样；可以重试，已保存的草稿会保留。"
FAILURE_CATEGORIES = {"round_limit", "scene_limit", "structure", "review", "provider", "engine", "storage"}
FAILURE_STAGES = {"director_plan", "director_review", "writer_craft", "actor_perform", "settle",
                  "settle_batch", "world_event", "writer_chapter", "editor_review", "simulation", "saving"}


def provider_issue(message):
    if "的 content 不是合法 JSON" in message:
        return "content_json"
    if "响应不是合法 JSON" in message:
        return "response_json"
    if "finish_reason=length" in message or "max_tokens 截断" in message:
        return "truncated"
    if any(text in message for text in ("返回空 content", "响应没有 choices", "响应体为空")):
        return "empty"
    return None


def failure_message(category, stage, mode, issue=None):
    labels = {"director_plan": "导演规划", "director_review": "导演复核", "writer_craft": "场景表达",
              "actor_perform": "人物演绎", "settle": "行动结算", "settle_batch": "行动结算",
              "world_event": "世界裁定", "writer_chapter": "章节写作", "editor_review": "正文核查",
              "simulation": "章节推演", "saving": "本地保存"}
    if category in ("round_limit", "scene_limit"):
        message = ("本场" if category == "round_limit" else "本章") + "尚未形成自然阶段节点，达到演绎保护上限。"
    else:
        cause = {"structure": "返回的结构未通过校验", "review": "正文仍未通过事实与信息边界核查",
                 "provider": "模型请求未完成", "storage": "本地保存未完成"}.get(category, "尚未完成")
        specific = {"content_json": "模型返回的 JSON 内容无法解析", "response_json": "API 响应不是合法 JSON",
                    "truncated": "模型输出被长度上限截断", "empty": "模型返回为空"}.get(issue)
        message = labels.get(stage, "章节生成") + "：" + (specific or cause) + "。"
    message += "阅读节点保持原样。"
    if mode == "writing":
        return message + "完整推演草稿已保留，重试只继续写作与核查。"
    if mode == "simulation":
        suffix = "导演复核" if category in ("round_limit", "scene_limit") else "已保存阶段"
        return message + "推演检查点已保留，重试从" + suffix + "继续；未完成的一轮可能需要重做。"
    return message + "这次没有可恢复的推演检查点，重试需要重新准备。"

SCHEMA = """
CREATE TABLE IF NOT EXISTS chapter_state (
  id INTEGER PRIMARY KEY CHECK(id=1), revision INTEGER NOT NULL DEFAULT 1,
  cursor INTEGER NOT NULL DEFAULT 0, cutover_tick INTEGER NOT NULL,
  continuity TEXT NOT NULL DEFAULT '', updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS chapter (
  chapter_id INTEGER PRIMARY KEY AUTOINCREMENT, number INTEGER NOT NULL,
  revision INTEGER NOT NULL, status TEXT NOT NULL,
  title TEXT NOT NULL, base_signature TEXT NOT NULL, end_state TEXT NOT NULL,
  projection TEXT NOT NULL, plan TEXT NOT NULL, continuity TEXT NOT NULL DEFAULT '',
  prose TEXT NOT NULL DEFAULT '', reader_digest TEXT NOT NULL DEFAULT '',
  error TEXT, created_at TEXT NOT NULL, published_at TEXT,
  UNIQUE(revision, number)
);
CREATE TABLE IF NOT EXISTS reader_fact (
  event_id INTEGER PRIMARY KEY, chapter_id INTEGER NOT NULL, revealed_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS chapter_request (
  request_id TEXT PRIMARY KEY, tick INTEGER NOT NULL, status TEXT NOT NULL,
  owner_id TEXT, heartbeat_ms INTEGER, result TEXT, error TEXT,
  created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS chapter_work (
  revision INTEGER NOT NULL, number INTEGER NOT NULL, base_signature TEXT NOT NULL,
  simulation TEXT NOT NULL, progress TEXT NOT NULL, updated_at TEXT NOT NULL,
  PRIMARY KEY(revision, number)
);
CREATE INDEX IF NOT EXISTS idx_chapter_status ON chapter(status, revision, number);
CREATE INDEX IF NOT EXISTS idx_chapter_request ON chapter_request(status, heartbeat_ms);
"""


def encode(value) -> str:
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"), sort_keys=True)


def exists(conn) -> bool:
    return conn.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='chapter_state'").fetchone() is not None


def enabled(conn) -> bool:
    return exists(conn) and conn.execute("SELECT 1 FROM chapter_state WHERE id=1").fetchone() is not None


def enable(db_path: str) -> None:
    """Enable at the next checkpoint. Existing prose, facts, and originals stay intact."""
    conn = db.connect(db_path)
    try:
        conn.executescript(SCHEMA)
        with db.write_txn(conn):
            tick = conn.execute("SELECT tick FROM run WHERE run_id=1").fetchone()["tick"]
            conn.execute("INSERT OR IGNORE INTO chapter_state(id,cutover_tick,updated_at) VALUES(1,?,?)",
                         (tick, db.now()))
    finally:
        conn.close()


def snapshot(conn) -> dict:
    return {table: [dict(row) for row in conn.execute(f"SELECT * FROM {table} ORDER BY rowid")]
            for table in CORE_TABLES}


def signature(state: dict) -> str:
    state = dict(state)
    # Diagnostic timing/errors do not alter the fictional checkpoint.
    state["run"] = [{k: v for k, v in row.items()
                     if k not in ("updated_at", "last_error")} for row in state["run"]]
    return hashlib.sha256(encode(state).encode("utf-8")).hexdigest()


def restore(conn, state: dict) -> None:
    """Called inside the publication transaction, never while preparing a future."""
    for table in reversed(CORE_TABLES):
        conn.execute(f"DELETE FROM {table}")
    for table in CORE_TABLES:
        columns = [row["name"] for row in conn.execute(f"PRAGMA table_info({table})")]
        rows = state[table]
        if rows:
            marks = ",".join("?" for _ in columns)
            conn.executemany(f"INSERT INTO {table}({','.join(columns)}) VALUES({marks})",
                             [[row[col] for col in columns] for row in rows])


def state_row(conn) -> dict:
    return dict(conn.execute("SELECT * FROM chapter_state WHERE id=1").fetchone())


def invalidate(conn, reason: str) -> int:
    """An external change only removes unread futures; published canon is untouched."""
    if not enabled(conn):
        return 0
    cur = conn.execute("UPDATE chapter SET status='invalidated',error=?,end_state='' "
                       "WHERE status IN ('draft','prepared','failed')", (reason,))
    ensure_work_schema(conn)
    conn.execute("DELETE FROM chapter_work")
    conn.execute("UPDATE chapter_state SET revision=revision+1,updated_at=? WHERE id=1", (db.now(),))
    return cur.rowcount


def ensure_work_schema(conn) -> None:
    """Also migrate already-enabled chapter archives when they are opened."""
    conn.execute("CREATE TABLE IF NOT EXISTS chapter_work ("
                 "revision INTEGER NOT NULL, number INTEGER NOT NULL, base_signature TEXT NOT NULL,"
                 "simulation TEXT NOT NULL, progress TEXT NOT NULL, updated_at TEXT NOT NULL,"
                 "PRIMARY KEY(revision, number))")


def load_work(conn, revision, number, base_signature) -> dict | None:
    ensure_work_schema(conn)
    row = conn.execute("SELECT * FROM chapter_work WHERE revision=? AND number=?",
                       (revision, number)).fetchone()
    if row is None:
        return None
    if row["base_signature"] != base_signature:
        conn.execute("DELETE FROM chapter_work WHERE revision=? AND number=?", (revision, number))
        return None
    return {"simulation": json.loads(row["simulation"]), "progress": json.loads(row["progress"])}


def save_work(conn, request_id, owner, revision, anchor, number, base_signature, simulation, progress):
    ensure_work_schema(conn)
    with db.write_txn(conn):
        check_owner(conn, request_id, owner, revision, anchor)
        conn.execute("INSERT INTO chapter_work(revision,number,base_signature,simulation,progress,updated_at)"
                     " VALUES(?,?,?,?,?,?) ON CONFLICT(revision,number) DO UPDATE SET "
                     "base_signature=excluded.base_signature,simulation=excluded.simulation,"
                     "progress=excluded.progress,updated_at=excluded.updated_at",
                     (revision, number, base_signature, encode(simulation), encode(progress), db.now()))


def clear_work(conn, revision, number):
    ensure_work_schema(conn)
    conn.execute("DELETE FROM chapter_work WHERE revision=? AND number=?", (revision, number))


def live_requests(conn) -> list:
    if not exists(conn):
        return []
    return [r for r in conn.execute("SELECT * FROM chapter_request WHERE status='in_progress'")
            if lease_alive(r["heartbeat_ms"], db.now_ms(), DEFAULT_LEASE_MS)]


def claim(conn, request_id: str) -> tuple[str, dict | None]:
    if not isinstance(request_id, str) or not 1 <= len(request_id.strip()) <= 160:
        raise EngineError("继续阅读需要 1–160 字的 request_id")
    owner = uuid.uuid4().hex
    with db.write_txn(conn):
        if conn.execute("SELECT status FROM run WHERE run_id=1").fetchone()["status"] == "ended":
            return owner, {"action": "ended", "message": "这份故事已经结束，可以继续阅读已保存正文",
                           "advanced": None, "prose": None, "accounting": None, "timing": {}}
        row = conn.execute("SELECT * FROM chapter_request WHERE request_id=?", (request_id,)).fetchone()
        if row is not None and row["status"] == "committed":
            result = json.loads(row["result"])
            result["advanced"]["deduped"] = True
            return owner, result
        if live_requests(conn):
            raise StepBusy("这份故事正在准备或展示章节，请等当前请求完成")
        for old in conn.execute("SELECT heartbeat_ms FROM step_request WHERE status='in_progress'"):
            if lease_alive(old["heartbeat_ms"], db.now_ms(), DEFAULT_LEASE_MS):
                raise StepBusy("旧推进仍在处理，不能同时生成章节")
        conn.execute("UPDATE chapter_request SET status='failed',error='生成租约已过期' "
                     "WHERE status='in_progress'")
        tick = conn.execute("SELECT tick FROM run WHERE run_id=1").fetchone()["tick"]
        stamp = db.now()
        conn.execute("INSERT INTO chapter_request(request_id,tick,status,owner_id,heartbeat_ms,created_at,updated_at)"
                     " VALUES(?,?,'in_progress',?,?,?,?) ON CONFLICT(request_id) DO UPDATE SET "
                     "status='in_progress',owner_id=excluded.owner_id,heartbeat_ms=excluded.heartbeat_ms,"
                     "error=NULL,updated_at=excluded.updated_at",
                     (request_id, tick, owner, db.now_ms(), stamp, stamp))
    return owner, None


def check_owner(conn, request_id, owner, revision, anchor) -> None:
    if conn.execute("SELECT status FROM run WHERE run_id=1").fetchone()["status"] == "ended":
        raise EngineError("故事已结束，不能发布新章节")
    row = conn.execute("SELECT status,owner_id FROM chapter_request WHERE request_id=?", (request_id,)).fetchone()
    if row is None or row["status"] != "in_progress" or row["owner_id"] != owner:
        raise EngineError("章节生成所有权已被接管，迟到结果作废")
    if state_row(conn)["revision"] != revision or signature(snapshot(conn)) != anchor:
        raise EngineError("阅读节点已变化，准备中的未来作废；请从当前节点继续")


def segment(row) -> dict:
    projection = json.loads(row["projection"])
    ticks = projection["ticks"]
    return {"seg_id": "chapter-" + str(row["chapter_id"]), "tick": ticks[1],
            "chapter_number": row["number"], "chapter_title": row["title"],
            "status": "committed", "prose": row["prose"], "has_prose": bool(row["prose"]),
            "digest": row["reader_digest"], "pov_actor_id": None,
            "place_names": list(dict.fromkeys(s["place"]["name"] for s in projection["scenes"])),
            "prose_style": "chapter", "checkpoint": True, "created_at": row["created_at"],
            "updated_at": row["published_at"] or row["created_at"]}


def publish(conn, row, request_id, owner, revision, anchor, accounting, started_ms, warning="") -> dict:
    import time
    with db.write_txn(conn):
        check_owner(conn, request_id, owner, revision, anchor)
        if row["base_signature"] != anchor:
            raise EngineError("预备章节与当前事实不一致，不能接续")
        restore(conn, json.loads(row["end_state"]))
        stamp = db.now()
        conn.execute("UPDATE chapter SET status='published',published_at=?,end_state='' WHERE chapter_id=? AND status='prepared'",
                     (stamp, row["chapter_id"]))
        conn.execute("UPDATE chapter_state SET cursor=?,continuity=?,updated_at=? WHERE id=1",
                     (row["number"], row["continuity"], stamp))
        projection = json.loads(row["projection"])
        for eid in projection["reader_event_ids"]:
            conn.execute("INSERT OR IGNORE INTO reader_fact(event_id,chapter_id,revealed_at) VALUES(?,?,?)",
                         (eid, row["chapter_id"], stamp))
        prose = segment({**dict(row), "published_at": stamp})
        result = {"action": "advanced", "advanced": {
            "ok": True, "tick": prose["tick"], "chapter_number": row["number"],
            "request_id": request_id, "deduped": False,
            "events": len(projection["reader_event_ids"])},
            "prose": {"ok": True, "segment": prose}, "recovered": None,
            "accounting": accounting, "advance_accounting": None,
            "engine_mode": "chapters", "checkpoint": True,
            "cache_hit": accounting.get("cache_hit", False),
            "preparation_warning": warning,
            "timing": {"complete_ms": round((time.perf_counter() * 1000 - started_ms), 3)}}
        conn.execute("UPDATE chapter_request SET status='committed',tick=?,result=?,owner_id=NULL,"
                     "heartbeat_ms=NULL,error=NULL,updated_at=? WHERE request_id=? AND owner_id=?",
                     (prose["tick"], encode(result), stamp, request_id, owner))
    return result


def fail(conn, request_id, owner, error: str, public=None) -> None:
    with db.write_txn(conn):
        if conn.execute("SELECT 1 FROM chapter_request WHERE request_id=? AND owner_id=? AND status='in_progress'",
                        (request_id, owner)).fetchone() is None:
            return
        tick = conn.execute("SELECT tick FROM run WHERE run_id=1").fetchone()["tick"]
        conn.execute("INSERT INTO error_log(request_id,tick,stage,error_type,message,created_at) VALUES(?,?,?,?,?,?)",
                     (request_id, tick, "chapter", "chapter_failure", error, db.now()))
        conn.execute("UPDATE chapter_request SET status='failed',error=?,result=?,owner_id=NULL,heartbeat_ms=NULL,"
                     "updated_at=? WHERE request_id=? AND owner_id=? AND status='in_progress'",
                      (PUBLIC_FAILURE, encode({"advanced": public}) if public is not None else None,
                       db.now(), request_id, owner))
