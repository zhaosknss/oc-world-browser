"""推进核心：一次 step = 一个 tick。

步骤（对应 docs/第一阶段实施任务.md「一步如何运行」）：
 0 请求登记与并发闸门（实例所有权 + 租约心跳）→ 1 读取有效快照与待处理事件
 → 2 产生暂存副本 → 3 外部事件先在暂存世界生效
 → 3' 世界回合（只有显式打开 story_loop 的运行包）：给出本刻局面与零或一件外界变化
 → 4 构造受限上下文并请求意图（模型等待在写事务外）
 → 5 按记录顺序结算（后一个依据前面已结算后果复核）
 → 6 一个短事务提交 → 7 提交后按已结算事件直接格式化展示
新入队的事件不参与本次推进，留到下一步。

两种推进路径（由运行包场景快照里的 `story_loop.enabled` 决定，见 src/story.py）：

- **默认（旧包/旧档）**：所有角色先各自决策一次，复杂行动合成一个批次请求结算，
  最后按顺序应用。上下文基于同一份「本刻开始前」的世界，因此同刻内互相看不见结果。
- **剧情体验改造（`story_loop.sequential_actions`）**：角色按轮转顺序**逐个**
  context → decide → 校验 → 结算 → 应用，后行动者拿到的是更新过的世界与感知范围；
  复杂行动复用批次结算协议，但每次只送一个请求（牺牲批量，换来当刻的顺序正确性）。
  每人每刻仍然只决策一次。同时按开关启用世界回合与同场公开发言（见 src/story.py、
  src/settlement.py::settle_speak）。

并发闸门说明见 src/lease.py：登记带 owner_id 与心跳，只有心跳过期的登记才可被清理，
因此恢复接口与另一进程的启动都不会释放仍在执行的推进。心跳线程承受瞬时连接错误；
租约确实保不住或登记被接管时，它向引擎显式报告失效，当前推进随即中止。
"""
from __future__ import annotations

import json
import os
import sqlite3
import uuid

from . import context as ctxmod
from . import db, notes as notes_mod, scenario as scenario_mod, settlement, story as story_mod
from .lease import DEFAULT_HEARTBEAT_MS, DEFAULT_LEASE_MS, StepLease, lease_alive
from .models import (EXIT_SIGNALS, EngineError, ProviderError, ProviderSchemaError,
                     StepBusy, classify_provider_exception, scrub_secrets, stage_label,
                     validate_intent, validate_settlement)

KIND_LABEL = {"external": "外部", "move": "移动", "speak": "对话",
              "act": "行动", "wait": "待机"}
MAX_REQUEST_ID = 128
# 每个角色带回的「本人已结算尝试」上限：个人状态取回用，与近期观察窗口相互独立。
OWN_EVENT_LIMIT = 12
# 参与「本人尝试」的事件类型：待机不算一次尝试。
ATTEMPT_EVENT_KINDS = ("act", "speak", "move")
# 世界回合自动带入的外部事件用这个 key 入 external_event 表（区别于 if_start / intervention）。
WORLD_EVENT_KEY = "world_turn"
# 世界回合读进提示词的「近几刻已结算事件」上限。
WORLD_RECENT_EVENTS = 12


def provider_view(provider) -> dict:
    """提供方自我说明（模式、模型名、端点、超时……），供界面显示；绝不含密钥。"""
    describe = getattr(provider, "describe", None)
    if callable(describe):
        try:
            view = describe()
            if isinstance(view, dict):
                return view
        except Exception:                      # noqa: BLE001 - 说明信息不该影响推进
            pass
    return {"mode": getattr(provider, "mode", "unknown"),
            "provider": type(provider).__name__}



def _normalize_request_id(value) -> str:
    if not isinstance(value, str) or not value.strip():
        raise EngineError("request_id 不能为空")
    rid = value.strip()
    if len(rid) > MAX_REQUEST_ID:
        raise EngineError(f"request_id 过长（上限 {MAX_REQUEST_ID}）")
    return rid


def _visibility_note(staging: dict, witnesses: list[str]) -> str:
    all_ids = sorted(staging["characters"])
    if not witnesses:
        return "无人感知"
    if set(witnesses) >= set(all_ids):
        return "全场可见"
    names = [staging["characters"][w]["name"] for w in witnesses if w in staging["characters"]]
    if len(witnesses) == 1:
        return f"仅{names[0]}可知"
    return "、".join(names) + "在场"


def probe_report(staging: dict, contexts: dict[str, dict]) -> dict:
    """按场景声明的探针检查各角色上下文中是否出现指定内容（可见/不可见）。"""
    probes = staging["scenario"].get("probes", [])
    out: dict[str, dict] = {}
    for actor_id, ctx in contexts.items():
        text = json.dumps(ctx, ensure_ascii=False)
        out[actor_id] = {p["label"]: (p["token"] in text) for p in probes}
    return out


def format_display(staging: dict, events: list[dict]) -> str:
    """已结算事件直接格式化展示，不再调用叙述模型。"""
    tick = staging["run"]["tick"]
    lines = [f"【第 {tick} 刻】"]
    for ev in events:
        label = KIND_LABEL.get(ev["kind"], ev["kind"])
        line = f"· [{label}] {ev['text']}"
        if not ev["success"]:
            line += f"（未成立：{ev['reason']}）"
        line += f"　｜{ev['visibility']}"
        lines.append(line)
    if len(lines) == 1:
        lines.append("· 本刻没有任何已结算事件。")
    return "\n".join(lines)


class Runner:
    def __init__(self, db_path: str, provider, lease_ms: int | None = None,
                 heartbeat_ms: int | None = None, instance_id: str | None = None):
        self.db_path = db_path
        self.provider = provider
        self.lease_ms = DEFAULT_LEASE_MS if lease_ms is None else int(lease_ms)
        self.heartbeat_ms = DEFAULT_HEARTBEAT_MS if heartbeat_ms is None else int(heartbeat_ms)
        self.instance_id = instance_id or f"pid{os.getpid()}-{uuid.uuid4().hex[:8]}"

    # ------------------------------------------------------------------ 读取
    def load_staging(self, conn) -> dict:
        scenario = scenario_mod.read_scenario(conn)
        run = conn.execute("SELECT * FROM run WHERE run_id=1").fetchone()
        if run is None:
            raise EngineError("数据库未初始化：缺少 run 记录")
        locations = {}
        for row in conn.execute("SELECT * FROM location ORDER BY id"):
            locations[row["id"]] = {
                "id": row["id"], "name": row["name"], "description": row["description"],
                "connections": json.loads(row["connections"] or "[]"),
                "moment": row["moment"], "state_description": row["state_description"],
            }
        characters = {}
        for row in conn.execute("SELECT * FROM character ORDER BY id"):
            characters[row["id"]] = {
                "id": row["id"], "name": row["name"], "description": row["description"],
                "goals": json.loads(row["goals"] or "[]"),
                "current_tendency": row["current_tendency"],
                "change_reason": row["change_reason"],
                "location_id": row["location_id"], "status_text": row["status_text"],
            }
        resources = {}
        for row in conn.execute("SELECT * FROM resource ORDER BY id"):
            resources[row["id"]] = {
                "id": row["id"], "name": row["name"], "description": row["description"],
                "location_id": row["location_id"], "holder_id": row["holder_id"],
                "unique_item": bool(row["unique_item"]), "updated_tick": row["updated_tick"],
            }
        # 观察连同来源事件一起读出，供上下文按角色范围过滤（见 src/context.py）。
        observations: dict[str, list[dict]] = {}
        for row in conn.execute(
                "SELECT o.*, e.kind AS src_kind, e.text AS src_text,"
                " e.witnesses AS src_witnesses, e.tick AS src_tick,"
                " e.actor_id AS src_actor_id"
                " FROM observation o LEFT JOIN event e ON e.event_id = o.source_event_id"
                " ORDER BY o.obs_id"):
            source_event = None
            if row["source_event_id"] is not None and row["src_kind"] is not None:
                source_event = {
                    "event_id": row["source_event_id"], "tick": row["src_tick"],
                    "kind": row["src_kind"], "actor_id": row["src_actor_id"],
                    "text": row["src_text"],
                    "witnesses": json.loads(row["src_witnesses"] or "[]"),
                }
            observations.setdefault(row["owner_id"], []).append({
                "tick": row["tick"], "content": row["content"],
                "source_type": row["source_type"], "source_event_id": row["source_event_id"],
                "source_actor_id": row["source_actor_id"], "source_event": source_event,
                "first_hand": row["first_hand"], "reliable": row["reliable"],
            })
        pending = [dict(row) for row in conn.execute(
            "SELECT * FROM external_event WHERE status='pending' ORDER BY event_id")]
        markers = {ch["id"]: list(ch.get("private_markers", []))
                   for ch in scenario.get("characters", [])}
        # 情境线索（可选，来自运行包快照）：只进本人那一份决策输入，不进叙述、不给别人。
        cues = {ch["id"]: str(ch.get("situational_cues") or "")
                for ch in scenario.get("characters", [])}
        # 个人状态与「本人已结算尝试」：都只按 actor_id 取本人那一份。
        # 旧存档可能还没有 character_note 表（notes.load_all 会当成「还没写下」返回空表）。
        return {
            "scenario": scenario,
            "run": {
                "tick": run["tick"], "status": run["status"],
                "world_revision": run["world_revision"], "actor_cursor": run["actor_cursor"],
                "provider_mode": run["provider_mode"], "scenario_version": run["scenario_version"],
                # 演示层的开场条件：世界回合要把原始 IF 与它的类型/说法一起读进来。
                # 它们在 run 表里，旧档补列后为 NULL，语义就是「没有起始条件」。
                "if_condition": run["if_condition"], "if_patch": self._if_patch(run["if_patch"]),
                "prose_style": run["prose_style"],
            },
            "locations": locations, "characters": characters, "resources": resources,
            "observations": observations, "pending_external": pending,
            "private_markers": markers, "character_cues": cues,
            "story_turns": story_mod.load_turns(conn),
            "new_events": [], "seq": 0, "event_index": {},
            "notes": notes_mod.load_all(conn),
            "own_events": self._load_own_events(conn, sorted(characters)),
        }

    @staticmethod
    def _if_patch(raw) -> dict:
        """run.if_patch 是演示层写下的 json；坏了或还没写都当成「没有补丁」。"""
        if not raw:
            return {}
        try:
            value = json.loads(raw)
        except (TypeError, ValueError):
            return {}
        return value if isinstance(value, dict) else {}

    def _load_own_events(self, conn, actor_ids: list[str]) -> dict[str, list[dict]]:
        """每个角色最近若干条自己做成的事（含没做成的），用于个人经历取回。

        只按 actor_id 取，不掺别人的记录；每条都带 success 与 reason，
        角色下一轮能看出「我上次试过什么、成没成、当时为什么没成」。
        """
        placeholders = ",".join("?" for _ in ATTEMPT_EVENT_KINDS)
        out: dict[str, list[dict]] = {}
        for actor_id in actor_ids:
            rows = conn.execute(
                "SELECT event_id, tick, kind, text, success, reason FROM event"
                f" WHERE actor_id=? AND kind IN ({placeholders})"
                " ORDER BY event_id DESC LIMIT ?",
                (actor_id, *ATTEMPT_EVENT_KINDS, OWN_EVENT_LIMIT)).fetchall()
            out[actor_id] = [dict(row) for row in reversed(rows)]
        return out

    # ------------------------------------------------------- provider 边界
    def _provider_call(self, label: str, fn, *args):
        """归一化 provider 边界的异常。

        退出信号原样上抛；其余一律变成 ProviderError，避免未归一的异常
        绕开引擎的收尾路径、把在途登记挂在库里。
        """
        try:
            return fn(*args)
        except ProviderError:
            raise
        except EXIT_SIGNALS:
            raise
        except BaseException as exc:            # 含 asyncio.CancelledError（BaseException 子类）
            raise classify_provider_exception(exc, label) from exc

    # ------------------------------------------------------------------ 推进
    def step(self, request_id: str) -> dict:
        rid = _normalize_request_id(request_id)
        conn = db.connect(self.db_path)
        stage = "reserve"
        lease: StepLease | None = None
        expected_revision: int | None = None
        try:
            stamp = db.now()
            row = conn.execute(
                "SELECT * FROM step_request WHERE request_id=?", (rid,)).fetchone()
            if row is not None and row["status"] == "committed":
                stored = json.loads(row["result"])
                stored["deduped"] = True
                return stored
            if (row is not None and row["status"] == "in_progress"
                    and lease_alive(row["heartbeat_ms"], db.now_ms(), self.lease_ms)):
                raise StepBusy(f"该 request_id 正在处理中：{rid}（登记租约仍有效）")
            live = [r["request_id"] for r in conn.execute(
                "SELECT request_id, heartbeat_ms FROM step_request WHERE status='in_progress'")
                if lease_alive(r["heartbeat_ms"], db.now_ms(), self.lease_ms)]
            if live:
                raise StepBusy(f"同一 run 已有推进请求在进行中：{live[0]}（登记租约仍有效）")

            staging = self.load_staging(conn)
            # 已结束的故事不再推进（演示层结束本次演示后写 status='ended'）：
            # 界面说结束后世界还在往前走，比不结束更糟。
            if staging["run"].get("status") == "ended":
                raise EngineError("这次故事已经结束，不再推进；要换条件请新开一个存档。")
            base_tick = staging["run"]["tick"]
            base_revision = staging["run"]["world_revision"]
            expected_revision = base_revision
            new_tick = base_tick + 1
            staging["run"]["tick"] = new_tick

            # 登记与并发闸门在同一个写事务里复核：先按租约清掉失效登记，
            # 抢到锁且成为唯一在飞请求的实例才算登记成功。
            dedupe: dict | None = None
            with db.write_txn(conn):
                from . import chapter_store
                if chapter_store.live_requests(conn):
                    raise StepBusy("当前故事正在生成章节，不能并行逐刻推进")
                self._expire_stale(conn)
                fresh = conn.execute(
                    "SELECT status, result FROM step_request WHERE request_id=?", (rid,)).fetchone()
                if fresh is not None and fresh["status"] == "committed":
                    dedupe = json.loads(fresh["result"])
                else:
                    if fresh is None:
                        cur = conn.execute(
                            "INSERT OR IGNORE INTO step_request(request_id, tick, status,"
                            " owner_id, heartbeat_ms, created_at, updated_at)"
                            " VALUES(?,?,?,?,?,?,?)",
                            (rid, new_tick, "in_progress", self.instance_id, db.now_ms(),
                             stamp, stamp))
                    elif fresh["status"] == "failed":
                        cur = conn.execute(
                            "UPDATE step_request SET status='in_progress', tick=?, error=NULL,"
                            " owner_id=?, heartbeat_ms=?, updated_at=?"
                            " WHERE request_id=? AND status='failed'",
                            (new_tick, self.instance_id, db.now_ms(), stamp, rid))
                    else:
                        cur = None
                    claimed = cur is not None and cur.rowcount == 1
                    if not claimed:
                        raise StepBusy(f"该 request_id 的登记已被其他实例占用：{rid}")
                    flying = conn.execute(
                        "SELECT COUNT(*) AS n, MIN(request_id) AS rid FROM step_request"
                        " WHERE status='in_progress'").fetchone()
                    if flying["n"] > 1:
                        raise StepBusy(f"同一 run 已有推进请求在进行中：{flying['rid']}")
            if dedupe is not None:
                dedupe["deduped"] = True
                return dedupe

            lease = StepLease(self.db_path, rid, self.instance_id, self.heartbeat_ms,
                              self.lease_ms)
            lease.start()

            # 3 外部事件先在暂存世界生效，并按明确范围生成观察
            stage = "external"
            consumed = self._apply_external(staging)

            loop = story_mod.loop_config(staging["scenario"])
            order = self._actor_order(staging)
            char_ids = set(staging["characters"])
            loc_ids = set(staging["locations"])
            contexts: dict[str, dict] = {}
            isolation: dict[str, list[str]] = {}
            intents: list[dict] = []

            # 3' 世界回合：只有显式打开 story_loop 的运行包才会多这一次调用。
            # 它在角色决策之前，读到的是「已应用读者事件」的世界；给出的外界变化
            # 同样先落在暂存世界，后行动的角色因此可能感知到。
            if loop["world_turn"]:
                stage = "world"
                staging["story_turn"] = self._world_turn(staging, consumed, lease, conn)

            if loop["sequential_actions"]:
                # 4/5 顺序路径：逐个「决策 → 结算 → 应用」。后行动者拿到的是更新过的
                # 世界与感知范围，所以同刻就能接上前人的话与结果；每人仍然只决策一次。
                for actor_id in order:
                    stage = "intent"
                    ctx = ctxmod.build_context(staging, actor_id)
                    contexts[actor_id] = ctx
                    isolation[actor_id] = ctxmod.leak_scan(staging, actor_id, ctx)
                    raw = self._provider_call(f"decide/{actor_id}", self.provider.decide, ctx)
                    self._ensure_lease(lease)
                    try:
                        intent = validate_intent(
                            raw, actor_id, char_ids, loc_ids,
                            {cid: ch["location_id"]
                             for cid, ch in staging["characters"].items()})
                    except ProviderSchemaError as exc:
                        raise ProviderSchemaError(
                            f"[{stage_label('decide', actor_id)}] {exc}") from exc
                    intents.append(intent)
                    stage = "settle"
                    staging["seq"] += 1
                    seq = staging["seq"]
                    action = intent["action"]
                    if action == "act":
                        validated, origin = self._single_settle(staging, intent, ctx, new_tick)
                        event = settlement.settle_complex(
                            staging, intent, validated, new_tick, seq, origin)
                    else:
                        event = self._settle_simple(staging, intent, new_tick, seq,
                                                    loop["public_speech"])
                    settlement.apply_event(staging, event)
                    self._ensure_lease(lease)
            else:
                # 4 所有需行动角色基于同一份处理后的世界取受限视图并提出意图
                stage = "intent"
                location_of = {cid: ch["location_id"]
                               for cid, ch in staging["characters"].items()}
                for actor_id in order:
                    ctx = ctxmod.build_context(staging, actor_id)
                    contexts[actor_id] = ctx
                    isolation[actor_id] = ctxmod.leak_scan(staging, actor_id, ctx)
                    raw = self._provider_call(f"decide/{actor_id}", self.provider.decide, ctx)
                    self._ensure_lease(lease)
                    # 校验错误带上阶段与角色：日志里要能看出是这一步的哪个角色出的问题。
                    try:
                        intents.append(
                            validate_intent(raw, actor_id, char_ids, loc_ids, location_of))
                    except ProviderSchemaError as exc:
                        raise ProviderSchemaError(
                            f"[{stage_label('decide', actor_id)}] {exc}") from exc

                # 5 固定顺序结算；复杂行动合成一次批次请求，再按序复核前置条件
                stage = "settle"
                complex_results = self._batch_settle(staging, intents, contexts, new_tick)
                self._ensure_lease(lease)
                for intent in intents:
                    staging["seq"] += 1
                    seq = staging["seq"]
                    event = self._settle_simple(staging, intent, new_tick, seq,
                                                loop["public_speech"],
                                                complex_results)
                    settlement.apply_event(staging, event)

            # 6 一个短事务写入事件、认知、资源、快照/步数、外部队列与 request_id 结果
            stage = "commit"
            stats = self.provider.take_stats()
            # 本刻各角色写下的个人状态；真正落库在下面的提交事务里。
            state_updates = {intent["actor_id"]: dict(intent.get("state_update") or {})
                             for intent in intents}
            report = self._build_report(staging, rid, order, isolation, stats, consumed,
                                        intents, contexts, state_updates)
            payload = json.dumps(report, ensure_ascii=False)
            cursor = staging["run"]["actor_cursor"]
            next_cursor = (cursor + 1) % max(len(order), 1)

            self._ensure_lease(lease)           # 心跳报告失效时，迟到结果不得提交
            lease.stop()                        # 提交阶段不再需要心跳
            lease = None

            with db.write_txn(conn):
                current = conn.execute(
                    "SELECT tick, world_revision FROM run WHERE run_id=1").fetchone()
                if current["tick"] != base_tick or current["world_revision"] != base_revision:
                    raise EngineError("提交前校验失败：有效快照已被其他写入改动")

                # 登记所有权复核：租约被别的实例接管时本次提交整体作废
                owned = conn.execute(
                    "UPDATE step_request SET tick=? WHERE request_id=? AND owner_id=?"
                    " AND status='in_progress'",
                    (new_tick, rid, self.instance_id)).rowcount
                if owned != 1:
                    raise EngineError("登记已被其他实例接管，本次提交作废")

                external_event_ids: dict[int, int] = {}
                # 世界回合自动生成的外界变化：在提交事务里才插一条**已消费**的
                # external_event（付费调用前不永久入队），再把它的事件 id 回填到
                # 事件与观察上——这样「这条观察是哪次世界回合带来的」事后可追。
                for ev in staging["new_events"]:
                    auto = ev.get("auto_external")
                    if auto and not ev.get("external_event_id"):
                        cur = conn.execute(
                            "INSERT INTO external_event(preset_key, scope, description,"
                            " payload, status, created_tick, consumed_tick, created_at)"
                            " VALUES(?,?,?,?, 'consumed', ?, ?, ?)",
                            (auto["preset_key"], auto["scope"], auto["description"],
                             json.dumps(auto.get("payload") or {}, ensure_ascii=False),
                             new_tick, new_tick, stamp))
                        ev["external_event_id"] = int(cur.lastrowid)
                        if staging.get("world_event") is ev:
                            staging["story_turn"]["auto_event_id"] = ev["external_event_id"]

                for ev in staging["new_events"]:
                    cur = conn.execute(
                        "INSERT INTO event(tick, seq, kind, actor_id, target_id, location_id,"
                        " text, success, reason, witnesses, external_event_id, created_at)"
                        " VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
                        (ev["tick"], ev["seq"], ev["kind"], ev["actor_id"], ev["target_id"],
                         ev["location_id"], ev["text"], 1 if ev["success"] else 0, ev["reason"],
                         json.dumps(ev["witnesses"]), ev["external_event_id"], stamp))
                    event_id = int(cur.lastrowid)
                    if ev["external_event_id"]:
                        external_event_ids[ev["external_event_id"]] = event_id
                    for ob in ev["observations"]:
                        conn.execute(
                            "INSERT INTO observation(owner_id, tick, content, source_type,"
                            " source_event_id, source_actor_id, first_hand, reliable, created_at)"
                            " VALUES(?,?,?,?,?,?,?,?,?)",
                            (ob["owner_id"], ob["tick"], ob["content"], ob["source_type"],
                             event_id, ob["source_actor_id"], ob["first_hand"], ob["reliable"],
                             stamp))

                # 自动外界事件与自己入队的事件共用一张表，只是它插进来就已经是
                # consumed，所以这里按 event_id 回填消费结果，不参与上面的 status='pending' 更新。
                for ev in staging["new_events"]:
                    if ev.get("auto_external") and ev.get("external_event_id"):
                        conn.execute(
                            "UPDATE external_event SET consumed_tick=?, consumed_event_id=?"
                            " WHERE event_id=?",
                            (new_tick, external_event_ids.get(ev["external_event_id"]),
                             ev["external_event_id"]))

                for cid, ch in staging["characters"].items():
                    conn.execute(
                        "UPDATE character SET location_id=?, status_text=?, updated_tick=?"
                        " WHERE id=?", (ch["location_id"], ch["status_text"], new_tick, cid))
                # 个人状态：与事件、观察在同一个事务里提交。技术失败整步回滚时
                # 这里根本不会执行，所以不会留下半截个人状态；没有任何变化则不写。
                for actor_id, update in state_updates.items():
                    merged, changed = notes_mod.merge(
                        (staging.get("notes") or {}).get(actor_id), update, new_tick)
                    if changed:
                        notes_mod.ensure_table(conn)      # 旧库兜底：缺表就补上
                        notes_mod.save(conn, actor_id, merged, stamp)
                for lid, loc in staging["locations"].items():
                    conn.execute(
                        "UPDATE location SET moment=?, state_description=? WHERE id=?",
                        (loc["moment"], loc["state_description"], lid))
                for resource in staging["resources"].values():
                    conn.execute(
                        "UPDATE resource SET location_id=?, holder_id=?, updated_tick=?"
                        " WHERE id=?",
                        (resource["location_id"], resource["holder_id"],
                         new_tick, resource["id"]))
                for item in consumed:
                    conn.execute(
                        "UPDATE external_event SET status='consumed', consumed_tick=?,"
                        " consumed_event_id=? WHERE event_id=? AND status='pending'",
                        (new_tick, external_event_ids.get(item["event_id"]), item["event_id"]))
                # 世界回合记录：与世界事件、观察、人物状态、资源、步数在同一个事务里提交。
                # 技术失败时整步回滚，因此不会留下「有局面记录、没有对应事实」的半刻。
                turn = staging.get("story_turn")
                if turn is not None:
                    story_mod.save_turn(conn, turn, stamp)
                    # 自动事件的 external_event id 只有插入之后才存在，回填进报告，
                    # 接口与页面才能顺着它查到「这条观察是哪次世界回合带来的」。
                    if report.get("story_turn") is not None:
                        report["story_turn"]["auto_event_id"] = turn.get("auto_event_id")
                        payload = json.dumps(report, ensure_ascii=False)
                conn.execute(
                    "UPDATE run SET tick=?, world_revision=?, actor_cursor=?, status='paused',"
                    " last_error=NULL, updated_at=? WHERE run_id=1",
                    (new_tick, base_revision + 1, next_cursor, stamp))
                conn.execute(
                    "UPDATE step_request SET status='committed', tick=?, result=?, error=NULL,"
                    " owner_id=NULL, heartbeat_ms=NULL, updated_at=? WHERE request_id=?",
                    (new_tick, payload, stamp, rid))
            return report
        except StepBusy:
            raise
        except EXIT_SIGNALS:
            raise
        except BaseException as exc:
            self._record_failure(rid, stage, exc, expected_revision=expected_revision)
            if isinstance(exc, (ProviderError, EngineError)) or isinstance(exc, sqlite3.Error):
                raise
            raise classify_provider_exception(exc, stage) from exc
        finally:
            if lease is not None:
                lease.stop()
            conn.close()

    # ------------------------------------------------------------------ 内部
    def _ensure_lease(self, lease: StepLease | None) -> None:
        """心跳线程报告租约失效时中止当前推进。

        检查点设在每次 provider 调用之后与提交之前：租约失效后不再发出新的
        provider 调用，已经拿到的迟到结果也不提交（提交时的所有权复核是
        最后一道闸门）。失效原因带心跳诊断信息，随 error_log 落库。
        """
        if lease is not None:
            lease.raise_if_dead()

    def _expire_stale(self, conn, now_ms: int | None = None) -> int:
        """把租约过期的在途登记标成 failed；仍在心跳的登记不动。"""
        moment = db.now_ms() if now_ms is None else now_ms
        threshold = moment - self.lease_ms
        cur = conn.execute(
            "UPDATE step_request SET status='failed', error=?, updated_at=?"
            " WHERE status='in_progress' AND (heartbeat_ms IS NULL OR heartbeat_ms <= ?)",
            (f"租约过期：{self.lease_ms}ms 内没有心跳，判定为失效登记", db.now(), threshold))
        return int(cur.rowcount)

    def _apply_external(self, staging: dict) -> list[dict]:
        consumed = []
        for ext in staging["pending_external"]:
            payload = json.loads(ext["payload"] or "{}")
            witnesses = self._scope_members(staging, ext["scope"])
            staging["seq"] += 1
            event = settlement.settle_external(
                staging, ext, payload, staging["run"]["tick"], staging["seq"], witnesses)
            settlement.apply_event(staging, event)
            consumed.append({"event_id": ext["event_id"], "preset_key": ext["preset_key"],
                             "scope": ext["scope"], "witnesses": witnesses,
                             # description/payload 一并带回：世界回合要把「本刻刚生效的
                             # 外部事件」当输入，其中 claim 仍是未核实的说法。
                             "description": ext["description"], "payload": payload})
        return consumed

    def _scope_members(self, staging: dict, scope: str) -> list[str]:
        if scope == "all":
            return sorted(staging["characters"])
        if scope.startswith("location:"):
            lid = scope.split(":", 1)[1]
            return sorted(cid for cid, ch in staging["characters"].items()
                          if ch["location_id"] == lid)
        if scope.startswith("actor:"):
            aid = scope.split(":", 1)[1]
            return [aid] if aid in staging["characters"] else []
        raise EngineError(f"未知的外部事件范围：{scope}")

    def _actor_order(self, staging: dict) -> list[str]:
        ids = sorted(staging["characters"])
        if not ids:
            return ids
        cursor = staging["run"]["actor_cursor"] % len(ids)
        return ids[cursor:] + ids[:cursor]

    # ------------------------------------------------------- 世界回合
    def _recent_events(self, conn, limit: int = WORLD_RECENT_EVENTS) -> list[dict]:
        """近几刻**已经结算**的事件（含成败与原因），按时间顺序。

        只读 event 表：这一层读到的是事实，不是打算。本刻刚生效的外部事件已经写进
        暂存世界（还没落库），由 consumed 那条通道单独给，不在这里重复。
        """
        rows = conn.execute(
            "SELECT event_id, tick, kind, actor_id, text, success, reason FROM event"
            " ORDER BY event_id DESC LIMIT ?", (int(limit),)).fetchall()
        out = [dict(row) for row in reversed(rows)]
        for ev in out:
            ev["success"] = bool(ev["success"])
        return out

    @staticmethod
    def _previous_turn(staging: dict) -> dict | None:
        """上次局面记录：只取比本刻更早的那一条。旧档第一次推进时没有，返回 None。"""
        turns = staging.get("story_turns") or {}
        tick = staging["run"]["tick"]
        earlier = [t for t in turns if t < tick]
        return turns[max(earlier)] if earlier else None

    def _world_turn(self, staging: dict, consumed: list[dict], lease, conn) -> dict:
        """一次世界回合：给出本刻局面，并按需把一件外界变化落进暂存世界。

        失败语义与技术失败一致：结构/范围错误带阶段标签上抛，本步整步回滚，
        不会留下半刻剧情，也不会留下自动事件排队。
        """
        request = story_mod.build_world_request(
            staging, self._previous_turn(staging), self._recent_events(conn), consumed)
        raw = self._provider_call("world", self.provider.world_turn, request)
        self._ensure_lease(lease)
        try:
            turn = story_mod.validate_turn(raw, staging["scenario"],
                                           set(staging["characters"]), set(staging["locations"]))
        except ProviderSchemaError as exc:
            raise ProviderSchemaError(f"[{stage_label('world_turn')}] {exc}") from exc
        turn["tick"] = staging["run"]["tick"]
        if turn.get("event"):
            staging["world_event"] = self._apply_world_event(staging, turn["event"])
        return turn

    def _apply_world_event(self, staging: dict, spec: dict) -> dict:
        """把世界回合提出的一件外界变化落进暂存世界：复用外部事件的结算与观察语义。

        说法（claim）仍然只是说法：落到人物认知里的是 reliable=0 的那一条，
        不会因为「是世界回合提出来的」就变成已证实的事实。
        """
        payload: dict = {}
        if spec.get("claim"):
            payload["claim"] = spec["claim"]
            if spec.get("claim_source_actor"):
                payload["claim_source_actor"] = spec["claim_source_actor"]
        else:
            payload["direct_observation"] = True
        if spec.get("location_changes"):
            payload["location_changes"] = spec["location_changes"]
        tick = staging["run"]["tick"]
        ext = {"event_id": None, "preset_key": WORLD_EVENT_KEY, "scope": spec["scope"],
               "description": spec["description"]}
        witnesses = self._scope_members(staging, spec["scope"])
        staging["seq"] += 1
        event = settlement.settle_external(staging, ext, payload, tick, staging["seq"], witnesses)
        event["auto_external"] = {"preset_key": WORLD_EVENT_KEY, "scope": spec["scope"],
                                  "description": spec["description"], "payload": payload,
                                  "basis": spec.get("basis") or ""}
        settlement.apply_event(staging, event)
        return event

    # ------------------------------------------------------- 结算
    @staticmethod
    def _settle_simple(staging: dict, intent: dict, tick: int, seq: int,
                       public_speech: bool, complex_results: dict | None = None) -> dict:
        """按行动类型结算：简单动作走规则，复杂行动用已经校验过的结算结果。"""
        action = intent["action"]
        if action == "wait":
            return settlement.settle_wait(staging, intent, tick, seq)
        if action == "move":
            return settlement.settle_move(staging, intent, tick, seq)
        if action == "speak":
            # 公开发言只在新运行包里开启（见 src/story.py 的 public_speech）：
            # 旧包照旧只给说话者与指定收件人。
            return settlement.settle_speak(staging, intent, tick, seq, public=public_speech)
        validated, origin = complex_results[intent["actor_id"]]
        return settlement.settle_complex(staging, intent, validated, tick, seq, origin)

    def _single_settle(self, staging: dict, intent: dict, context: dict,
                       tick: int) -> tuple[dict, str]:
        """顺序路径上的复杂行动：复用批次结算协议，但一次只送一个请求。

        上下文与允许的观察范围都按**此刻**重新取（前面的行动可能已经改变现场），
        因此「先行动者的后果」会真实影响后面这个行动的复核，而不是用旁白去补。
        """
        actor_id = intent["actor_id"]
        here = staging["characters"][actor_id]["location_id"]
        allowed = sorted(set(settlement.co_located(staging, here)) | {actor_id})
        request = {"tick": tick, "intent": intent, "context": context,
                   "allowed_witnesses": allowed,
                   "all_character_ids": sorted(staging["characters"]),
                   "world_constraints": {"rules": staging["scenario"].get("world", {}),
                       "locations": staging["locations"], "resources": staging["resources"]},
                   "actor_location": here}
        results = self._provider_call("settle_batch", self.provider.settle_batch, [request])
        if not isinstance(results, list) or len(results) != 1:
            count = len(results) if isinstance(results, list) else type(results).__name__
            raise ProviderSchemaError(
                f"[{stage_label('settle', actor_id)}] 结算条目数不符：期望 1，收到 {count}")
        try:
            validated = validate_settlement(
                results[0], intent, set(allowed), set(staging["locations"]),
                set(staging["characters"]), here, set(staging["resources"]))
        except ProviderSchemaError as exc:
            raise ProviderSchemaError(
                f"[{stage_label('settle', actor_id)}] {exc}") from exc
        return validated, here

    def _batch_settle(self, staging: dict, intents: list[dict],
                      contexts: dict[str, dict], tick: int) -> dict[str, tuple[dict, str]]:
        complex_intents = [i for i in intents if i["action"] == "act"]
        if not complex_intents:
            return {}
        requests = []
        for intent in complex_intents:
            actor_id = intent["actor_id"]
            here = staging["characters"][actor_id]["location_id"]
            allowed = sorted(set(settlement.co_located(staging, here)) | {actor_id})
            requests.append({
                "tick": tick, "intent": intent, "context": contexts[actor_id],
                "allowed_witnesses": allowed,
                "all_character_ids": sorted(staging["characters"]),
                "actor_location": here,
            })
        results = self._provider_call("settle_batch", self.provider.settle_batch, requests)
        settle_label = stage_label("settle", [i["actor_id"] for i in complex_intents])
        if not isinstance(results, list) or len(results) != len(requests):
            count = len(results) if isinstance(results, list) else type(results).__name__
            raise ProviderSchemaError(
                f"[{settle_label}] 批次结算条目数不符：期望 {len(requests)}，收到 {count}")
        out: dict[str, tuple[dict, str]] = {}
        for request, result in zip(requests, results):
            try:
                validated = validate_settlement(
                    result, request["intent"], set(request["allowed_witnesses"]),
                    set(staging["locations"]), set(staging["characters"]),
                    request["actor_location"], set(staging["resources"]))
            except ProviderSchemaError as exc:
                raise ProviderSchemaError(
                    f"[{stage_label('settle', request['intent']['actor_id'])}] {exc}") from exc
            out[request["intent"]["actor_id"]] = (validated, request["actor_location"])
        return out

    @staticmethod
    def _state_report(intents: list[dict], state_updates: dict[str, dict]) -> list[dict]:
        """个人状态更新的字段级清单：改了哪几项、忽略了哪几个没登记的字段。"""
        ignored = {intent["actor_id"]: list(intent.get("state_ignored") or [])
                   for intent in intents}
        return [{"actor_id": actor_id, "changed": sorted(update),
                 "ignored": sorted(ignored.get(actor_id) or [])}
                for actor_id, update in sorted((state_updates or {}).items())]

    def _build_report(self, staging: dict, rid: str, order: list[str],
                      isolation: dict[str, list[str]], stats: dict,
                      consumed: list[dict], intents: list[dict],
                      contexts: dict[str, dict],
                      state_updates: dict[str, dict] | None = None) -> dict:
        state_report = self._state_report(intents, state_updates or {})
        events = []
        for ev in staging["new_events"]:
            item = {k: v for k, v in ev.items()
                    if k not in ("observations", "auto_external")}
            item["visibility"] = _visibility_note(staging, ev["witnesses"])
            item["witness_names"] = [staging["characters"][w]["name"]
                                     for w in ev["witnesses"] if w in staging["characters"]]
            item["observation_count"] = len(ev["observations"])
            if ev.get("auto_external"):
                item["auto_external"] = dict(ev["auto_external"])
            events.append(item)
        return {
            "request_id": rid,
            "tick": staging["run"]["tick"],
            "mode": self.provider.mode,
            "provider": provider_view(self.provider),
            "owner_id": self.instance_id,
            "order": order,
            "intents": intents,
            "events": events,
            "observations_created": sum(len(ev["observations"]) for ev in staging["new_events"]),
            "display_text": format_display(staging, events),
            "consumed_external_events": consumed,
            "resources": [
                {"id": r["id"], "name": r["name"], "location_id": r["location_id"],
                 "holder_id": r["holder_id"]}
                for r in sorted(staging["resources"].values(), key=lambda item: item["id"])],
            "isolation": isolation,
            "probes": probe_report(staging, contexts),
            # 本刻各角色写下的个人状态（字段级）：本刻就会落库，下一轮决策读回。
            "state_updates": state_report,
            # 世界回合（只有打开 story_loop 的包才有）：本刻局面与零或一件外界变化。
            "story_turn": story_mod.turn_view(staging.get("story_turn")),
            "story_loop": story_mod.loop_config(staging["scenario"]),
            "accounting": stats,
            "deduped": False,
        }

    def _record_failure(self, rid: str, stage: str, exc: BaseException,
                        expected_revision: int | None = None) -> None:
        """收尾：只处理仍属本实例、尚未提交的登记。

        已提交的请求与 run 状态都不动（提交后迟到的异常不得改写已提交结果）；
        世界版本已被别的推进改动时也不改 run 状态。
        落库前统一过一遍密钥擦除：provider 是自己擦过的，这里兜住未归一的异常文本。
        """
        if isinstance(exc, sqlite3.Error):
            error_type = "sqlite"
        else:
            error_type = getattr(exc, "error_type", type(exc).__name__)
        stamp = db.now()
        conn = db.connect(self.db_path)
        try:
            row = conn.execute("SELECT status FROM step_request WHERE request_id=?",
                               (rid,)).fetchone()
            if row is not None and row["status"] == "committed":
                return
            with db.write_txn(conn):
                cur = conn.execute(
                    "UPDATE step_request SET status='failed', error=?, updated_at=?"
                    " WHERE request_id=? AND status='in_progress' AND owner_id=?",
                    (scrub_secrets(str(exc)), stamp, rid, self.instance_id))
                if cur.rowcount == 1:
                    conn.execute(
                        "UPDATE run SET status='error', last_error=?, updated_at=?"
                        " WHERE run_id=1 AND (? IS NULL OR world_revision=?)",
                        (scrub_secrets(f"[{stage}/{error_type}] {exc}"), stamp,
                         expected_revision, expected_revision))
                    message = scrub_secrets(str(exc))
                else:
                    message = scrub_secrets(
                        f"（登记已不属于本实例或已失效，未改动状态）{exc}")
                conn.execute(
                    "INSERT INTO error_log(request_id, tick, stage, error_type, message,"
                    " created_at) VALUES(?,?,?,?,?,?)",
                    (rid, None, stage, error_type, message, stamp))
        except sqlite3.Error:
            pass
        finally:
            conn.close()

    # ------------------------------------------------------------------ 查询
    def get_result(self, request_id: str) -> dict:
        rid = _normalize_request_id(request_id)
        conn = db.connect(self.db_path)
        try:
            from . import chapter_store
            if chapter_store.exists(conn):
                chapter = conn.execute("SELECT * FROM chapter_request WHERE request_id=?", (rid,)).fetchone()
                if chapter is not None:
                    result = json.loads(chapter["result"]) if chapter["result"] else None
                    return {"request_id": rid, "tick": chapter["tick"], "status": chapter["status"],
                            "error": chapter["error"], "result": result, "engine_mode": "chapters"}
            row = conn.execute(
                "SELECT * FROM step_request WHERE request_id=?", (rid,)).fetchone()
            if row is None:
                raise EngineError(f"没有这个 request_id 的记录：{rid}")
            result = json.loads(row["result"]) if row["result"] else None
            if result is not None:
                result["deduped"] = True
            return {"request_id": rid, "tick": row["tick"], "status": row["status"],
                    "error": row["error"], "result": result}
        finally:
            conn.close()

    def get_state(self) -> dict:
        conn = db.connect(self.db_path)
        try:
            staging = self.load_staging(conn)
            events = [dict(row) for row in conn.execute(
                "SELECT event_id, tick, seq, kind, actor_id, target_id, location_id, text,"
                " success, reason, witnesses, external_event_id FROM event"
                " ORDER BY event_id DESC LIMIT 40")]
            events.reverse()
            for ev in events:
                ev["witnesses"] = json.loads(ev["witnesses"] or "[]")
                ev["visibility"] = _visibility_note(staging, ev["witnesses"])
                ev["success"] = bool(ev["success"])
            contexts, isolation = {}, {}
            for actor_id in sorted(staging["characters"]):
                ctx = ctxmod.build_context(staging, actor_id)
                contexts[actor_id] = ctx
                isolation[actor_id] = ctxmod.leak_scan(staging, actor_id, ctx)
            observations = {
                owner: [{k: v for k, v in ob.items() if k != "source_event"}
                        for ob in items[-12:]]
                for owner, items in staging["observations"].items()
            }
            from . import chapter_store
            chapter_requests = ([] if not chapter_store.exists(conn) else
                [self._request_view(row) for row in conn.execute(
                    "SELECT request_id,tick,status,error,owner_id,heartbeat_ms,updated_at"
                    " FROM chapter_request ORDER BY updated_at DESC LIMIT 8")])
            return {
                "mode": self.provider.mode,
                "provider": provider_view(self.provider),
                # 场景快照里记录的 provider_mode：换 provider 启动时会与当前模式不同，
                # 两个值都给出，避免界面把「这次实际在用谁」和「初始化时记了什么」混为一谈。
                "scenario_provider_mode": staging["run"]["provider_mode"],
                "scenario": {
                    "id": staging["scenario"]["scenario_id"],
                    "version": staging["scenario"]["version"],
                    "title": staging["scenario"].get("title", ""),
                    "summary": staging["scenario"].get("summary", ""),
                },
                "run": staging["run"],
                # 剧情体验改造：这一档是不是走世界回合/顺序行动/公开发言，以及最近几条局面。
                # 只读诊断用；旧档没有 story_loop 就是全关，story_turns 为空。
                "story_loop": story_mod.loop_config(staging["scenario"]),
                "story_turns": [staging["story_turns"][t]
                                for t in sorted(staging["story_turns"])[-8:]],
                "locations": list(staging["locations"].values()),
                "characters": list(staging["characters"].values()),
                "resources": list(staging["resources"].values()),
                "events": events,
                "pending_external": [
                    {"event_id": ext["event_id"], "preset_key": ext["preset_key"],
                     "scope": ext["scope"], "description": ext["description"],
                     "created_tick": ext["created_tick"]}
                    for ext in staging["pending_external"]],
                "presets": [
                    {"key": p["key"], "label": p.get("label", p["key"]),
                     "scope": p["scope"], "description": p.get("description", "")}
                    for p in staging["scenario"].get("presets", [])],
                "requests": [self._request_view(row) for row in conn.execute(
                    "SELECT request_id, tick, status, error, owner_id, heartbeat_ms, updated_at"
                    " FROM step_request ORDER BY tick DESC, updated_at DESC LIMIT 8")] + chapter_requests,
                "last_committed_request": (
                    lambda row: row["request_id"] if row is not None else None)(
                        conn.execute("SELECT request_id FROM step_request"
                                     " WHERE status='committed' ORDER BY tick DESC LIMIT 1")
                        .fetchone()),
                "errors": [dict(row) for row in conn.execute(
                    "SELECT error_id, request_id, stage, error_type, message, created_at"
                    " FROM error_log ORDER BY error_id DESC LIMIT 6")],
                "lease": {"lease_ms": self.lease_ms, "heartbeat_ms": self.heartbeat_ms,
                          "instance_id": self.instance_id},
                "contexts": contexts,
                "isolation": isolation,
                "probes": probe_report(staging, contexts),
            }
        finally:
            conn.close()

    def _request_view(self, row) -> dict:
        view = dict(row)
        view["lease_alive"] = (row["status"] == "in_progress"
                               and lease_alive(row["heartbeat_ms"], db.now_ms(), self.lease_ms))
        view["lease_age_ms"] = (None if row["heartbeat_ms"] is None
                                else db.now_ms() - int(row["heartbeat_ms"]))
        return view

    # ------------------------------------------------------------------ 运维
    def recover(self) -> dict:
        """把运行错误状态清回可继续；只清理租约确实过期的在途登记。

        仍在推进（心跳有效）的请求不会被释放：恢复接口不能解除并发闸门。
        """
        stamp = db.now()
        conn = db.connect(self.db_path)
        try:
            with db.write_txn(conn):
                cleared = self._expire_stale(conn)
                conn.execute(
                    "UPDATE run SET status='paused', last_error=NULL, updated_at=?"
                    " WHERE run_id=1 AND status!='ended'", (stamp,))
            state = conn.execute("SELECT tick, status FROM run WHERE run_id=1").fetchone()
            return {"tick": state["tick"], "status": state["status"], "cleared": cleared,
                    "lease_ms": self.lease_ms,
                    "rule": "只清理心跳超过租约时长的登记；仍在推进的请求不会被释放"}
        finally:
            conn.close()

    def reset_stale_on_start(self) -> int:
        """启动清理遵守同一规则：只清理租约过期的登记。

        另一进程正在推进时心跳是新的，因此这里不会误清理它的请求。
        """
        conn = db.connect(self.db_path)
        try:
            with db.write_txn(conn):
                return self._expire_stale(conn)
        finally:
            conn.close()
