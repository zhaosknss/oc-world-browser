"""DeepSeek 官方 API 适配器（最小实现，OpenAI 兼容协议）。

官方依据（2026-09-16 查阅，链接与原文摘要见 docs/最小官方API接入结果.md）：
- https://api-docs.deepseek.com/                      OpenAI 兼容；base_url `https://api.deepseek.com`；
                                                     模型 `deepseek-flash` / `deepseek-v4-pro`；
                                                     认证 `Authorization: Bearer ${DEEPSEEK_API_KEY}`
- https://api-docs.deepseek.com/guides/json_mode      `response_format={'type':'json_object'}`；
                                                     提示词里必须出现 "json" 并给出格式示例；
                                                     要设 `max_tokens` 防止截断；偶发空响应
- https://api-docs.deepseek.com/quick_start/error_codes  400/401/402/422/429/500/503
- https://api-docs.deepseek.com/quick_start/rate_limit   并发超限返回 429；非流式请求等待期间会
                                                     持续返回空行；10 分钟未开始推理服务端断开

三条刻意的设计取舍（对应任务第 1、3 条与定向修复第 1 条）：

1. **不用 openai SDK**。SDK 默认 `max_retries=2`，自动重试 connection error / 408 / 409 / 429 /
   >=500，并且「超时的请求默认再重试两次」（见其 README「Retries / Timeouts」）。任务要求首版
   关闭「不明确是否已被受理请求的自动重发」，SDK 的默认行为正相反。因此这里用标准库
   `http.client` 直接发一次请求：`MAX_ATTEMPTS = 1`，连接/读取/总体期限自己给，失败按类上抛。
   若以后要换 SDK，必须显式 `max_retries=0`。

2. **不使用远端幂等**。官方文档没有为 `/chat/completions` 定义幂等键；本地 request_id 与
   `x-request-id` 都只是引用，不等于服务端去重。因此不承诺远端 exactly-once；失败一律交用户
   显式处理，并提示「手动重试也可能重复计费」。

3. **`total_timeout_s` 是墙钟截止时间，不是套接字读超时**。套接字读超时只管「静默期」：
   服务端持续吐字节（慢速 Content-Length、慢速 chunked、空行保活）会把计时器不断清零，
   整体等待可以远超期限。所以这里用单调时钟算出 deadline，`_DeadlineGuard` 到点强制关闭
   本地连接，并在连接/发送/响应头/响应体每个阶段边界复核期限。
   边界要说清：**停掉本地等待 ≠ 服务端停止推理或停止计费**，本地无从确认远端状态。

采样参数（`thinking` / `reasoning_effort` / `temperature`）的实际下发规则见
`DeepSeekProvider._apply_sampling`，`describe()["sampling"]` 与真实请求走同一段判断。

角色输入始终是 `src/context.py` 构造的受限数据对象，这里只做序列化，不额外注入世界状态。
"""
from __future__ import annotations

import json
import os
import socket
import threading
import time
from http.client import (HTTPConnection, HTTPSConnection, HTTPException,
                         IncompleteRead, RemoteDisconnected)
from urllib.parse import urlsplit

from .prompt_layout import render_payload

from .models import (ACTOR_FIELD_TYPES, EXIT_SIGNALS, LOCATION_FIELD_TYPES,
                     REQUIRE_TYPES, RESOURCE_ACTIONS, VALID_ACTIONS,
                     ProviderAuthError, ProviderConfigError, ProviderEmptyResponse,
                     ProviderError, ProviderInvalidOutput, ProviderNetworkError,
                     ProviderQuotaError, ProviderRateLimit, ProviderRequestRejected,
                     ProviderSchemaError, ProviderServiceError, ProviderTimeout,
                     ProviderTruncated, register_secret_scrubber, stage_label)

DEFAULT_BASE_URL = "https://api.deepseek.com"
DEFAULT_MODEL = "deepseek-flash"
DEFAULT_CHAT_PATH = "/chat/completions"

API_KEY_ENV = "DEEPSEEK_API_KEY"
CONFIG_PATH_ENV = "DEEPSEEK_CONFIG"
DEFAULT_CONFIG_PATH = os.path.join("local-data", "deepseek-api", "config.json")

# 首版固定为 1：一次调用只发一次 HTTP 请求，失败不自动重发。
MAX_ATTEMPTS = 1

# 官方《思考模式》文档（2026-09-16 查阅）：
#   思考模式默认打开，effort 默认 high；开关 {"thinking": {"type": "enabled/disabled"}}；
#   强度 {"reasoning_effort": "low/high/max"}；
#   思考模式不支持 temperature / presence_penalty / frequency_penalty —— 设置不报错但不生效；
#   top_p 在思考模式生效（下限 0.95），非思考模式恒为 1.0 并忽略传入值。
# 因此这里：thinking 默认 enabled 且显式下发；启用时不下发 temperature（发了也不生效，会误导）；
# 关闭时才按配置下发 temperature；temperature=0 只是采样参数，不构成确定性保证。
THINKING_VALUES = ("enabled", "disabled")
REASONING_EFFORT_VALUES = ("low", "high", "max")

DEFAULTS = {
    "base_url": DEFAULT_BASE_URL,
    "model": DEFAULT_MODEL,
    "chat_path": DEFAULT_CHAT_PATH,
    "connect_timeout_s": 10.0,
    "read_timeout_s": 120.0,
    "total_timeout_s": 180.0,
    "max_tokens": 2048,
    "settle_max_tokens": 4096,
    # 正文一段通常比一次决策长，但远短于整批结算：单给一个预算，避免拿结算预算写正文。
    "narrate_max_tokens": 2048,
    # 事件理解只要一个很小的 json（范围 + 一句描述），给小预算就够。
    "interpret_max_tokens": 1024,
    # 世界回合（见 src/story.py）只要一段短局面加零点或一件外界变化，独立给预算：
    # 它既不该拿结算的预算，也不该被决策的预算挤掉。
    "world_max_tokens": 1024,
    "chapter_max_tokens": 16384,
    "prepare_chapters": 2,
    "thinking": "enabled",       # 保持官方默认；显式下发
    "reasoning_effort": None,    # None = 不下发，用服务端默认（high）
    "temperature": 1.0,          # 官方默认值；只在 thinking=disabled 时下发
}

# 环境变量覆盖项：值为字符串，加载时按类型转换。
ENV_KEYS = {
    "DEEPSEEK_BASE_URL": ("base_url", str),
    "DEEPSEEK_MODEL": ("model", str),
    "DEEPSEEK_CHAT_PATH": ("chat_path", str),
    "DEEPSEEK_CONNECT_TIMEOUT_S": ("connect_timeout_s", float),
    "DEEPSEEK_READ_TIMEOUT_S": ("read_timeout_s", float),
    "DEEPSEEK_TOTAL_TIMEOUT_S": ("total_timeout_s", float),
    "DEEPSEEK_MAX_TOKENS": ("max_tokens", int),
    "DEEPSEEK_SETTLE_MAX_TOKENS": ("settle_max_tokens", int),
    "DEEPSEEK_NARRATE_MAX_TOKENS": ("narrate_max_tokens", int),
    "DEEPSEEK_INTERPRET_MAX_TOKENS": ("interpret_max_tokens", int),
    "DEEPSEEK_WORLD_MAX_TOKENS": ("world_max_tokens", int),
    "DEEPSEEK_CHAPTER_MAX_TOKENS": ("chapter_max_tokens", int),
    "DEEPSEEK_THINKING": ("thinking", str),
    "DEEPSEEK_REASONING_EFFORT": ("reasoning_effort", str),
    "DEEPSEEK_TEMPERATURE": ("temperature", float),
}

# HTTP 状态码 → 异常。官方文档给出的全部错误码都在这里，未列出的按 4xx/5xx 兜底。
STATUS_ERRORS = {
    400: (ProviderRequestRejected, "400 请求格式无效（Invalid Format）"),
    401: (ProviderAuthError, "401 认证失败（API key 不正确）"),
    402: (ProviderQuotaError, "402 余额不足"),
    422: (ProviderRequestRejected, "422 参数无效（Invalid Parameters）"),
    429: (ProviderRateLimit, "429 触发限流（并发超限）"),
    500: (ProviderServiceError, "500 服务端错误"),
    503: (ProviderServiceError, "503 服务端过载"),
}
NO_RESEND_HINT = "首版不自动重发；确认后显式重试也可能重复计费。"
# 期限到点必须交代清楚的边界：本地停手 ≠ 远端停手。
DEADLINE_BOUNDARY = ("本地已停止等待并关闭连接；服务端可能仍在推理、仍会计费，"
                     "本地无从确认。")


def _redact(text: str, secret: str | None) -> str:
    """把密钥从任意文本里抹掉；密钥为空或过短时只在明显出现时替换。"""
    out = text if isinstance(text, str) else str(text)
    if secret and len(secret) >= 6 and secret in out:
        out = out.replace(secret, "***")
    return out


class _DeadlineGuard:
    """把「总体调用期限」变成真正的墙钟约束，而不是一次性的套接字读超时。

    只用套接字读超时是不够的：它是**静默期**超时，服务端只要持续吐字节
    （慢速 Content-Length、慢速 chunked、空行保活），每次读到数据就把计时器
    清零，整体等待可以远超 total_timeout_s。

    这个守卫做两件事：

    1. 按单调时钟起一个 `threading.Timer`，到点强制 `shutdown` + `close`
       本地套接字，让卡在阻塞读上的调用立刻返回；
    2. 暴露 `expired`，让调用方在**每个阶段边界**（连接后、发送后、拿到响应头后、
       读完响应体后）复核期限，避免「阻塞调用恰好在期限之后返回」被当作成功。

    诚实边界：`shutdown` 只能让本地的阻塞系统调用提前返回，**不能**让服务端停止
    推理，也不停止计费；对不碰套接字的阻塞调用（异常实现）只能在它返回后才能发现。
    """

    def __init__(self, deadline: float):
        self.deadline = deadline
        self.fired = False
        self._conn = None
        self._timer: threading.Timer | None = None

    def attach(self, conn) -> None:
        """挂上连接并启动到点强制关闭。期限已过则立刻关，不启动定时器。"""
        self._conn = conn
        remaining = self.deadline - time.monotonic()
        if remaining <= 0:
            self.fired = True
            self._force_close()
            return
        self._timer = threading.Timer(remaining, self._on_fire)
        self._timer.daemon = True
        self._timer.start()

    @property
    def expired(self) -> bool:
        return self.fired or time.monotonic() >= self.deadline

    def remaining(self) -> float:
        return self.deadline - time.monotonic()

    def _on_fire(self) -> None:
        self.fired = True
        self._force_close()

    def _force_close(self) -> None:
        conn, self._conn = self._conn, None
        if conn is None:
            return
        try:
            sock = getattr(conn, "sock", None)
            if sock is not None and hasattr(sock, "shutdown"):
                try:
                    sock.shutdown(socket.SHUT_RDWR)
                except OSError:
                    pass
        except Exception:                                  # noqa: BLE001 - 收尾不能抛
            pass
        try:
            conn.close()
        except Exception:                                  # noqa: BLE001
            pass

    def cancel(self) -> None:
        if self._timer is not None:
            self._timer.cancel()
            self._timer = None



def load_config(options: dict | None = None, env: dict | None = None,
                root: str | None = None) -> dict:
    """按「内置默认 ← 本地配置文件 ← 环境变量 ← 显式 options」的顺序取配置。

    密钥只从环境变量或被忽略的本地配置文件读；显式 options 仅供测试注入。
    返回的字典额外带 `api_key_source`，用来在界面上说明密钥来自哪里（不含密钥本身）。
    """
    env = os.environ if env is None else env
    root = root or os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

    cfg = dict(DEFAULTS)
    key = None
    key_source = None

    path = env.get(CONFIG_PATH_ENV) or os.path.join(root, DEFAULT_CONFIG_PATH)
    if not os.path.isabs(path):
        path = os.path.join(root, path)
    if os.path.isfile(path):
        try:
            with open(path, "r", encoding="utf-8") as fh:
                file_cfg = json.load(fh)
        except (OSError, json.JSONDecodeError) as exc:
            raise ProviderConfigError(
                f"本地配置文件无法读取或不是合法 JSON：{exc}（配置文件：{path}）") from exc
        if not isinstance(file_cfg, dict):
            raise ProviderConfigError(f"本地配置必须是 JSON 对象：{path}")
        for name, value in file_cfg.items():
            if name == "api_key":
                if isinstance(value, str) and value.strip():
                    key = value.strip()
                    key_source = "配置文件"
                continue
            if name in cfg:
                cfg[name] = value
        cfg["_config_path"] = path

    for env_name, (field, cast) in ENV_KEYS.items():
        raw = env.get(env_name)
        if raw is None or not str(raw).strip():
            continue
        try:
            cfg[field] = cast(str(raw).strip())
        except (TypeError, ValueError) as exc:
            raise ProviderConfigError(f"环境变量 {env_name} 不是合法的 {cast.__name__}：{raw!r}") from exc

    env_key = env.get(API_KEY_ENV)
    if env_key and str(env_key).strip():
        key = str(env_key).strip()
        key_source = f"环境变量 {API_KEY_ENV}"

    for name, value in (options or {}).items():
        if name == "api_key":
            key = str(value).strip() if value else None
            key_source = "显式传入"
        elif name in cfg:
            cfg[name] = value

    if not key:
        raise ProviderConfigError(
            f"未配置 API 密钥：请设置环境变量 {API_KEY_ENV}，"
            f"或在被忽略的本地文件 {DEFAULT_CONFIG_PATH} 里写 {{\"api_key\": \"...\"}}"
            "（不要写进场景、前端或交接文档）")

    cfg["api_key"] = key
    cfg["api_key_source"] = key_source
    _validate(cfg)
    return cfg


def _validate(cfg: dict) -> None:
    if type(cfg["prepare_chapters"]) is not int or cfg["prepare_chapters"] not in (1, 2):
        raise ProviderConfigError("prepare_chapters 必须为 1 或 2")
    parsed = urlsplit(str(cfg["base_url"]))
    if parsed.scheme not in ("http", "https") or not parsed.hostname:
        raise ProviderConfigError(f"base_url 不合法（需要 http/https 绝对地址）：{cfg['base_url']!r}")
    if not str(cfg["model"]).strip():
        raise ProviderConfigError("model 不能为空")
    for field in ("connect_timeout_s", "read_timeout_s", "total_timeout_s"):
        value = cfg[field]
        if not isinstance(value, (int, float)) or isinstance(value, bool) or value <= 0:
            raise ProviderConfigError(f"{field} 必须是正数：{value!r}")
    for field in ("max_tokens", "settle_max_tokens", "narrate_max_tokens", "chapter_max_tokens",
                  "interpret_max_tokens", "world_max_tokens"):
        value = cfg[field]
        if not isinstance(value, int) or isinstance(value, bool) or value <= 0:
            raise ProviderConfigError(f"{field} 必须是正整数：{value!r}")
    if cfg["thinking"] not in THINKING_VALUES:
        raise ProviderConfigError(
            f"thinking 只能是 {' / '.join(THINKING_VALUES)}（官方开关取值），收到：{cfg['thinking']!r}")
    effort = cfg["reasoning_effort"]
    if effort is not None and effort not in REASONING_EFFORT_VALUES:
        raise ProviderConfigError(
            f"reasoning_effort 只能是 {' / '.join(REASONING_EFFORT_VALUES)} 或省略，收到：{effort!r}")
    temperature = cfg["temperature"]
    if temperature is not None:
        if (not isinstance(temperature, (int, float)) or isinstance(temperature, bool)
                or not 0 <= float(temperature) <= 2):
            raise ProviderConfigError(f"temperature 必须在 0–2 之间或省略，收到：{temperature!r}")


# --------------------------------------------------------------------------- 提示词
#
# 协议与校验器必须同源：下面用到的枚举、字段清单直接取自 src/models.py 的校验常量，
# 示例则是「可校验示例」——tests/test_settlement_protocol.py 会把它们原样交给真正的
# validate_settlement 校验。上一轮结算失败的成因就是两处各写一份：提示词里 requires
# 只有 []，模型只能猜字段名，猜错就被校验器判为「未知前置条件类型：None」，整步回滚。

# 角色决策的协议。行动枚举取自 src/models.py 的 VALID_ACTIONS，避免两处各写一份。
# 另外明说「只输出这一个 json 对象」：思考模式下推理内容同样占用 completion，
# 输出越啰嗦越容易撞上 max_tokens 截断（截断被判为 truncated，不当作有效输出）。
DECIDE_SYSTEM = """你在一个文字世界里扮演角色「{name}」，为它决定这一刻要做什么。
只依据用户提供的受限上下文 json 行动；上下文里没有出现的角色心理、状态或消息，
一律视为该角色不知情，不得使用。

只输出一个 json 对象，不要输出解释、不要用 markdown 代码块，也不要在 json 之外写任何
分析或说明文字。格式：
{{
  "actor_id": "{actor_id}",
  "action": "{actions}",
  "target": null,
  "tone": null,
  "text": null,
  "state": {{
    "focus": "你此刻在意的事、短期打算；没有变化就写空字符串",
    "situation": "你对当前处境的理解；没有变化就写空字符串",
    "lessons": "你试过什么、什么有用什么没用；没有变化就写空字符串",
    "pending": "你还没做完的事；没有变化就写空字符串"
  }}
}}

字段规则：
- action:"wait" 不带 target/text，表示原地待机。
- action:"move" 的 target 必须是上下文中 location.connections 里的地点 id。
- action:"speak" 的 target 必须是 present 里的人 id，text 是要说的话。
- action:"act" 的 target 是这一复杂行动的简短描述（字符串），text 可为 null。
  复杂行动由引擎的批次结算判定成败，你只负责声明想做什么。
- tone 是你这一刻语气的一两个词（例如「压着火」「急着赶工」「没底气」）。
  它只是你自己的一个注记，**不会**改变世界，也不会被别人看到；不想写就写 null。

state 是你自己写下的那一层，会保存下来，下一次决策时原样回到你的输入里：
- 它是**你自己的理解与打算**，不是世界事实，也可以判断错；不要把它写成别人知道的事。
- focus / pending 是**还没做的**事，不要写成已经做成；
  这一刻行动的结果你还没有看到，不要预先把它写成已经成功。
- 只写自己确实经历过或观察到的事；上下文里没有的，不要当成自己知道的。
- 想继续原来的打算、继续等、换一个办法、暂时退开，都可以。没有必须换招这回事。
- 每项一句话以内，不要写推理过程。与上次相同、或这一项没变化，就写 ""，
  引擎会沿用你之前写下的内容。
- 不要用 state 复述人设、世界设定或别人的信息。

示例（json 输出）：
{{"actor_id": "{actor_id}", "action": "move", "target": "hall", "tone": "急着弄清是谁在说话", "text": null,
 "state": {{"focus": "想弄清走廊里那句话是谁说的", "situation": "屋里的人不愿意多讲",
           "lessons": "直接问没有问出东西", "pending": "还没找到那个说话的人"}}}}

没有把握的时候不是只有一条路：可以先看、先试一步、找在场的人搭话或搭手、暂时退开，也可以等一等
——选哪一种取决于你自己的利益和眼前知道的事。等了不作废，出手也不必等到十成把握。
唯一会被引擎判为无效、整步回滚的，是编造上下文里不存在的地点或人物。"""


def build_decide_system(name: str, actor_id: str) -> str:
    """渲染角色决策协议；行动枚举取自 src/models.py 的 VALID_ACTIONS。"""
    return DECIDE_SYSTEM.format(name=name, actor_id=actor_id,
                                actions=" | ".join(VALID_ACTIONS))

# 示例里的占位符：`<>` 里是说明文字，不是要照抄的字符串。
PLACEHOLDERS = {
    "actor": "<本人 actor_id>",
    "witness": "<allowed_witnesses 里的角色 id>",
    "resource": "<资源 id>",
    "resource_name": "<资源名称>",
    "location": "<本人所在地点 id>",
    "state": "<context.location.state_description 的原文>",
}

SETTLE_PROTOCOL_EXAMPLES: list[dict] = [
    {
        "title": "拿取一件资源",
        "note": ("它此刻没有人拿着、就放在本人所在地点：requires 用 holder_id=null 与 "
                 "location_id=本人所在地点 把这件事说清楚，resource_actions 再写 take。"),
        "result": {
            "actor_id": PLACEHOLDERS["actor"],
            "success": True,
            "reason": "它就在地上，也没有人拿着",
            "fact_text": "{name}捡起了" + PLACEHOLDERS["resource_name"],
            "witnesses": [PLACEHOLDERS["actor"], PLACEHOLDERS["witness"]],
            "actor_changes": {"status_text": "手里多了" + PLACEHOLDERS["resource_name"]},
            "location_changes": {},
            "requires": [{"type": "resource_state",
                          "resource_id": PLACEHOLDERS["resource"],
                          "holder_id": None,
                          "location_id": PLACEHOLDERS["location"]}],
            "resource_actions": [{"action": "take",
                                  "resource_id": PLACEHOLDERS["resource"]}],
        },
    },
    {
        "title": "放下手里的资源",
        "note": ("只有本人手里有它时才能放下：requires 用 holder_id=本人 actor_id 说明这一点，"
                 "resource_actions 再写 drop。放下之后它回到本人所在地点。"),
        "result": {
            "actor_id": PLACEHOLDERS["actor"],
            "success": True,
            "reason": "他决定把它放回原处",
            "fact_text": "{name}放下了" + PLACEHOLDERS["resource_name"],
            "witnesses": [PLACEHOLDERS["actor"], PLACEHOLDERS["witness"]],
            "actor_changes": {},
            "location_changes": {},
            "requires": [{"type": "resource_state",
                          "resource_id": PLACEHOLDERS["resource"],
                          "holder_id": PLACEHOLDERS["actor"]}],
            "resource_actions": [{"action": "drop",
                                  "resource_id": PLACEHOLDERS["resource"]}],
        },
    },
    {
        "title": "行动依赖现场状态",
        "note": ("这次行动只在现场仍处于某个状态时成立：把 context.location.state_description "
                 "的原文逐字抄进 equals（校验是全等比较，改写或概括都会判为条件不成立）。"
                 "reason 里写的状态必须与 equals 指的是同一个状态。"),
        "result": {
            "actor_id": PLACEHOLDERS["actor"],
            "success": True,
            "reason": "现场条件仍然满足",
            "fact_text": "{name}趁着现场的条件把这件事做成了",
            "witnesses": [PLACEHOLDERS["actor"]],
            "actor_changes": {},
            "location_changes": {"state_description": "现场被这次行动改变了"},
            "requires": [{"type": "location_state",
                          "location_id": PLACEHOLDERS["location"],
                          "equals": PLACEHOLDERS["state"]}],
            "resource_actions": [],
        },
    },
    {
        "title": "行动不成立（合法失败）",
        "note": ("判定不成立时 success=false、reason 写清为什么不成立、fact_text 写成一次没成的"
                 "尝试；actor_changes、location_changes、resource_actions 必须留空，requires 也留空。"
                 "世界内失败是正常结果，不会让本次推进作废。"),
        "result": {
            "actor_id": PLACEHOLDERS["actor"],
            "success": False,
            "reason": "门从外面锁住了，推不开",
            "fact_text": "{name}试着推门，门没有开",
            "witnesses": [PLACEHOLDERS["actor"]],
            "actor_changes": {},
            "location_changes": {},
            "requires": [],
            "resource_actions": [],
        },
    },
]


def render_settle_examples() -> str:
    """把可校验示例渲染成提示词里的示例段落（提示词与测试用的是同一份）。"""
    blocks = []
    for index, example in enumerate(SETTLE_PROTOCOL_EXAMPLES, start=1):
        blocks.append(f"示例 {index}：{example['title']}\n{example['note']}\n"
                      + json.dumps(example["result"], ensure_ascii=False, indent=2))
    return "\n\n".join(blocks)


def resolve_settle_examples(values: dict) -> list[dict]:
    """把示例里的占位符换成真实 id，得到可直接交给 validate_settlement 的结果对象。

    values 必须给全 PLACEHOLDERS 的每个键；缺一个就报错，不允许留下未解析的占位符
    ——那样「示例能过校验」就成了假结论。
    """
    missing = sorted(set(PLACEHOLDERS) - set(values))
    if missing:
        raise KeyError(f"示例占位符未给全：{missing}")

    def replace(node):
        if isinstance(node, str):
            for name, token in PLACEHOLDERS.items():
                node = node.replace(token, str(values[name]))
            return node
        if isinstance(node, list):
            return [replace(item) for item in node]
        if isinstance(node, dict):
            return {key: replace(value) for key, value in node.items()}
        return node

    return [{"title": example["title"], "note": example["note"],
             "result": replace(example["result"])}
            for example in SETTLE_PROTOCOL_EXAMPLES]


def build_settle_system() -> str:
    """渲染发给模型的结算协议。

    枚举与字段清单取自 src/models.py 的校验常量，示例取自 SETTLE_PROTOCOL_EXAMPLES
    （`render_settle_examples`）——校验器改了枚举，提示词跟着变，不需要两处对齐。
    """
    require_types = " / ".join(REQUIRE_TYPES)
    resource_actions = " / ".join(RESOURCE_ACTIONS)
    actor_fields = "、".join(sorted(ACTOR_FIELD_TYPES))
    location_fields = "、".join(sorted(LOCATION_FIELD_TYPES))
    lines = [
        "你在一个文字世界里担任规则裁定者，判定若干复杂行动是否成立。",
        "只依据每个请求给出的受限上下文与行动声明判断，不得引入上下文之外的事实。",
        "",
        "只输出一个 json 对象，不要输出解释、不要用 markdown 代码块。格式：",
        "{",
        '  "results": [',
        "    {",
        '      "actor_id": "与对应 intent 相同的角色 id",',
        '      "success": true,',
        '      "reason": "简短原因；success 为 false 时说明为什么不成立",',
        '      "fact_text": "第三人称、可直接展示的既成事实描述；用 {name} 指代本人",',
        '      "witnesses": ["能感知到这件事的角色 id"],',
        '      "actor_changes": {"status_text": "本人状态的一句新描述"},',
        '      "location_changes": {"state_description": "本人所在地点状态的一句新描述"},',
        '      "requires": [],',
        '      "resource_actions": []',
        "    }",
        "  ]",
        "}",
        "results 的条数、顺序必须与请求里的 requests 完全一致；expected_result_count 就是应有条数。",
        "",
        "字段与取值（枚举必须逐字使用；写法不对会被引擎拒绝，本次推进整步回滚）：",
        "- success 是布尔；reason、fact_text 是非空字符串。",
        "- witnesses 只能取该请求 allowed_witnesses 里的角色 id，越界会被拒绝。",
        f"- actor_changes 允许的键只有 {actor_fields}；location_changes 允许的键只有 "
        f"{location_fields}；值都必须是非空字符串（不接受 null、数字、数组、对象）。",
        "- location_changes 作用在本人所在地点上，不要用它去改别的地点的现场。",
        "- fact_text 里写 {name} 会替换成本人姓名；不要用别的占位符（引擎只替换这一个）。",
        "- 只引用该请求上下文里出现过的 id：资源见 context.location.resources 与",
        "  context.self.carried_resources，地点见 context.location，人物见 context.present 与",
        "  allowed_witnesses。上下文里没有的 id 一律不要写，也不要凭推测补全。",
        "  这条只约束**结构化的 id**（resource_id / location_id / holder_id 与人物 id）。",
        "  用树枝、石块、绳子这类现场普通物件做一件合乎场景的事，不需要它登记成资源，",
        "  也不要为它编造资源 id、更不要把它写进 resource_actions。",
        "  反过来：登记过的资源（锯、蜂蜜、木料这一类）必须按上面的归属规则走，不能绕开。",
        "",
        "requires：声明这次行动依赖的当前状态，没有依赖就写 []。每项一条前置条件，"
        f"type 只能是 {require_types}：",
        '- {"type": "resource_state", "resource_id": "上下文里出现过的资源 id", '
        '"holder_id": 角色 id 或 null, "location_id": 地点 id 或 null}',
        "  holder_id 与 location_id 至少要写一个。holder_id 写 null 表示「此刻没有人持有它」，",
        "  写角色 id 表示「正被此人持有」；location_id 写地点 id 表示「此刻就在这个地点」，",
        "  写 null 表示「不在任何地点（在某人手里）」。",
        '- {"type": "location_state", "location_id": "已知地点 id", "equals": "现场状态的原文"}',
        "  equals 必须逐字照抄该请求 context.location.state_description 的原文：校验是全等比较，",
        "  改写、概括或补标点都会判为条件不成立。",
        "",
        f"resource_actions：这次行动真正要搬运的世界资源，没有就写 []。action 只能是 "
        f"{resource_actions}：",
        "- take：把本人所在地点的某件资源拿到手里。",
        "- drop：把本人手里的某件资源放到本人所在地点。",
        "- 每一项都要写 resource_id，并且这个资源必须在 requires 里用 resource_state 声明过；",
        "  没声明就是输出错误，整步回滚。",
        "- 拿/放是否真的成立由引擎按当时的资源归属判定：已经被别人取走的资源，即使写了 take",
        "  也会判为失败。写之前先看上下文里的资源归属，不确定就不要写。",
        "",
        "示例（<> 里是占位说明，不是要照抄的字符串；实际必须换成该请求上下文里出现的 id）：",
        "",
        render_settle_examples(),
        "",
        "以下写法会被引擎拒绝（整步回滚，这一步作废）：",
        f"- requires 的某一项没写 type，或 type 不是 {require_types}。",
        f"- resource_actions 的 action 不是 {resource_actions}。",
        "- 改了某个资源，却没在 requires 里用 resource_state 声明它的 resource_id。",
        "- resource_state 只写了 type 与 resource_id，holder_id 与 location_id 都没写。",
        "- location_state 的 equals 是空串，或 location_id 不是已知地点。",
        "- success=false 却带着 actor_changes、location_changes 或 resource_actions。",
        "- witnesses 里出现 allowed_witnesses 之外的角色 id。",
        "- results 的条数或 actor_id 与请求对不上。",
        "",
        "复杂行动仍由引擎复核：你声明 success 但前置条件不成立时，事件记为带原因的世界内失败。",
        "world_constraints.rules 是实际世界约束，优先于以上通用示例。人物提出的道具与现场细节",
        "不是它们已经存在的证据。不得因为它出现在意图 text／target 就认定为既定事实。",
        "未登记的普通物件只在符合实际设定时使用；能够改变出入、身份、线索或解决关键困难的",
        "新物件不是随意补充的表达。fact_text 只写在场者可感知的结果，不公开私有动机与幕后原因。",
        "失败的 fact_text 要写具体可观察结果，不复述意图当成事实：缺少钥匙时写没找到钥匙，",
        "不要写已经拿到钥匙但开门失败。看不见失败原因时只写可见的尝试与没有完成。",
    ]
    return "\n".join(lines)


SETTLE_SYSTEM = build_settle_system()



class DeepSeekProvider:
    """按 ModelProvider 协议调用 DeepSeek 官方 API。

    与 FakeProvider 的差别只在传输层：输入仍是受限上下文，输出仍交给
    `validate_intent` / `validate_settlement` 校验；校验失败即输出错误，整步回滚，
    绝不静默退回模拟结果。
    """

    mode = "deepseek"

    transport_label = "标准库 http.client（单次请求，不自动重发）"

    def __init__(self, scenario: dict | None = None, options: dict | None = None,
                 env: dict | None = None, root: str | None = None):
        self.config = load_config(options, env, root)
        self.model = str(self.config["model"])
        self.base_url = str(self.config["base_url"]).rstrip("/")
        self.chat_path = str(self.config["chat_path"])
        if not self.chat_path.startswith("/"):
            self.chat_path = "/" + self.chat_path
        # 场景只用于校验调用方传参习惯；这里不读场景，更不从场景取密钥。
        self.scenario_id = (scenario or {}).get("scenario_id")
        self._reset_stats()
        register_secret_scrubber(self.redact)

    # -- 密钥擦除 -------------------------------------------------------
    def redact(self, text) -> str:
        return _redact(text, self.config.get("api_key"))

    # -- 对外说明（不含密钥）--------------------------------------------
    def describe(self) -> dict:
        parsed = urlsplit(self.base_url)
        thinking = self.config["thinking"]
        # 这里跑的是「实际会下发什么」的同一段判断，界面/日志与真实请求一致。
        return {
            "mode": self.mode,
            "provider": type(self).__name__,
            "model": self.model,
            "endpoint": f"{parsed.scheme}://{parsed.netloc}{parsed.path}{self.chat_path}",
            "api_key_source": self.config.get("api_key_source"),
            "structured_output": "response_format={'type': 'json_object'}",
            "transport": self.transport_label,
            "max_attempts": MAX_ATTEMPTS,
            "timeouts": {
                "connect_s": self.config["connect_timeout_s"],
                "read_s": self.config["read_timeout_s"],
                "total_s": self.config["total_timeout_s"],
            },
            "max_tokens": {"decide": self.config["max_tokens"],
                           "settle_batch": self.config["settle_max_tokens"],
                           "narrate": self.config["narrate_max_tokens"],
                           "interpret": self.config["interpret_max_tokens"],
                           "world_turn": self.config["world_max_tokens"],
                           "chapter": self.config["chapter_max_tokens"],
                           "chapter_interpret": max(8192, self.config["interpret_max_tokens"])},
            "sampling": {
                "thinking": thinking,
                # effective（实际下发）与 configured（配置里写了什么）分开给，
                # 免得「配置了但被规则挡下」的参数在界面上凭空消失。
                "reasoning_effort": (self.config["reasoning_effort"]
                                     if thinking == "enabled" else None),
                "reasoning_effort_configured": self.config["reasoning_effort"],
                "temperature": (self.config["temperature"]
                                if thinking == "disabled" else None),
                "temperature_configured": self.config["temperature"],
                "note": self._sampling_note(),
            },
        }

    def _sampling_note(self) -> str:
        """一句话说清「哪些参数下发、哪些被官方忽略所以不下发」。"""
        thinking = self.config["thinking"]
        effort = self.config["reasoning_effort"]
        temperature = self.config["temperature"]
        if thinking == "enabled":
            parts = ["思考模式开启（官方默认）：官方忽略 temperature，因此不下发"]
            if temperature is not None:
                parts.append(f"已配置 temperature={temperature}，不下发")
            parts.append("reasoning_effort 生效"
                         + (f"（={effort}）" if effort is not None else "（用服务端默认 high）"))
        else:
            parts = ["思考模式关闭：按配置下发 temperature"
                     + (f"（={temperature}）" if temperature is not None else "（未配置，不下发）")]
            if effort is not None:
                parts.append(f"reasoning_effort={effort} 只对思考模式有效，已配置但**不下发**")
        return "；".join(parts)


    # -- 记账 -----------------------------------------------------------
    def _reset_stats(self) -> None:
        self.logical_requests = 0
        self.attempts = 0
        self.elapsed_ms = 0.0
        self.calls: list[dict] = []
        self._prompt_tokens = 0
        self._completion_tokens = 0
        self._total_tokens = 0
        self._usage_calls = 0
        self._missing_usage_calls = 0
        self._reasoning_tokens = 0
        self._reasoning_usage_calls = 0
        self._cache_hit_tokens = 0
        self._cache_miss_tokens = 0
        self._cache_usage_calls = 0
        self._response_usage = None

    def _record(self, stage: str, tick, actor_id, started: float, ok: bool,
                usage: dict | None = None, error_type: str | None = None,
                http_status: int | None = None, transport: dict | None = None) -> None:
        self.attempts += 1
        elapsed = (time.perf_counter() - started) * 1000.0
        self.elapsed_ms += elapsed
        self.calls.append({
            "stage": stage, "tick": tick, "actor_id": actor_id, "ok": ok,
            "elapsed_ms": round(elapsed, 3), "mode": self.mode, "model": self.model,
            "tokens": usage, "error_type": error_type, "http_status": http_status,
            "transport": transport or None,
        })

    def take_stats(self) -> dict:
        known = self._usage_calls > 0 and self._usage_calls == self.attempts and self._missing_usage_calls == 0
        stats = {
            "mode": self.mode,
            "model": self.model,
            "logical_requests": self.logical_requests,
            "attempts": self.attempts,
            "elapsed_ms": round(self.elapsed_ms, 3),
            # 服务端没给 usage 就标未知，不用本地估算冒充实际用量。
            "tokens": ({"prompt": self._prompt_tokens,
                        "completion": self._completion_tokens,
                        "total": self._total_tokens} if known else None),
            "usage_known": known,
            "usage_missing_calls": self._missing_usage_calls,
            "cache_usage_known": known and self._cache_usage_calls == self._usage_calls,
            "cache_tokens": ({"hit": self._cache_hit_tokens, "miss": self._cache_miss_tokens,
                              "prompt": self._cache_hit_tokens + self._cache_miss_tokens}
                             if known and self._cache_usage_calls == self._usage_calls else None),
            "cache_hit_rate": (self._cache_hit_tokens / (self._cache_hit_tokens + self._cache_miss_tokens)
                               if known and self._cache_usage_calls == self._usage_calls
                               and self._cache_hit_tokens + self._cache_miss_tokens else None),
            "reasoning_tokens": (self._reasoning_tokens
                                 if self._usage_calls > 0
                                 and self._reasoning_usage_calls == self._usage_calls
                                 else None),
            "calls": self.calls,
        }
        self._reset_stats()
        return stats

    # -- decide ---------------------------------------------------------
    def decide(self, context: dict) -> dict:
        actor_id = context["self"]["id"]
        tick = context["run"]["tick"]
        system = build_decide_system(context["self"]["name"], actor_id)
        user = ("这是该角色这一刻可用的受限上下文（json）。"
                "请按系统提示的 json 格式返回它的行动意图，以及它自己写下的 state：\n"
                + json.dumps(context, ensure_ascii=False))
        return self._request_json(system, user, stage="decide", tick=tick,
                                  actor_id=actor_id, max_tokens=self.config["max_tokens"])

    # -- settle_batch ---------------------------------------------------
    def settle_batch(self, requests: list[dict]) -> list[dict]:
        tick = requests[0]["tick"] if requests else -1
        if not requests:
            self.logical_requests += 1
            self._record("settle", tick, None, time.perf_counter(), ok=True)
            return []
        actor_ids = [req["intent"]["actor_id"] for req in requests]
        payload = {
            "requests": [
                {
                    "actor_id": req["intent"]["actor_id"],
                    "intent": req["intent"],
                    "actor_location": req["actor_location"],
                    "allowed_witnesses": list(req["allowed_witnesses"]),
                    "all_character_ids": list(req.get("all_character_ids", [])),
                    "context": req["context"],
                    "world_constraints": req.get("world_constraints", {}),
                }
                for req in requests
            ],
            "expected_result_count": len(requests),
        }
        user = render_payload(payload)
        parsed = self._request_json(SETTLE_SYSTEM, user, stage="settle", tick=tick,
                                    actor_id=None,
                                    max_tokens=self.config["settle_max_tokens"],
                                    label=stage_label("settle", actor_ids))
        if isinstance(parsed, dict):
            results = parsed.get("results")
            if results is None:
                raise ProviderSchemaError(
                    '批次结算输出缺少 results 字段：期望 {"results": [...]}，收到键 '
                    + json.dumps(sorted(parsed.keys()), ensure_ascii=False))
            parsed = results
        if not isinstance(parsed, list):
            raise ProviderSchemaError(
                f"批次结算输出必须是数组或 {{\"results\": [...]}}，收到 {type(parsed).__name__}")
        return parsed

    # -- world_turn -----------------------------------------------------
    def world_turn(self, request: dict) -> dict:
        """世界回合（见 src/story.py）：一次 json 调用，独立阶段标签与输出预算。

        与角色决策共用同一套超时、总体期限、密钥擦除与记账，只是阶段名不同，
        因此日志里能直接区分「这次是哪个阶段出的问题」。
        """
        parsed = self._request_json(
            request["system"], request["user"], stage="world", tick=request.get("tick"),
            actor_id=None, max_tokens=self.config["world_max_tokens"],
            label=stage_label("world_turn"))
        if not isinstance(parsed, dict):
            raise ProviderSchemaError(
                f"世界回合的输出必须是对象，收到 {type(parsed).__name__}")
        return parsed

    # -- narrate / interpret --------------------------------------------
    def narrate(self, request: dict) -> str:
        """把一刻的已结算事件改写成正文；输出是纯文本，不加 response_format。"""
        tick = request.get("tick")
        pov = request.get("pov_actor_id")
        return self._request_completion(
            request["system"], request["user"], stage="narrate", tick=tick, actor_id=pov,
            max_tokens=self.config["narrate_max_tokens"], json_mode=False,
            label=stage_label("narrate", pov))

    def narrate_stream(self, request: dict, on_delta) -> str:
        """Stream only final prose content; reasoning tokens never enter the page.

        A partial preview is not a saved segment. The caller saves only after
        [DONE] and finish_reason=stop, using the same narration validation.
        """
        tick = request.get("tick")
        pov = request.get("pov_actor_id")
        tag = stage_label("narrate", pov)
        self.logical_requests += 1
        started = time.perf_counter()
        transport: dict = {}
        body = {"model": self.model,
                "messages": [{"role": "system", "content": request["system"]},
                             {"role": "user", "content": request["user"]}],
                "max_tokens": int(self.config["narrate_max_tokens"]),
                "stream": True, "stream_options": {"include_usage": True}}
        self._apply_sampling(body)
        try:
            prose, status = self._post_once(
                json.dumps(body, ensure_ascii=False).encode("utf-8"), tag,
                timing=transport,
                on_response=lambda response: self._read_prose_stream(
                    response, tag, on_delta, transport, started))
        except ProviderError as exc:
            self._record("narrate", tick, pov, started, ok=False,
                         error_type=exc.error_type, transport=transport)
            raise
        except EXIT_SIGNALS:
            raise
        except Exception as exc:
            self._record("narrate", tick, pov, started, ok=False,
                         error_type="adapter_exception", transport=transport)
            raise ProviderInvalidOutput(
                self.redact(f"[{tag}] 流式适配器异常：{type(exc).__name__}: {exc}")) from exc
        self._record("narrate", tick, pov, started, ok=True,
                     usage=self._take_usage(transport.pop("usage", None)),
                     http_status=status, transport=transport)
        return prose

    def _read_prose_stream(self, response, tag: str, on_delta,
                           timing: dict, started: float) -> str:
        parts: list[str] = []
        data_lines: list[str] = []
        finish_reason = None
        done = False

        def event(data: str) -> None:
            nonlocal finish_reason, done
            if data == "[DONE]":
                done = True
                return
            try:
                chunk = json.loads(data)
            except json.JSONDecodeError as exc:
                raise ProviderInvalidOutput(f"[{tag}] 流式响应不是合法 JSON") from exc
            if not isinstance(chunk, dict):
                raise ProviderInvalidOutput(f"[{tag}] 流式响应片段不是对象")
            if isinstance(chunk.get("usage"), dict):
                timing["usage"] = chunk["usage"]
            choices = chunk.get("choices") or []
            if not isinstance(choices, list):
                raise ProviderInvalidOutput(f"[{tag}] 流式响应 choices 无效")
            for choice in choices:
                if not isinstance(choice, dict):
                    raise ProviderInvalidOutput(f"[{tag}] 流式响应 choice 无效")
                delta = choice.get("delta") or {}
                if not isinstance(delta, dict):
                    raise ProviderInvalidOutput(f"[{tag}] 流式响应 delta 无效")
                content = delta.get("content")
                if isinstance(content, str) and content:
                    if "first_content_ms" not in timing:
                        timing["first_content_ms"] = round(
                            (time.perf_counter() - started) * 1000, 3)
                    parts.append(content)
                    on_delta(content)
                if choice.get("finish_reason") is not None:
                    finish_reason = choice["finish_reason"]

        while not done:
            raw = response.readline(1024 * 1024)
            if not raw:
                break
            if len(raw) >= 1024 * 1024 and not raw.endswith(b"\n"):
                raise ProviderInvalidOutput(f"[{tag}] 流式响应单行过大")
            line = raw.decode("utf-8", "replace").rstrip("\r\n")
            if line == "data: [DONE]":
                if data_lines:
                    event("\n".join(data_lines))
                    data_lines.clear()
                event("[DONE]")
            elif line.startswith("data:"):
                data_lines.append(line[5:].lstrip())
            elif not line and data_lines:
                event("\n".join(data_lines))
                data_lines.clear()
        if data_lines and not done:
            event("\n".join(data_lines))
        if not done:
            raise ProviderNetworkError(f"[{tag}] 流式响应未收到 [DONE]；" + NO_RESEND_HINT)
        if finish_reason == "length":
            raise ProviderTruncated(f"[{tag}] 正文输出被 max_tokens 截断，未保存不完整正文")
        if finish_reason != "stop":
            raise ProviderInvalidOutput(f"[{tag}] 流式正文未正常完成（finish_reason={finish_reason!r}）")
        prose = "".join(parts).strip()
        if not prose:
            raise ProviderEmptyResponse(f"[{tag}] 流式正文为空")
        return prose

    def interpret(self, request: dict) -> dict:
        """把读者输入理解成一件外部事件；输出仍走 json + 本地校验。"""
        parsed = self._request_completion(
            request["system"], request["user"], stage="interpret", tick=request.get("tick"),
            actor_id=None, max_tokens=(max(8192, self.config["interpret_max_tokens"])
                if request.get("chapter_mode") else self.config["interpret_max_tokens"]), json_mode=True,
            label=stage_label("interpret"))
        if not isinstance(parsed, dict):
            raise ProviderSchemaError(
                f"事件理解的输出必须是对象，收到 {type(parsed).__name__}")
        return parsed

    def organize_world(self, request: dict) -> dict:
        """整理导入资料；仍走真实 JSON 适配器、超时与用量记录。"""
        parsed = self._request_json(
            request["system"], request["user"], stage="organize", tick=None,
            actor_id=None, max_tokens=max(4096, self.config["world_max_tokens"]),
            label="资料整理")
        if not isinstance(parsed, dict):
            raise ProviderSchemaError("资料整理必须返回 JSON 对象")
        return parsed

    def chapter_role(self, request: dict):
        """Same official adapter and reasoning settings; no implicit retries."""
        role = request["role"]
        prose = role == "writer_chapter"
        budgets = {"writer_chapter": max(self.config["chapter_max_tokens"], self.config["narrate_max_tokens"]),
                   "actor_perform": max(4096, self.config["max_tokens"])}
        budget = budgets.get(role, max(self.config["chapter_max_tokens"], self.config["world_max_tokens"], self.config["max_tokens"]))
        user = render_payload(request["payload"]) if isinstance(request.get("payload"), dict) else request["user"]
        return self._request_completion(request["system"], user,
            stage=role, tick=request.get("tick"), actor_id=request.get("actor_id"),
            max_tokens=budget, json_mode=not prose, label="章节协作/" + role)

    # -- 传输层 ---------------------------------------------------------
    def _request_json(self, system: str, user: str, stage: str, tick, actor_id,
                      max_tokens: int, label: str | None = None):
        """发一次请求并解析 json 输出。

        失败的报错一律带阶段标签（`[角色决策（a）]` / `[复杂结算（a、b）]`），
        真实推进出错后能直接看出是哪一步、哪个角色，不必再靠猜。
        """
        return self._request_completion(system, user, stage=stage, tick=tick,
                                        actor_id=actor_id, max_tokens=max_tokens,
                                        json_mode=True, label=label)

    def _request_completion(self, system: str, user: str, stage: str, tick, actor_id,
                            max_tokens: int, json_mode: bool, label: str | None = None):
        """发一次请求并解析输出。

        json_mode=True 时下发 response_format=json_object 并把 content 解析成对象；
        正文叙述走 json_mode=False，content 原样当文本用（此时不声明 JSON 输出，
        免得为了「合法 JSON」把正文写坏，或让模型把正文塞进一个 json 字符串里）。

        两条路径共用同一套超时、总体期限、密钥擦除与记账，因此正文调用不会绕过
        provider 边界的任何保障。
        """
        self.logical_requests += 1
        started = time.perf_counter()
        tag = label or stage_label(stage, actor_id)
        body = {
            "model": self.model,
            "messages": [{"role": "system", "content": system},
                         {"role": "user", "content": user}],
            "max_tokens": int(max_tokens),
            "stream": False,
        }
        if json_mode:
            body["response_format"] = {"type": "json_object"}
        self._apply_sampling(body)

        transport: dict = {}
        self._response_usage = None
        try:
            raw, status = self._post_once(
                json.dumps(body, ensure_ascii=False).encode("utf-8"), tag,
                timing=transport)
        except ProviderError as exc:
            self._record(stage, tick, actor_id, started, ok=False,
                         error_type=getattr(exc, "error_type", None),
                         transport=transport)
            raise
        except EXIT_SIGNALS:
            raise                                      # Ctrl-C / SystemExit 原样上抛
        except Exception as exc:                       # noqa: BLE001 - 兜底也要记账
            self._record(stage, tick, actor_id, started, ok=False,
                         error_type="adapter_exception", transport=transport)
            raise ProviderInvalidOutput(
                self.redact(f"[{tag}] 适配器异常：{type(exc).__name__}: {exc}")) from exc

        try:
            usage, parsed = self._parse_success(stage, raw, status, tag,
                                                json_mode=json_mode)
        except ProviderError as exc:
            self._record(stage, tick, actor_id, started, ok=False,
                         usage=self._response_usage, error_type=exc.error_type, http_status=status,
                         transport=transport)
            raise
        self._record(stage, tick, actor_id, started, ok=True, usage=usage,
                     http_status=status, transport=transport)
        return parsed

    def _apply_sampling(self, body: dict) -> None:
        """按官方《思考模式》语义决定下发哪些采样参数。

        - 思考模式开关始终显式下发：`{"thinking": {"type": "enabled"|"disabled"}}`，
          不再依赖服务端默认值，配置和实际请求一一对应。
        - `reasoning_effort` 只在思考模式开启且有配置时下发（思考模式的强度参数）。
        - `temperature` 只在思考模式**关闭**时下发。官方文档明确：思考模式下设置
          temperature 不报错但不生效；若照发，日志里会出现一个看似生效、实则被忽略的值。
          temperature=0 也只是采样参数，不构成「输出确定」的保证。
        """
        thinking = self.config.get("thinking")
        if thinking is not None:
            body["thinking"] = {"type": thinking}
        effort = self.config.get("reasoning_effort")
        if thinking == "enabled" and effort is not None:
            body["reasoning_effort"] = effort
        temperature = self.config.get("temperature")
        if thinking == "disabled" and temperature is not None:
            body["temperature"] = temperature

    def _deadline_error(self, phase: str, label: str):
        """统一的期限超时异常：说清本地做了什么、以及本地管不到什么。"""
        return ProviderTimeout(self.redact(
            f"[{label}] 总体调用期限 {self.config['total_timeout_s']:g}s 已到（{phase}）。"
            + DEADLINE_BOUNDARY + NO_RESEND_HINT))

    def _post_once(self, body: bytes, label: str, timing: dict | None = None,
                   on_response=None) -> tuple[str, int]:
        """发一次 HTTP 请求；不做任何重发。返回 (响应文本, 状态码)。

        总体期限用单调时钟覆盖**完整等待**：连接、请求发送、响应头、响应体。
        读取超时只负责「静默期」，慢速吐字节靠 `_DeadlineGuard` 到点掐断，
        因此慢速 Content-Length / 慢速 chunked / 空行保活都不会把整体等待拖长。
        """
        clock = time.perf_counter()
        timing = timing if timing is not None else {}
        parsed = urlsplit(self.base_url)
        host = parsed.hostname
        port = parsed.port or (443 if parsed.scheme == "https" else 80)
        path = (parsed.path.rstrip("/") + self.chat_path) or self.chat_path
        connect_s = float(self.config["connect_timeout_s"])
        read_s = float(self.config["read_timeout_s"])
        total_s = float(self.config["total_timeout_s"])
        # 单调时钟：不受系统时间调整影响。
        deadline = time.monotonic() + total_s
        guard = _DeadlineGuard(deadline)

        conn_cls = HTTPSConnection if parsed.scheme == "https" else HTTPConnection
        conn = conn_cls(host, port, timeout=connect_s)
        try:
            if guard.expired:
                raise self._deadline_error("发起请求之前", label)
            # 连接超时也压进总体预算里，避免「连接就吃掉全部期限」。
            conn.timeout = max(1e-3, min(connect_s, guard.remaining()))
            try:
                conn.connect()
                timing["connect_ms"] = round((time.perf_counter() - clock) * 1000, 3)
            except (socket.timeout, TimeoutError) as exc:
                if guard.expired:
                    raise self._deadline_error("建立连接阶段", label) from exc
                raise ProviderTimeout(self.redact(
                    f"[{label}] 连接 {host}:{port} 超时（{conn.timeout:g}s，含总体期限约束）"
                    + NO_RESEND_HINT)) from exc
            except OSError as exc:
                if guard.expired:
                    raise self._deadline_error("建立连接阶段", label) from exc
                raise ProviderNetworkError(self.redact(
                    f"[{label}] 连接 {host}:{port} 失败：{type(exc).__name__}: {exc}；"
                    + NO_RESEND_HINT)) from exc

            if guard.expired:
                raise self._deadline_error("连接建立之后", label)

            # 读超时同样不得超过总体预算：静默期上限 = min(read_s, 剩余期限)。
            try:
                if conn.sock is not None:
                    conn.sock.settimeout(max(1e-3, min(read_s, guard.remaining())))
            except OSError:                                    # pragma: no cover - 极端环境
                pass

            # 到点强制关连接：慢速吐字节时让阻塞读立刻返回，而不是等它吐完。
            guard.attach(conn)
            try:
                sent_at = time.perf_counter()
                conn.request("POST", path, body=body, headers={
                    "Content-Type": "application/json",
                    "Accept": "application/json",
                    "Authorization": f"Bearer {self.config['api_key']}",
                    "User-Agent": "oc-world/0.1 (+stdlib http.client)",
                })
                timing["send_ms"] = round((time.perf_counter() - sent_at) * 1000, 3)
                if guard.expired:
                    raise self._deadline_error("请求发送之后", label)
                headers_at = time.perf_counter()
                response = conn.getresponse()
                timing["headers_wait_ms"] = round(
                    (time.perf_counter() - headers_at) * 1000, 3)
                if guard.expired:
                    raise self._deadline_error("收到响应头之后", label)
                status = int(response.status)
                body_at = time.perf_counter()
                # Stream callback consumes the body while the same deadline guard
                # remains active. Non-stream callers retain the old full-body path.
                if on_response is not None and status == 200:
                    streamed = on_response(response)
                    raw_bytes = b""
                else:
                    streamed = None
                    raw_bytes = response.read()
                timing["body_ms"] = round((time.perf_counter() - body_at) * 1000, 3)
                if guard.expired:
                    raise self._deadline_error("读取响应体阶段", label)
            except ProviderTimeout:
                raise
            except ProviderError:
                raise
            except EXIT_SIGNALS:
                raise                                          # Ctrl-C 原样上抛，不吞成超时
            except (socket.timeout, TimeoutError) as exc:
                if guard.expired:
                    raise self._deadline_error("等待响应阶段", label) from exc
                raise ProviderTimeout(self.redact(
                    f"[{label}] 等待响应超时（读取上限 {read_s}s，静默期无数据）："
                    + NO_RESEND_HINT)) from exc
            except RemoteDisconnected as exc:
                if guard.expired:
                    raise self._deadline_error("读取响应体阶段", label) from exc
                raise ProviderNetworkError(self.redact(
                    f"[{label}] 服务端提前断开连接（响应不完整）：{NO_RESEND_HINT}")) from exc
            except IncompleteRead as exc:
                if guard.expired:
                    raise self._deadline_error("响应体传输中断之后", label) from exc
                raise ProviderNetworkError(self.redact(
                    f"[{label}] 响应传输中断（IncompleteRead）：{exc}；{NO_RESEND_HINT}")) from exc
            except (HTTPException, OSError, ValueError) as exc:
                # ValueError：期限到点后连接已被本地关闭，读已关闭的文件会抛这个。
                if guard.expired:
                    raise self._deadline_error("读取响应阶段", label) from exc
                raise ProviderNetworkError(self.redact(
                    f"[{label}] HTTP 传输失败：{type(exc).__name__}: {exc}；"
                    + NO_RESEND_HINT)) from exc
        finally:
            guard.cancel()
            try:
                conn.close()
            except OSError:                                    # pragma: no cover
                pass

        timing["transport_ms"] = round((time.perf_counter() - clock) * 1000, 3)
        text = raw_bytes.decode("utf-8", errors="replace") if raw_bytes else ""
        if status != 200:
            raise self._status_error(status, text, label)
        return (streamed if on_response is not None else text), status

    def _status_error(self, status: int, text: str, label: str):
        factory, label_text = STATUS_ERRORS.get(status)
        if factory is None:
            if 400 <= status < 500:
                factory, label_text = ProviderRequestRejected, f"{status} 请求被拒"
            elif status >= 500:
                factory, label_text = ProviderServiceError, f"{status} 服务端错误"
            else:
                factory, label_text = ProviderInvalidOutput, f"{status} 非预期状态码"
        detail = self._error_detail(text)
        hint = f"；{NO_RESEND_HINT}" if factory in (ProviderRateLimit, ProviderServiceError,
                                                    ProviderNetworkError) else ""
        message = f"[{label}] {label_text}"
        if detail:
            message += f"（服务端说明：{detail}）"
        return factory(self.redact(message + hint))

    @staticmethod
    def _error_detail(text: str) -> str:
        """从官方错误体里取一句话说明；取不到就返回空串。"""
        if not text or not text.strip():
            return ""
        try:
            payload = json.loads(text)
        except json.JSONDecodeError:
            return text.strip()[:200]
        if isinstance(payload, dict):
            error = payload.get("error")
            if isinstance(error, dict) and error.get("message"):
                return str(error["message"])[:200]
            if isinstance(error, str):
                return error[:200]
            if payload.get("message"):
                return str(payload["message"])[:200]
        return json.dumps(payload, ensure_ascii=False)[:200]

    def _parse_success(self, stage: str, text: str, status: int,
                       label: str, json_mode: bool = True) -> tuple[dict | None, object]:
        """解析成功响应：先看截断，再看空响应，最后才解析内容。

        每条报错都带阶段标签：截断与结构错误要在日志里能直接区分是「角色决策」
        「复杂结算」还是「正文叙述」出的问题（截断属输出长度问题，结构错误属协议问题，
        处理方式不同），必要时还带角色 id。

        json_mode=False（正文叙述）时只把 content 去空白后原样返回，不做 JSON 解析：
        正文里有换行、引号和各种标点，硬要求它是合法 JSON 只会写坏文字。
        """
        if not text or not text.strip():
            # 官方文档说明非流式请求等待期间会持续返回空行，这里按空响应处理。
            raise ProviderEmptyResponse(
                f"[{label}] HTTP 200 但响应体为空（官方说明 JSON 模式偶发空响应，可改提示词缓解）")
        try:
            payload = json.loads(text)
        except json.JSONDecodeError as exc:
            raise ProviderInvalidOutput(self.redact(
                f"[{label}] 响应不是合法 JSON：{exc}；响应片段：{text[:200]!r}")) from exc
        if not isinstance(payload, dict):
            raise ProviderInvalidOutput(
                f"[{label}] 响应顶层必须是对象，收到 {type(payload).__name__}")

        # Failed content and length-limited responses still consumed billed tokens.
        usage = self._take_usage(payload.get("usage"))
        self._response_usage = usage

        choices = payload.get("choices")
        if not isinstance(choices, list) or not choices:
            raise ProviderEmptyResponse(
                f"[{label}] 响应没有 choices："
                + json.dumps(payload, ensure_ascii=False)[:200])
        first = choices[0] if isinstance(choices[0], dict) else {}
        finish = first.get("finish_reason")
        message = first.get("message") if isinstance(first.get("message"), dict) else {}
        content = message.get("content")
        if finish == "length":
            tail = ("请提高 max_tokens 或缩小批次规模" if json_mode
                    else "请提高叙述输出预算，或把一段写得短一些")
            what = "JSON 不完整，" if json_mode else "正文只写了一半，"
            raise ProviderTruncated(
                f"[{label}] 输出被 max_tokens 截断（finish_reason=length）：{what}{tail}")
        if not isinstance(content, str) or not content.strip():
            raise ProviderEmptyResponse(
                f"[{label}] 返回空 content（finish_reason={finish!r}）")

        if not json_mode:
            return usage, content.strip()
        try:
            parsed = json.loads(content.strip())
        except json.JSONDecodeError as exc:
            raise ProviderInvalidOutput(self.redact(
                f"[{label}] 的 content 不是合法 JSON：{exc}；内容片段：{content[:200]!r}")) from exc
        return usage, parsed

    def _take_usage(self, usage) -> dict | None:
        if not isinstance(usage, dict):
            self._missing_usage_calls += 1
            return None
        values = {}
        for name, key in (("prompt", "prompt_tokens"), ("completion", "completion_tokens"),
                          ("total", "total_tokens")):
            value = usage.get(key)
            values[name] = int(value) if type(value) is int and value >= 0 else None
        if any(value is None for value in values.values()):
            self._missing_usage_calls += 1
            return None
        detail = usage.get("completion_tokens_details")
        reasoning = detail.get("reasoning_tokens") if isinstance(detail, dict) else None
        if isinstance(reasoning, int) and not isinstance(reasoning, bool):
            values["reasoning"] = reasoning
            self._reasoning_tokens += reasoning
            self._reasoning_usage_calls += 1
        self._usage_calls += 1
        self._prompt_tokens += values["prompt"]
        self._completion_tokens += values["completion"]
        self._total_tokens += values["total"]
        hit, miss = usage.get("prompt_cache_hit_tokens"), usage.get("prompt_cache_miss_tokens")
        if type(hit) is int and type(miss) is int and hit >= 0 and miss >= 0 and hit + miss == values["prompt"]:
            values.update(prompt_cache_hit_tokens=hit, prompt_cache_miss_tokens=miss)
            self._cache_hit_tokens += hit
            self._cache_miss_tokens += miss
            self._cache_usage_calls += 1
        return values


__all__ = ["DeepSeekProvider", "load_config", "DEFAULTS", "MAX_ATTEMPTS", "DEFAULT_MODEL",
           "DECIDE_SYSTEM", "SETTLE_SYSTEM", "PLACEHOLDERS", "SETTLE_PROTOCOL_EXAMPLES",
           "build_decide_system", "build_settle_system", "render_settle_examples",
           "resolve_settle_examples"]
