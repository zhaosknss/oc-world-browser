"""模型接口与首阶段的模拟实现。

ModelProvider 是唯一可替换的模型边界：角色每次决策一次调用，
复杂行动走批次结算调用（新版三人包按实际行动逐次结算，每次一个请求）；
显式打开 story_loop 的运行包每刻另有一次世界回合调用；
不单独调用私有反思或记忆摘要。

角色写下的短期个人状态（当前在意的事与打算、对处境的理解、试过的结果、没做完的事）
与行动由**同一次 decide 调用**返回，不额外加一次反思请求：它的 state 字段由
src/models.py::validate_intent 校验，由 src/engine.py 在提交事务里落库
（src/notes.py），下一次决策时随上下文一起回到该角色手里。

FakeProvider 不宣称 token 用量：它只记录逻辑请求数、实际尝试次数与耗时。
真实模型走 src/deepseek.py 的 DeepSeekProvider，实现同一组方法即可替换；
默认路径仍是 FakeProvider。
"""
from __future__ import annotations

import copy
import time
from typing import Any

from .models import (ProviderCancelled, ProviderInvalidOutput, ProviderSchemaError,
                     ProviderTimeout)

FAULT_TYPES = ("invalid_json", "schema", "timeout", "cancel", "witness_out_of_scope")

# 模拟正文的标注只在**页面统一展示一次**（阅读页正文区上方），不再每段重复。
# 早先是每段开头加〔模拟文本…〕、结尾再加一句说明，读起来全是重复的声明，
# 反而看不清正文本身。这里的两句都由 reading_view 交给页面，段落文字保持干净。
FAKE_PROSE_BANNER = ("本页正文是模拟文本：由已结算事件直接拼出的占位文字，"
                     "只用来检查阅读节奏、段落衔接与失败提示是否通顺，不是模型写出来的。")

# build_provider 认识的提供方名称。默认 fake；deepseek 需要本机配置密钥。
PROVIDER_NAMES = ("fake", "deepseek")
DEEPSEEK_ALIASES = ("deepseek", "deepseek-api", "real")


class ModelProvider:
    """接口定义；真实 API 接入在首阶段验收之后，实现同一组方法即可替换。

    除了角色决策与批次结算，阅读观察版还用到两个边界：

    - `narrate(request)`：把某一刻的已结算事件改写成面向读者的正文段落。
      request 的键固定为 `system` / `user`（提示词由 src/narrate.py 组装，
      因为它们属于「可以换掉的世界材料」）、`tick`、`pov_actor_id`、`payload`
      （结构化输入，模拟提供方用它拼占位正文，不必反过来解析 user 串）。
    - `interpret(request)`：把读者输入的自由文本理解成一件外部事件。
      request 的键为 `system` / `user` / `text` / `tick` / `payload`（当前世界、
      地点、人物与可用范围的摘要）。结构化输出由 src/intervention.py 校验。
    - `world_turn(request)`：世界回合（见 src/story.py）。request 的键为
      `system` / `user` / `tick` / `payload`（IF、上次局面、已结算事件、当前世界状态、
      本刻刚生效的外部事件）。返回一份短局面与零或一件外界变化，由 src/story.py 校验。
      只有显式打开 story_loop 的新运行包才会调用它。
    """

    mode = "abstract"

    def decide(self, context: dict) -> dict:  # pragma: no cover - 接口
        raise NotImplementedError

    def settle_batch(self, requests: list[dict]) -> list[dict]:  # pragma: no cover
        raise NotImplementedError

    def world_turn(self, request: dict) -> dict:  # pragma: no cover - 接口
        raise NotImplementedError

    def narrate(self, request: dict) -> str:  # pragma: no cover - 接口
        raise NotImplementedError

    def chapter_role(self, request: dict):  # pragma: no cover - 接口
        raise NotImplementedError

    def interpret(self, request: dict) -> dict:  # pragma: no cover - 接口
        raise NotImplementedError

    def take_stats(self) -> dict:  # pragma: no cover - 接口
        raise NotImplementedError

    def describe(self) -> dict:
        """给界面/接口用的自我说明；绝不含密钥。"""
        return {"mode": self.mode, "provider": type(self).__name__}


class FakeProvider(ModelProvider):
    """模拟模型：按场景脚本返回意图，未命中脚本时回退为 wait。

    另提供故障注入，用于验证无效返回/超时/取消下的状态不变。
    世界回合按场景/覆盖数据里的 `world_script`（按 tick）返回；没有预设时给出
    「本刻没有新的外界变化」的空局面，不假装主持了什么。

    `seen` 是**诊断用**的原始输入留档（世界回合请求、每次决策的上下文、每批结算请求），
    与 `take_stats()` 的记账相互独立、不随 take_stats 清零：离线验证要能直接看
    「后行动者到底拿到了什么上下文」这种问题，光靠计数答不了。
    """

    mode = "fake"

    def __init__(self, scenario: dict | None = None, faults: list[dict] | None = None):
        scenario = scenario or {}
        self.script = scenario.get("provider_script", [])
        self.complex_rules = scenario.get("complex_rules", [])
        self.scenario_prose = scenario.get("provider_prose", [])
        self.world_script = scenario.get("world_script", [])
        self.chapter_script = scenario.get("chapter_script", [])
        self.faults = list(faults or [])
        self.seen: dict[str, list] = {"world": [], "decide": [], "settle": []}
        self._reset_stats()

    def chapter_role(self, request: dict):
        """Deterministic contract fixture; its text does not represent model quality."""
        self.logical_requests += 1
        started = time.perf_counter()
        role, payload = request["role"], request["payload"]
        tick, actor_id = request.get("tick"), request.get("actor_id")
        self.seen.setdefault("chapters", []).append(copy.deepcopy(request))
        fault = self._check_fault(role, tick, actor_id)
        if fault is not None:
            self._record(role, tick, actor_id, started, ok=False)
            self._raise_fault(fault, role)
        for item in self.chapter_script:
            if (item.get("role") == role and item.get("tick", tick) == tick
                    and item.get("actor_id", actor_id) == actor_id):
                self._record(role, tick, actor_id, started, ok=True)
                return copy.deepcopy(item["output"])
        if role == "director_plan":
            actors = payload["characters"]
            pov = sorted(actors)[0]
            location = actors[pov]["location_id"]
            result = {"title": "模拟章节", "throughline": "检查完整章节的状态接续",
                "chapter_goal": "经历一次相互回应", "ending_aim": "交流形成阶段落点",
                "scene": {"actors": [aid for aid, ch in actors.items() if ch["location_id"] == location],
                    "pov_actor_id": pov, "location_id": location, "reader_visible": True,
                    "purpose": "仅为流程检查", "proposed_event": None}}
        elif role == "director_review":
            done = payload["exchange"] >= 2
            result = {"scene_done": done, "chapter_done": done,
                      "closure": "交流形成了可继续或投入事件的停顿" if done else "",
                      "continuity": "延续已发生的行动与消息", "next_scene": None}
        elif role == "actor_perform":
            result = {"actions": [self._scripted_intent(tick, actor_id)],
                      "state": {"focus": "根据已知现场判断下一步", "pending": f"第{tick}刻后的打算"}}
        elif role == "writer_craft":
            result = {"texture": "", "dialogue_direction": ""}
        elif role == "world_event":
            result = {"approved": True, "reason": "模拟事件裁定"}
        elif role == "writer_chapter":
            result = "\n\n".join("".join(e["text"] for e in s["events"]) for s in payload["scenes"])
        elif role == "editor_review":
            result = {"approved": True, "rewrite_notes": ""}
        else:
            raise ProviderSchemaError("未知章节职责：" + role)
        self._record(role, tick, actor_id, started, ok=True)
        return copy.deepcopy(result)

    def describe(self) -> dict:
        return {"mode": self.mode, "provider": type(self).__name__,
                "script_entries": len(self.script),
                "complex_rules": len(self.complex_rules),
                "prose_entries": len(self.scenario_prose),
                "world_entries": len(self.world_script),
                "faults": len(self.faults),
                "note": "按场景脚本返回，不调用真实模型，不产生 token 用量；"
                        "正文是占位文本，模拟标注由阅读页统一展示"}

    def _reset_stats(self) -> None:
        self.logical_requests = 0
        self.attempts = 0
        self.elapsed_ms = 0.0
        self.calls: list[dict] = []

    # -- 故障注入 -------------------------------------------------------
    def _check_fault(self, stage: str, tick: int, actor_id: str | None) -> dict | None:
        for fault in self.faults:
            if fault.get("stage") != stage:
                continue
            if fault.get("tick") is not None and fault["tick"] != tick:
                continue
            if fault.get("actor_id") is not None and fault["actor_id"] != actor_id:
                continue
            return fault
        return None

    def _raise_fault(self, fault: dict, stage: str) -> None:
        kind = fault.get("type")
        if kind not in FAULT_TYPES:
            raise ProviderSchemaError(f"未知故障类型：{kind}")
        message = fault.get("message") or f"注入故障（{stage}）：{kind}"
        if kind == "timeout":
            raise ProviderTimeout(message)
        if kind == "cancel":
            raise ProviderCancelled(message)
        raise ProviderInvalidOutput(message)

    # -- 记账 -----------------------------------------------------------
    def _record(self, stage: str, tick: int, actor_id: str | None,
                started: float, ok: bool) -> None:
        self.attempts += 1
        elapsed = (time.perf_counter() - started) * 1000.0
        self.elapsed_ms += elapsed
        self.calls.append({"stage": stage, "tick": tick, "actor_id": actor_id,
                           "ok": ok, "elapsed_ms": round(elapsed, 3),
                           "mode": self.mode, "tokens": None})

    def take_stats(self) -> dict:
        stats = {
            "mode": self.mode,
            "logical_requests": self.logical_requests,
            "attempts": self.attempts,
            "elapsed_ms": round(self.elapsed_ms, 3),
            "tokens": None,          # 模拟模式不宣称 token 用量
            "calls": self.calls,
        }
        self._reset_stats()
        return stats

    # -- 角色决策 -------------------------------------------------------
    def decide(self, context: dict) -> dict:
        tick = context["run"]["tick"]
        actor_id = context["self"]["id"]
        self.logical_requests += 1
        started = time.perf_counter()
        self.seen["decide"].append(copy.deepcopy(context))
        fault = self._check_fault("decide", tick, actor_id)
        if fault is not None:
            self._record("decide", tick, actor_id, started, ok=False)
            self._raise_fault(fault, "decide")
        intent = self._scripted_intent(tick, actor_id)
        self._record("decide", tick, actor_id, started, ok=True)
        return copy.deepcopy(intent)

    def _scripted_intent(self, tick: int, actor_id: str) -> dict:
        for entry in self.script:
            if entry.get("tick") == tick and entry.get("actor_id") == actor_id:
                return entry["intent"]
        return {"actor_id": actor_id, "action": "wait", "target": None,
                "tone": "平静", "text": None}

    # -- 世界回合（模拟）------------------------------------------------
    def world_turn(self, request: dict) -> dict:
        """按 `world_script` 返回本刻局面；没有预设时给一份空局面（本刻没有新变化）。

        返回值仍要过 src/story.py 的校验，因此这里不替调用方兜结构错误。
        """
        tick = request.get("tick", -1)
        self.logical_requests += 1
        started = time.perf_counter()
        self.seen["world"].append(copy.deepcopy(request))
        fault = self._check_fault("world", tick, None)
        if fault is not None:
            self._record("world", tick, None, started, ok=False)
            self._raise_fault(fault, "world")
        turn = None
        for entry in self.world_script:
            if entry.get("tick") == tick:
                turn = entry.get("turn")
                break
        if turn is None:
            turn = {"open_questions": "", "focus": {"actors": [], "locations": []},
                    "event": None, "source": "模拟世界回合（没有预设变化）"}
        self._record("world", tick, None, started, ok=True)
        return copy.deepcopy(turn)

    # -- 复杂行动批次结算 -----------------------------------------------
    def settle_batch(self, requests: list[dict]) -> list[dict]:
        self.logical_requests += 1
        tick = requests[0]["tick"] if requests else -1
        started = time.perf_counter()
        self.seen["settle"].append(copy.deepcopy(
            [req["intent"]["actor_id"] for req in requests]))
        results = []
        for req in requests:
            actor_id = req["intent"]["actor_id"]
            fault = self._check_fault("settle", req["tick"], actor_id)
            if fault is not None:
                self._record("settle", req["tick"], actor_id, started, ok=False)
                self._raise_fault(fault, "settle")
            results.append(self._rule_outcome(req))
        self._record("settle", tick, None, started, ok=True)
        return results

    def _rule_outcome(self, req: dict) -> dict:
        intent = req["intent"]
        actor_id = intent["actor_id"]
        allowed = list(req["allowed_witnesses"])
        rule = self._match_rule(actor_id, intent.get("target"))
        if rule is None:
            return {
                "actor_id": actor_id,
                "success": True,
                "reason": "按规则完成",
                "fact_text": f"{{name}}{intent.get('target')}（模拟结算：无预设规则的普通动作已完成）",
                "witnesses": allowed,
                "actor_changes": {},
                "location_changes": {},
            }
        out = {
            "actor_id": actor_id,
            "success": bool(rule.get("success", True)),
            "reason": rule.get("reason", "按规则完成"),
            "fact_text": rule.get("fact_text", "动作已完成"),
            "witnesses": allowed if rule.get("witnesses", "present") == "present"
                         else list(rule["witnesses"]),
            "actor_changes": dict(rule.get("actor_changes", {})),
            "location_changes": dict(rule.get("location_changes", {})),
            # 复杂行动的显式前置条件与结构化资源动作：由场景规则声明，
            # 引擎在应用前按暂存状态复核（见 src/models.py、src/settlement.py）。
            "requires": copy.deepcopy(rule.get("requires", [])),
            "resource_actions": copy.deepcopy(rule.get("resource_actions", [])),
        }
        if rule.get("fault") == "witness_out_of_scope":
            # 故意返回越界的观察范围，交给引擎的校验拒绝
            out["witnesses"] = sorted(set(req.get("all_character_ids", allowed)))
        elif rule.get("fault") == "actor_mismatch":
            out["actor_id"] = "nobody"
        elif rule.get("fault") == "missing_reason":
            out["reason"] = ""
        return out

    def _match_rule(self, actor_id: str, target: Any) -> dict | None:
        for rule in self.complex_rules:
            if rule.get("actor_id") == actor_id and rule.get("target") == target:
                return rule
        return None

    # -- 正文叙述（模拟）------------------------------------------------
    def narrate(self, request: dict) -> str:
        """返回一段**明确标注为模拟**的占位正文，不调用真实模型。

        场景可以用 `provider_prose` 按 tick 给出固定文本（测试用），
        否则由本次输入里的事实日志拼出来——这样 Fake 模式也能完整走通阅读链路，
        同时任何人一眼就能看出这不是模型写的。
        """
        tick = request.get("tick", 0)
        self.logical_requests += 1
        started = time.perf_counter()
        fault = self._check_fault("narrate", tick, request.get("pov_actor_id"))
        if fault is not None:
            self._record("narrate", tick, request.get("pov_actor_id"), started, ok=False)
            self._raise_fault(fault, "narrate")
        text = self._scripted_prose(tick) or self._placeholder_prose(request)
        self._record("narrate", tick, request.get("pov_actor_id"), started, ok=True)
        return copy.deepcopy(text)

    def _scripted_prose(self, tick: int):
        for entry in self.scenario_prose:
            if entry.get("tick") == tick:
                return entry["prose"]
        return None

    def _placeholder_prose(self, request: dict) -> str:
        """把这一刻的事实拼成一段可直接读的占位正文。

        要求：**不写重复的模拟声明，也不写结尾说明**（那些统一放页面上）；
        每一刻的事件都要出现，某两条文字重复也不合并、不删——事件记录不因为
        「读起来重复」而减少。
        """
        payload = request.get("payload") if isinstance(request.get("payload"), dict) else {}
        scene = payload.get("scene") if isinstance(payload.get("scene"), dict) else {}
        log = payload.get("scene_log") if isinstance(payload.get("scene_log"), list) else []
        places = scene.get("places") if isinstance(scene.get("places"), list) else []
        present = (scene.get("present_by_place")
                   if isinstance(scene.get("present_by_place"), list) else [])

        names = [str(item.get("name")) for item in places if item.get("name")]
        head = f"这一刻，{'、'.join(names)}。" if names else "这一刻。"
        body = "".join(str(line) for line in log)
        if not body:
            body = "这一刻没有人做出值得记下来的事。"
        tail = "".join(
            f"{item.get('place')}里有{'、'.join(str(p) for p in item.get('people', []))}。"
            for item in present if item.get("people"))
        return head + body + tail

    # -- 事件理解（模拟）------------------------------------------------
    def interpret(self, request: dict) -> dict:
        """模拟模式不做模型理解：返回 `applicable=None`，由调用方走本地规则。

        `applicable=None` 不是「不能应用」，而是「这一层没有意见」——
        src/intervention.py 会据此改用关键词与预设匹配，并把结果如实标出来。
        """
        self.logical_requests += 1
        started = time.perf_counter()
        self._record("interpret", request.get("tick"), None, started, ok=True)
        return {"applicable": None, "reason": "模拟模式不做模型理解，改用本地规则匹配"}


def build_provider(name: str, scenario: dict, faults: list[dict] | None = None,
                   options: dict | None = None) -> ModelProvider:
    """按名称构造 provider。默认 fake；deepseek 需本机配置密钥，构造失败即报错。

    options 仅供调用方（命令行/测试）覆盖模型名、base_url 与超时；
    密钥仍按 src/deepseek.py 的规则从环境变量或被忽略的本地配置读取。
    """
    if name == "fake":
        return FakeProvider(scenario, faults)
    if name in DEEPSEEK_ALIASES:
        from .deepseek import DeepSeekProvider   # 延迟导入：模拟路径不依赖真实适配器
        return DeepSeekProvider(scenario, options)
    raise ValueError(f"未知 provider：{name}（可用：{', '.join(PROVIDER_NAMES)}）")
