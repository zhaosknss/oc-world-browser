"""DeepSeek protocol over an explicit browser bridge, never desktop credentials."""
from __future__ import annotations

import json
import time

from .browser_lease import refresh_active
from .deepseek import (DEFAULTS, DEFAULT_MODEL, DeepSeekProvider, NO_RESEND_HINT,
                       _validate)
from .models import (EngineError, ProviderConfigError, ProviderInvalidOutput,
                     ProviderNetworkError, ProviderTimeout)


class BrowserDeepSeekProvider(DeepSeekProvider):
    transport_label = "浏览器 Worker 单次请求（不自动重发）"

    def __init__(self, scenario=None, options=None, request=None, checkpoint=None):
        # Deliberately do not call load_config or the desktop constructor: even
        # an absent browser key must not fall back to a host file/environment.
        options = options or {}
        self.config = dict(DEFAULTS)
        for key, value in options.items():
            if key in self.config:
                self.config[key] = value
        self.config.update({"model": options.get("model") or DEFAULT_MODEL,
                            "thinking": "enabled", "reasoning_effort": "high",
                            "api_key": str(options.get("api_key") or "").strip(),
                            "api_key_source": "本标签页临时输入"})
        _validate(self.config)
        self.model = self.config["model"]
        self.base_url = str(self.config["base_url"]).rstrip("/")
        self.chat_path = str(self.config["chat_path"])
        if not self.chat_path.startswith("/"):
            self.chat_path = "/" + self.chat_path
        self.scenario_id = (scenario or {}).get("scenario_id")
        self._request_bridge, self._checkpoint = request, checkpoint
        self._reset_stats()

    def _raw_once(self, url, body_text, headers_json, timeout_ms):
        bridge = self._request_bridge
        if bridge is None:
            try:
                from js import ocBrowserRequest
            except ImportError as exc:
                raise ProviderNetworkError("当前环境没有浏览器 API 请求桥") from exc
            bridge = ocBrowserRequest
        return bridge(url, body_text, headers_json, timeout_ms)

    def _post_once(self, body, label, timing=None, on_response=None):
        if not self.config["api_key"]:
            raise ProviderConfigError("请先在设置中填写自己的 DeepSeek API 密钥；已保存的正文仍可阅读")
        if on_response is not None:
            raise ProviderInvalidOutput("浏览器适配只读取完整响应，不把未保存正文作为流式成品")
        started = time.perf_counter()
        refresh_active()
        headers = {"Content-Type": "application/json", "Accept": "application/json",
                   "Authorization": "Bearer " + self.config["api_key"]}
        try:
            envelope = self._raw_once(
                self.base_url + self.chat_path, body.decode("utf-8"),
                json.dumps(headers), int(float(self.config["total_timeout_s"]) * 1000))
            envelope = json.loads(str(envelope)) if not isinstance(envelope, dict) else envelope
        except (ProviderNetworkError, ProviderTimeout):
            raise
        except Exception as exc:
            raise ProviderNetworkError(self.redact(
                f"[{label}] 浏览器请求未完成：{exc}。可能是网络或跨域限制。" + NO_RESEND_HINT)) from exc
        finally:
            refresh_active()
        if not isinstance(envelope, dict) or type(envelope.get("status")) is not int:
            raise ProviderInvalidOutput("浏览器请求桥没有返回合法 status/body")
        status = envelope["status"]
        raw = envelope.get("body", "")
        if not isinstance(raw, str):
            raw = json.dumps(raw, ensure_ascii=False)
        if status == 0:
            error = self.redact(str(envelope.get("error") or raw))
            if envelope.get("timeout"):
                raise ProviderTimeout(f"[{label}] 浏览器等待已超时：{error}。" + NO_RESEND_HINT)
            raise ProviderNetworkError(f"[{label}] 浏览器无法完成 API 请求，可能是网络或跨域限制：{error}。" + NO_RESEND_HINT)
        if status != 200:
            raise self._status_error(status, raw, label)
        if timing is not None:
            timing["transport_ms"] = round((time.perf_counter() - started) * 1000, 3)
        if self._checkpoint is not None:
            try:
                self._checkpoint()
            except Exception as exc:
                raise EngineError("模型响应已收到，但本地检查点未能提交；不要自动重发模型请求") from exc
        return raw, status

    def narrate_stream(self, request, on_delta):
        prose = self.narrate(request)
        on_delta(prose)
        return prose


BrowserProvider = BrowserDeepSeekProvider
