"""oc-world 首阶段实现包。"""
