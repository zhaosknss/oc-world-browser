"""Scene collaboration and chapter publication with speculative worlds kept separate.

The simulation uses a SQLite working copy. Canonical character memory only advances
when a complete chapter and its checkpoint are published in one transaction.
"""
from __future__ import annotations

import json
import os
import tempfile
import time

from . import chapter_protocol as protocol
from . import chapter_store as store
from . import context as ctxmod
from . import db, notes, settlement, story
from .engine import Runner
from .lease import StepLease
from .models import (EngineError, ProviderError, ProviderInvalidOutput, ProviderSchemaError, StepBusy,
                     classify_provider_exception, scrub_secrets, validate_intent)

# Engineering guards fail explicitly instead of disguising a truncated scene as a chapter.
MAX_SCENES = 6
MAX_ROUNDS = 4
PREPARE_CHAPTERS = 2


def _failure(exc, stage, category=None):
    """Attach fixed diagnostic names, never model text, to an existing error."""
    if not getattr(exc, "failure_stage", None):
        exc.failure_stage = stage
    if category and not getattr(exc, "failure_category", None):
        exc.failure_category = category
    return exc


def _chapter_budget(scene_number=0, round_number=0, *, boundary=False):
    return {"max_scenes": MAX_SCENES, "max_rounds_per_scene": MAX_ROUNDS,
            "scene_number": scene_number, "exchange": round_number,
            "scenes_remaining": max(0, MAX_SCENES - scene_number),
            "rounds_remaining": max(0, MAX_ROUNDS - round_number),
            "budget_boundary": boundary,
            "stage_goal": "充分展开一个实际成立的阶段，在真实变化或选择处自然停顿；未完主线可继续"}


def call(provider, role: str, system: str, payload: dict, lease: StepLease, *, tick=None, actor_id=None):
    lease.raise_if_dead()
    try:
        result = provider.chapter_role(protocol.request(role, system, payload, tick=tick, actor_id=actor_id))
    except (ProviderError, EngineError) as exc:
        raise _failure(exc, role)
    except Exception as exc:
        raise _failure(classify_provider_exception(exc, role), role) from exc
    lease.raise_if_dead()
    return result


def director_result(provider, role, payload, lease, character_ids, location_ids, *, tick):
    """One explicit structural correction, preserving all settled character choices."""
    planning = role == "director_plan"
    system = protocol.DIRECTOR if planning else protocol.DIRECTOR_REVIEW
    attempt_payload = payload
    for attempt in range(2):
        try:
            raw = call(provider, role, system, attempt_payload, lease, tick=tick)
        except ProviderInvalidOutput as exc:
            invalid = getattr(exc, "invalid_content", None)
            if attempt or not isinstance(invalid, str) or not invalid:
                raise
            attempt_payload = {**payload, "invalid_proposal": invalid,
                "correction_notes": "上一返回不是合法 JSON。按 output_schema 修正为一个完整可解析的 JSON 对象，"
                                    "保持同一规划意图与已裁定事实，只修正格式，不重新演绎人物行动。"}
            continue
        try:
            result = (protocol.plan if planning else protocol.review)(raw, character_ids, location_ids)
            scene = result["scene"] if planning else result["next_scene"]
            if scene is not None:
                actual = payload["characters"][scene["pov_actor_id"]]["location_id"]
                if scene["location_id"] != actual:
                    raise ProviderSchemaError("场景地点必须是跟随人物当前真实所在处 " + actual + "；转场前先让人物实际移动")
            return result
        except ProviderSchemaError as exc:
            if attempt:
                raise
            attempt_payload = {**payload, "invalid_proposal": raw,
                "correction_notes": str(exc) + "。只依据输入的已裁定事实修正结构，不重新演绎人物行动。"}


def world_payload(conn, runner: Runner) -> dict:
    state = runner.load_staging(conn)
    recent = [dict(row) for row in conn.execute("SELECT * FROM event ORDER BY event_id DESC LIMIT 60")]
    return {"world": state["scenario"].get("world", {}),
            "director_profiles": {person["id"]: {key: person[key] for key in
                ("voice", "relationships", "entrance_cues") if person.get(key)}
                for person in state["scenario"]["characters"]},
            "run": state["run"], "characters": state["characters"],
            "locations": state["locations"], "resources": state["resources"],
            "character_knowledge": {aid: observations[-24:] for aid, observations in state["observations"].items()},
            "private_notes": state["notes"],
            "recent_settled": list(reversed(recent)), "pending_external": state["pending_external"]}


def _place(state, pov_id) -> dict:
    loc = state["locations"][state["characters"][pov_id]["location_id"]]
    pack_loc = next(item for item in state["scenario"]["locations"] if item["id"] == loc["id"])
    return {"id": loc["id"], "name": loc["name"], "description": pack_loc.get("public_description", ""),
            "moment": loc["moment"]}


def _observable_event(row) -> dict:
    # Reasons may disclose causal information absent from the POV's observation.
    return {k: row[k] for k in ("event_id", "tick", "kind", "actor_id", "target_id",
                                "location_id", "text", "success")}


def scene_projection(conn, scene: dict, start_event_id: int, place: dict, texture: dict) -> dict | None:
    if not scene["reader_visible"]:
        return None
    pov = scene["pov_actor_id"]
    rows = []
    for row in conn.execute("SELECT * FROM event WHERE event_id>? ORDER BY event_id", (start_event_id,)):
        if pov in json.loads(row["witnesses"] or "[]") or row["actor_id"] == pov:
            rows.append(_observable_event(row))
    for eid in scene["reveal_past"]:
        row = conn.execute("SELECT * FROM event WHERE event_id=? AND event_id<=?", (eid, start_event_id)).fetchone()
        if row is None or pov not in json.loads(row["witnesses"] or "[]"):
            raise ProviderSchemaError("不能向正文揭示跟随人物未亲历的历史事件")
        rows.insert(0, _observable_event(row))
    return {"pov_actor_id": pov, "place": place, "events": rows, "craft": texture}


def _save_beat(conn, state: dict, consumed: list, tick: int) -> list[int]:
    """Same settlement semantics as legacy Runner; only the speculative DB is written."""
    stamp = db.now()
    ids = []
    with db.write_txn(conn):
        external_ids = {}
        for ev in state["new_events"]:
            auto = ev.get("auto_external")
            if auto:
                cur = conn.execute(
                    "INSERT INTO external_event(preset_key,scope,description,payload,status,created_tick,consumed_tick,created_at)"
                    " VALUES(?,?,?,?,'consumed',?,?,?)",
                    (auto["preset_key"], auto["scope"], auto["description"],
                     store.encode(auto.get("payload") or {}), tick, tick, stamp))
                ev["external_event_id"] = cur.lastrowid
            cur = conn.execute(
                "INSERT INTO event(tick,seq,kind,actor_id,target_id,location_id,text,success,reason,witnesses,external_event_id,created_at)"
                " VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
                (tick, ev["seq"], ev["kind"], ev["actor_id"], ev["target_id"],
                 ev["location_id"], ev["text"], int(ev["success"]), ev["reason"],
                 store.encode(ev["witnesses"]), ev["external_event_id"], stamp))
            event_id = cur.lastrowid
            ids.append(event_id)
            if ev["external_event_id"]:
                external_ids[ev["external_event_id"]] = event_id
            for ob in ev["observations"]:
                conn.execute(
                    "INSERT INTO observation(owner_id,tick,content,source_type,source_event_id,source_actor_id,first_hand,reliable,created_at)"
                    " VALUES(?,?,?,?,?,?,?,?,?)",
                    (ob["owner_id"], tick, ob["content"], ob["source_type"], event_id,
                     ob["source_actor_id"], ob["first_hand"], ob["reliable"], stamp))
        for ch in state["characters"].values():
            conn.execute("UPDATE character SET location_id=?,status_text=?,current_tendency=?,change_reason=?,updated_tick=? WHERE id=?",
                         (ch["location_id"], ch["status_text"], ch["current_tendency"],
                          ch["change_reason"], tick, ch["id"]))
        for loc in state["locations"].values():
            conn.execute("UPDATE location SET moment=?,state_description=? WHERE id=?",
                         (loc["moment"], loc["state_description"], loc["id"]))
        for resource in state["resources"].values():
            conn.execute("UPDATE resource SET location_id=?,holder_id=?,updated_tick=? WHERE id=?",
                         (resource["location_id"], resource["holder_id"], tick, resource["id"]))
        for aid, note in state["notes"].items():
            notes.save(conn, aid, note, stamp)
        for item in consumed:
            conn.execute("UPDATE external_event SET status='consumed',consumed_tick=?,consumed_event_id=? WHERE event_id=?",
                         (tick, external_ids.get(item["event_id"]), item["event_id"]))
        for eid, actual in external_ids.items():
            conn.execute("UPDATE external_event SET consumed_event_id=? WHERE event_id=?", (actual, eid))
        conn.execute("UPDATE run SET tick=?,world_revision=world_revision+1,status='paused',last_error=NULL,updated_at=? WHERE run_id=1",
                     (tick, stamp))
    return ids


def _actor_context(state: dict, actor_id: str, scene_number: int, round_number: int) -> dict:
    context = ctxmod.build_context(state, actor_id)
    # World adjudication reasons are not observations, including legacy failures.
    sources = {ob["source_event_id"]: ob["source_event"]
               for ob in state["observations"].get(actor_id, [])
               if ob.get("source_event_id") is not None and ob.get("source_event")}
    for observation in (context["observations"] + context["recall"]["related"] + context["known_claims"]):
        event = sources.get(observation.get("source_event_id")) or state.get("event_index", {}).get(observation.get("source_event_id"))
        if (event and event["kind"] == "act" and event["actor_id"] == actor_id
                and observation.get("source_type") == "direct"):
            observation["content"] = event["text"]
    for attempt in context["recall"]["my_attempts"]:
        attempt.pop("reason", None)
    context["recall"]["my_attempts_note"] = "这是本人已经做过的尝试与可见结果；失败不自动说明幕后原因。"
    # No scene purpose, plan, other actor notes, or future goal is given to the actor.
    context["scene"] = {"number": scene_number, "exchange": round_number}
    world = state["scenario"].get("world", {})
    context["world"]["background"] = world.get("public_description", state["scenario"].get("summary", ""))
    pack_place = next(loc for loc in state["scenario"]["locations"] if loc["id"] == context["location"]["id"])
    context["location"]["description"] = pack_place.get("public_description", "")
    public_cast = {ch["id"]: ch.get("public_description", "") for ch in state["scenario"]["characters"]}
    pronouns = {ch["id"]: ch.get("pronouns", "") for ch in state["scenario"]["characters"]}
    context["self"]["pronouns"] = pronouns.get(actor_id, "")
    for person in context["present"]:
        person["description"] = public_cast.get(person["id"], "")
        person["pronouns"] = pronouns.get(person["id"], "")
    return context


def perform_beat(conn, runner, scene, scene_number, round_number, lease) -> tuple[list[int], dict]:
    state = runner.load_staging(conn)
    tick = state["run"]["tick"] + 1
    state["run"]["tick"] = tick
    consumed = runner._apply_external(state)
    world_feedback = {}
    if round_number == 1 and scene["proposed_event"] is not None:
        proposed = scene["proposed_event"]
        try:
            if isinstance(proposed, dict) and any(key in proposed for key in ("kind", "action", "actor_id", "target_id")):
                raise ProviderSchemaError("外界提案不能替人物决定动作，须由角色自己选择")
            turn = story.validate_turn({"open_questions": "", "focus": {"actors": [], "locations": []},
                                       "event": proposed}, state["scenario"],
                                      set(state["characters"]), set(state["locations"]))
        except ProviderSchemaError as exc:
            # A proposed change is optional, not a settled fact. Reject it and tell
            # the director; never reinterpret a malformed proposal as an event.
            world_feedback = {"approved": False, "reason": str(exc)}
        else:
            raw = protocol.object_output(call(runner.provider, "world_event", protocol.WORLD,
                {"proposed_event": turn["event"], "world": state["scenario"].get("world", {}),
                 "locations": state["locations"], "characters": state["characters"],
                 "resources": state["resources"]}, lease, tick=tick), "world_event")
            if type(raw.get("approved")) is not bool:
                raise ProviderSchemaError("世界裁定 approved 必须是布尔值")
            world_feedback = {"approved": raw["approved"], "reason": protocol.text(raw.get("reason"), "world.reason")}
            if raw["approved"] and turn["event"]:
                runner._apply_world_event(state, turn["event"])
    # The director chooses who starts this exchange. A successful, heard address
    # also gives its recipient a turn; it does not prescribe their response or
    # expose private knowledge. Keep the initial order and append recipients.
    actor_queue = list(scene["actors"])
    scheduled = set(actor_queue)
    for actor_id in actor_queue:
        context = _actor_context(state, actor_id, scene_number, round_number)
        raw = protocol.object_output(call(runner.provider, "actor_perform", protocol.ACTOR,
                                         context, lease, tick=tick, actor_id=actor_id), "actor_perform")
        actions = raw.get("actions")
        if not isinstance(actions, list) or not 1 <= len(actions) <= 6:
            raise ProviderSchemaError("人物表演 actions 需要一组 1–6 个连续动作")
        if not isinstance(raw.get("state") or {}, dict):
            raise ProviderSchemaError("人物 state 必须是对象")
        note = dict(raw.get("state") or {})
        if "clear_state" in raw:
            note["clear"] = raw["clear_state"]
        try:
            update, _ = notes.normalize(note)
        except ValueError as exc:
            raise ProviderSchemaError(str(exc)) from exc
        for action in actions:
            if isinstance(action, dict):
                action = dict(action)
                # Some valid descriptions arrive in text with an empty act target.
                # Preserve that exact declared intention; never invent an action.
                if (action.get("action") == "act" and not action.get("target")
                        and isinstance(action.get("text"), str) and action["text"].strip()):
                    action["target"] = action["text"]
            intent = validate_intent(action, actor_id, set(state["characters"]), set(state["locations"]),
                                     {aid: ch["location_id"] for aid, ch in state["characters"].items()})
            state["seq"] += 1
            if intent["action"] == "act":
                try:
                    result, origin = runner._single_settle(state, intent,
                        _actor_context(state, actor_id, scene_number, round_number), tick)
                except (ProviderError, EngineError) as exc:
                    raise _failure(exc, "settle", "structure" if isinstance(exc, ProviderSchemaError) else None)
                lease.raise_if_dead()
                ev = settlement.settle_complex(state, intent, result, tick, state["seq"], origin)
                if not result["success"] and ev["reason"] == result["reason"]:
                    # The failed intention is not a description of what existed or
                    # partly succeeded. Preserve the adjudicator's observable result;
                    # causal reasons stay in the world event, outside actor knowledge.
                    visible = result["fact_text"].replace("{name}", state["characters"][actor_id]["name"])
                    ev["text"] = visible + "（这次尝试未完成。）"
                if not ev["success"]:
                    ev["observations"] = [settlement._obs(witness, tick, ev["text"], "direct")
                        for witness in sorted(set(ev["witnesses"]) | {actor_id})]
            else:
                ev = runner._settle_simple(state, intent, tick, state["seq"], True)
            settlement.apply_event(state, ev)
            target = ev["target_id"]
            if (ev["kind"] == "speak" and ev["success"]
                    and target in ev["witnesses"] and target in state["characters"]
                    and target not in scheduled):
                actor_queue.append(target)
                scheduled.add(target)
        merged, changed = notes.merge(state["notes"].get(actor_id), update, tick)
        if changed:
            state["notes"][actor_id] = merged
    return _save_beat(conn, state, consumed, tick), world_feedback


def simulate(conn, provider, runner, number, continuity, previous_digest, lease,
             *, resumed=None, checkpoint=None) -> tuple:
    state = runner.load_staging(conn)
    ids, lids = set(state["characters"]), set(state["locations"])
    progress = dict(resumed or {})

    def save():
        if checkpoint is not None:
            checkpoint(store.snapshot(conn), progress)

    if not progress:
        start_tick = state["run"]["tick"]
        payload = {**world_payload(conn, runner), "chapter_number": number,
                   "continuity": continuity, "reader_previous": previous_digest,
                   "chapter_budget": _chapter_budget(),
                   "output_schema": {"title": "章名", "throughline": "这一阶段的故事脉络",
                     "chapter_goal": "这一章要展开的事件与变化", "ending_aim": "自然停顿的依据",
                     "scene": {"actors": [sorted(ids)[0]], "pov_actor_id": sorted(ids)[0],
                      "location_id": state["characters"][sorted(ids)[0]]["location_id"],
                      "reader_visible": True, "purpose": "导演私有目的",
                      "proposed_event": None, "reveal_past": []}}}
        try:
            plan = director_result(provider, "director_plan", payload, lease, ids, lids, tick=start_tick)
        except (ProviderError, EngineError) as exc:
            raise _failure(exc, "director_plan", "structure" if isinstance(exc, ProviderSchemaError) else None)
        progress = {"start_tick": start_tick, "plan": plan, "scene": plan["scene"],
                    "scene_number": 1, "round_number": 1, "visible_scenes": [],
                    "last_review": None, "phase": "scene_setup"}
        save()
    while progress["phase"] != "complete":
        phase = progress["phase"]
        scene, scene_number = progress["scene"], progress["scene_number"]
        round_number = progress["round_number"]
        try:
            if phase == "scene_setup":
                state = runner.load_staging(conn)
                pov = scene["pov_actor_id"]
                if state["characters"][pov]["location_id"] != scene["location_id"]:
                    raise ProviderSchemaError("场景地点必须是跟随人物当前真实所在处，转场先实际移动")
                progress.update({"place": _place(state, pov), "texture": {}, "scene_recorded": False,
                    "start_id": conn.execute("SELECT COALESCE(MAX(event_id),0) n FROM event").fetchone()["n"],
                    "phase": "craft"})
            elif phase == "craft":
                if scene["reader_visible"]:
                    state = runner.load_staging(conn)
                    place = progress["place"]
                    texture = protocol.object_output(call(provider, "writer_craft", protocol.CRAFT,
                        {"place": place, "characters": ctxmod.expression_cast(state["scenario"],
                            {aid for aid, ch in state["characters"].items() if ch["location_id"] == place["id"]}),
                         "narration": ctxmod.narration_preferences(state["scenario"]),
                         "prior_visible": progress["visible_scenes"][-1:]}, lease,
                         tick=state["run"]["tick"]), "writer_craft")
                    progress["texture"] = {key: protocol.text(texture.get(key), key)
                                           for key in ("texture", "dialogue_direction")}
                progress["phase"] = "beat"
            elif phase == "beat":
                _, feedback = perform_beat(conn, runner, scene, scene_number, round_number, lease)
                progress.update({"world_feedback": feedback, "phase": "review"})
            elif phase in ("review", "boundary"):
                boundary = phase == "boundary" or round_number == MAX_ROUNDS
                data = {**world_payload(conn, runner), "plan": progress["plan"], "scene": scene,
                        "chapter_number": number, "scene_number": scene_number,
                        "exchange": round_number, "expression_suggestions": progress["texture"],
                        "world_feedback": progress.get("world_feedback", {}),
                        "chapter_budget": _chapter_budget(scene_number, round_number, boundary=boundary),
                        "output_schema": {"scene_done": False, "chapter_done": False,
                           "closure": "", "continuity": "已经成立的线索和后续未完问题",
                           "next_scene": None}}
                review = director_result(provider, "director_review", data, lease, ids, lids,
                                         tick=data["run"]["tick"])
                progress["last_review"] = review
                if review["scene_done"]:
                    progress["phase"] = "scene_complete"
                elif boundary:
                    kind = progress.get("boundary_kind", "round_limit")
                    progress.update({"phase": "boundary", "boundary_kind": kind})
                    save()
                    message = ("本章仍未形成阶段落点；超过场景保护上限，未发布截断正文"
                               if kind == "scene_limit" else
                               "当前场景尚未到自然停顿；超过演绎保护轮数，推演进度已保存，未发布半章")
                    raise _failure(EngineError(message), "director_review", kind)
                else:
                    progress.update({"round_number": round_number + 1, "phase": "beat"})
            elif phase == "scene_complete":
                if not progress["scene_recorded"]:
                    projection = scene_projection(conn, scene, progress["start_id"],
                                                  progress["place"], progress["texture"])
                    if projection is not None and projection["events"]:
                        progress["visible_scenes"].append(projection)
                    progress["scene_recorded"] = True
                review = progress["last_review"]
                if review["chapter_done"]:
                    progress["phase"] = "complete"
                elif scene_number >= MAX_SCENES:
                    progress.update({"phase": "boundary", "boundary_kind": "scene_limit"})
                    save()
                    raise _failure(EngineError("本章仍未形成阶段落点；超过场景保护上限，推演进度已保存"),
                                   "director_review", "scene_limit")
                else:
                    progress.update({"scene": review["next_scene"], "scene_number": scene_number + 1,
                                     "round_number": 1, "phase": "scene_setup"})
                    progress.pop("boundary_kind", None)
            else:
                raise EngineError("章节恢复检查点阶段无效")
            # Checkpoints contain only completed beats. A failed in-flight beat can
            # replay that beat, but previous settled exchanges are never rerun.
            save()
        except (ProviderError, EngineError) as exc:
            stage = {"craft": "writer_craft", "beat": "actor_perform",
                     "review": "director_review", "boundary": "director_review"}.get(phase, "simulation")
            raise _failure(exc, stage, "structure" if isinstance(exc, ProviderSchemaError) else None)
    plan, last_review = progress["plan"], progress["last_review"]
    start_tick, visible_scenes = progress["start_tick"], progress["visible_scenes"]
    if not visible_scenes:
        raise ProviderSchemaError("本章没有允许读者看见的场景与实际进展")
    end_tick = conn.execute("SELECT tick FROM run WHERE run_id=1").fetchone()["tick"]
    world = state["scenario"].get("world", {})
    visible_ids = {s["pov_actor_id"] for s in visible_scenes}
    visible_ids.update(e.get(key) for s in visible_scenes for e in s["events"]
                       for key in ("actor_id", "target_id") if e.get(key) in ids)
    projection = {"chapter_number": number,
        "public_background": world.get("public_description", state["scenario"].get("summary", "")),
        "cast": ctxmod.expression_cast(state["scenario"], visible_ids),
        "narration": ctxmod.narration_preferences(state["scenario"]),
        "reader_previous": previous_digest, "scenes": visible_scenes,
        "ticks": [start_tick + 1, end_tick],
        "reader_event_ids": sorted({e["event_id"] for s in visible_scenes for e in s["events"]})}
    # The private chapter title/ending/continuity are not sent to prose or the reading page.
    return plan, last_review["continuity"], projection, store.snapshot(conn)


def _write(conn, row, provider, lease, rid, owner, revision, anchor) -> None:
    try:
        _write_draft(conn, row, provider, lease, rid, owner, revision, anchor)
    except (ProviderError, EngineError) as exc:
        raise _failure(exc, "writer_chapter", "structure" if isinstance(exc, ProviderSchemaError) else None)


def _write_draft(conn, row, provider, lease, rid, owner, revision, anchor) -> None:
    projection = json.loads(row["projection"])
    writing_input = dict(projection)
    if row["error"]:
        # A resumed draft keeps the failed review's concrete feedback; its scenes stay fixed.
        writing_input["revision_notes"] = row["error"]
    prose = call(provider, "writer_chapter", protocol.WRITER, writing_input, lease,
                 tick=projection["ticks"][1])
    if not isinstance(prose, str) or not prose.strip():
        raise ProviderSchemaError("章节正文为空")
    for attempt in range(2):
        try:
            verdict = protocol.object_output(call(provider, "editor_review", protocol.EDITOR,
                {"allowed": projection, "prose": prose}, lease, tick=projection["ticks"][1]), "editor_review")
            if type(verdict.get("approved")) is not bool:
                raise ProviderSchemaError("正文核查 approved 必须是布尔值")
            feedback = "" if verdict["approved"] else protocol.text(verdict.get("rewrite_notes"), "rewrite_notes", required=True)
        except (ProviderError, EngineError) as exc:
            raise _failure(exc, "editor_review", "structure" if isinstance(exc, ProviderSchemaError) else None)
        if verdict["approved"]:
            break
        if attempt:
            raise _failure(ProviderSchemaError("正文仍未通过事实与信息边界核查：" + feedback), "editor_review", "review")
        prose = call(provider, "writer_chapter", protocol.WRITER,
                     {**projection, "previous_draft": prose, "revision_notes": feedback},
                     lease, tick=projection["ticks"][1])
        if not isinstance(prose, str) or not prose.strip():
            raise ProviderSchemaError("修订章节正文为空")
    digest = "\n".join(e["text"] for s in projection["scenes"] for e in s["events"])[-4000:]
    with db.write_txn(conn):
        store.check_owner(conn, rid, owner, revision, anchor)
        conn.execute("UPDATE chapter SET status='prepared',prose=?,reader_digest=?,error=NULL WHERE chapter_id=?",
                     (prose.strip(), digest, row["chapter_id"]))


def _prepare(conn, provider, rid, owner, revision, anchor, lease, number, continuity, previous_digest, base_state):
    count = getattr(provider, "config", {}).get("prepare_chapters", PREPARE_CHAPTERS)
    if type(count) is not int or count not in (1, 2):
        raise _failure(EngineError("prepare_chapters 需要为 1 或 2"), "simulation", "engine")
    # The directory is generated under this story and only contains this request's work copy.
    workspace = os.path.join(os.path.dirname(os.path.abspath(provider_db_path(conn))), ".chapter-work")
    os.makedirs(workspace, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="request-", dir=workspace) as tmp:
        path = os.path.join(tmp, "simulation.db")
        sim = db.connect(path)
        try:
            db.init_schema(sim)
            with db.write_txn(sim):
                store.restore(sim, base_state)
                scenario = conn.execute("SELECT value FROM meta WHERE key='scenario_json'").fetchone()["value"]
                sim.execute("INSERT OR REPLACE INTO meta(key,value) VALUES('scenario_json',?)", (scenario,))
            runner = Runner(path, provider)
            for offset in range(count):
                chapter_number = number + offset
                base = store.signature(store.snapshot(sim))
                work = store.load_work(conn, revision, chapter_number, base)
                if work is not None:
                    with db.write_txn(sim):
                        store.restore(sim, work["simulation"])
                def checkpoint(simulation, progress):
                    store.save_work(conn, rid, owner, revision, anchor, chapter_number, base,
                                    simulation, progress)
                    flush = getattr(provider, "_checkpoint", None)
                    if callable(flush):
                        try:
                            flush()
                        except Exception as exc:
                            raise _failure(EngineError("推演检查点已提交到工作库，但设备保存未完成"),
                                           "saving", "storage") from exc
                try:
                    plan, continuity, projection, end_state = simulate(sim, provider, runner, chapter_number,
                        continuity, previous_digest, lease,
                        resumed=work["progress"] if work is not None else None, checkpoint=checkpoint)
                except (ProviderError, EngineError) as exc:
                    if offset:
                        return _preparation_failure(conn, rid, exc)
                    raise
                with db.write_txn(conn):
                    store.check_owner(conn, rid, owner, revision, anchor)
                    conn.execute("INSERT INTO chapter(number,revision,status,title,base_signature,end_state,projection,plan,continuity,created_at)"
                        " VALUES(?,?,'draft',?,?,?,?,?,?,?)",
                        (chapter_number, revision, "第 " + str(chapter_number) + " 章",
                         base, store.encode(end_state), store.encode(projection), store.encode(plan),
                         continuity, db.now()))
                    store.clear_work(conn, revision, chapter_number)
                row = conn.execute("SELECT * FROM chapter WHERE revision=? AND number=?", (revision, chapter_number)).fetchone()
                try:
                    _write(conn, row, provider, lease, rid, owner, revision, anchor)
                except (ProviderError, EngineError) as exc:
                    with db.write_txn(conn):
                        conn.execute("UPDATE chapter SET error=? WHERE chapter_id=? AND status='draft'",
                                     (scrub_secrets(str(exc)), row["chapter_id"]))
                    if offset:
                        return _preparation_failure(conn, rid, exc)
                    raise
                previous_digest = _previous_visible(conn.execute("SELECT prose,projection FROM chapter WHERE chapter_id=?",
                                                                  (row["chapter_id"],)).fetchone())
        finally:
            sim.close()
    return ""


def _preparation_failure(conn, rid, exc) -> str:
    message = scrub_secrets(str(exc))
    with db.write_txn(conn):
        tick = conn.execute("SELECT tick FROM run WHERE run_id=1").fetchone()["tick"]
        conn.execute("INSERT INTO error_log(request_id,tick,stage,error_type,message,created_at) VALUES(?,?,?,?,?,?)",
                     (rid, tick, "chapter_future", getattr(exc, "error_type", type(exc).__name__), message, db.now()))
    return "当前章节已完整保存，后续准备暂未通过；下次继续时会恢复或重新准备未读内容。"


def _previous_visible(row) -> dict:
    if row is None:
        return {"prose": "", "settled": []}
    projection = json.loads(row["projection"])
    events = [event for scene in projection["scenes"] for event in scene["events"]]
    return {"prose": row["prose"][-10000:], "settled": events[-40:]}


def provider_db_path(conn) -> str:
    return conn.execute("PRAGMA database_list").fetchone()["file"]


def _public_failure(conn, exc, request_id):
    categories = {"round_limit", "scene_limit", "structure", "review", "provider", "engine", "storage"}
    stages = {"director_plan", "director_review", "writer_craft", "actor_perform", "settle",
              "settle_batch", "world_event", "writer_chapter", "editor_review", "simulation", "saving"}
    category = getattr(exc, "failure_category", None)
    if category not in categories:
        category = ("structure" if isinstance(exc, ProviderSchemaError) else
                    "provider" if isinstance(exc, ProviderError) else "engine")
    stage = getattr(exc, "failure_stage", None)
    if stage not in stages:
        stage = "simulation"
    mode = "restart"
    try:
        checkpoint = store.state_row(conn)
        params = (checkpoint["revision"], checkpoint["cursor"] + 1)
        if conn.execute("SELECT 1 FROM chapter WHERE revision=? AND number=? AND status='draft'", params).fetchone():
            mode = "writing"
        elif conn.execute("SELECT 1 FROM chapter_work WHERE revision=? AND number=?", params).fetchone():
            mode = "simulation"
    except Exception:
        pass
    issue = store.provider_issue(str(exc))
    message = store.failure_message(category, stage, mode, issue)
    return {"ok": False, "error": message, "error_type": getattr(exc, "error_type", type(exc).__name__),
            "request_id": request_id, "failure_category": category, "failure_stage": stage,
            "recovery_mode": mode, "recovery_available": mode != "restart",
            "provider_issue": issue,
            "revision": store.state_row(conn)["revision"]}


def continue_chapter(db_path, provider, request_id, on_advanced=None, on_chunk=None) -> dict:
    started = time.perf_counter() * 1000
    conn = db.connect(db_path)
    lease = None
    owner = None
    try:
        store.ensure_work_schema(conn)
        if conn.execute("SELECT status FROM run WHERE run_id=1").fetchone()["status"] == "ended":
            return {"action": "ended", "message": "这份故事已经结束，可以继续阅读已保存正文",
                    "advanced": None, "prose": None, "accounting": None, "timing": {}}
        owner, deduped = store.claim(conn, request_id)
        if deduped is not None:
            return deduped
        lease = StepLease(db_path, request_id, owner, table="chapter_request")
        lease.start()
        checkpoint = store.state_row(conn)
        revision = checkpoint["revision"]
        canonical = store.snapshot(conn)
        anchor = store.signature(canonical)
        number = checkpoint["cursor"] + 1
        row = conn.execute("SELECT * FROM chapter WHERE revision=? AND number=? AND status IN ('draft','prepared')",
                           (revision, number)).fetchone()
        cache_hit = row is not None and row["status"] == "prepared" and row["base_signature"] == anchor
        warning = ""
        if row is not None and row["base_signature"] != anchor:
            with db.write_txn(conn):
                store.invalidate(conn, "当前节点事实或条件已经改变")
            revision = store.state_row(conn)["revision"]
            row = None
        if row is None:
            previous = conn.execute("SELECT prose,projection FROM chapter WHERE status='published' ORDER BY chapter_id DESC LIMIT 1").fetchone()
            reader_previous = _previous_visible(previous)
            if previous is None:
                legacy = conn.execute("SELECT prose FROM prose_segment WHERE tick<=? AND status='committed' ORDER BY tick DESC LIMIT 1",
                                      (checkpoint["cutover_tick"],)).fetchone()
                if legacy is not None:
                    reader_previous["prose"] = legacy["prose"][-10000:]
            try:
                warning = _prepare(conn, provider, request_id, owner, revision, anchor, lease, number,
                         checkpoint["continuity"], reader_previous, canonical)
            except (ProviderError, EngineError):
                # A complete first chapter survives a later speculative failure.
                first = conn.execute("SELECT * FROM chapter WHERE revision=? AND number=? AND status='prepared'",
                                     (revision, number)).fetchone()
                if first is None:
                    raise
            row = conn.execute("SELECT * FROM chapter WHERE revision=? AND number=?", (revision, number)).fetchone()
        elif row["status"] == "draft":
            _write(conn, row, provider, lease, request_id, owner, revision, anchor)
        row = conn.execute("SELECT * FROM chapter WHERE chapter_id=?", (row["chapter_id"],)).fetchone()
        if row["status"] != "prepared":
            raise EngineError("章节尚未完整保存，当前阅读节点保持原样")
        lease.raise_if_dead()
        accounting = provider.take_stats()
        accounting["cache_hit"] = cache_hit
        result = store.publish(conn, row, request_id, owner, revision, anchor, accounting, started,
                               warning)
        result["cache_hit"] = cache_hit
        # Prose deltas only contain a fully validated, atomically published chapter.
        if on_advanced is not None:
            on_advanced(result["advanced"], accounting)
        if on_chunk is not None:
            on_chunk(result["prose"]["segment"]["prose"])
        return result
    except StepBusy:
        raise
    except (ProviderError, EngineError) as exc:
        error = scrub_secrets(str(exc))
        failure = _public_failure(conn, exc, request_id)
        if owner is not None:
            store.fail(conn, request_id, owner, error, failure)
        return {"action": "advance_failed", "advanced": failure,
                "prose": None, "accounting": provider.take_stats(), "engine_mode": "chapters",
                "timing": {"complete_ms": round(time.perf_counter() * 1000 - started, 3)}}
    except Exception as exc:
        error = scrub_secrets(f"章节保存失败：{type(exc).__name__}: {exc}")
        _failure(exc, "saving", "storage")
        failure = _public_failure(conn, exc, request_id)
        if owner is not None:
            store.fail(conn, request_id, owner, error, failure)
        return {"action": "advance_failed", "advanced": failure,
                "prose": None, "accounting": provider.take_stats(), "engine_mode": "chapters",
                "timing": {"complete_ms": round(time.perf_counter() * 1000 - started, 3)}}
    finally:
        if lease is not None:
            lease.stop()
        conn.close()
