"""熊出没展示的最小演示层：运行包载入、开场 IF、批次上限、结束冻结。

这一层只做展示需要的事，世界结算、角色决策与正文仍走原有模块：

    run.py --pack scenarios/boonie-early.json [--fake-overlay …] --provider …
        → bootstrap 运行包
        → /api/start 把用户的一句 IF 变成**本次运行的有效起始条件**（只此一次）
        → /api/continue 逐刻推进 + 写正文（前台按批调度）
        → /api/end 冻结这次故事（区分「暂停」与「结束」）

IF 的表达范围（和包里的 demo.if_supported 一致，超出一律拒绝并说明，不静默替换）：

| IF 类型 | 落地方式 | 只影响谁 |
|---|---|---|
| 环境/现场（天气、结冰、封路…） | 外部事件 + `location_changes` | 范围内可见 |
| 一句传到某人耳朵里的话 | 外部事件 + `claim`（按「说法」，不可靠） | 指定的人 |
| 全场都能看到/听到的事 | 外部事件 + `direct_observation` | 全部 |
| 开局位置 | 初始化阶段改 `character.location_id`（只限已有地点） | 那个人 |
| 开局物品归属 | 初始化阶段改 `resource.location_id/holder_id`（只限已有物品） | 世界状态 |

不能表达的一律**拒绝并说明原因**：改人物性格/立场/目标、新增角色或地点或物品、
把东西写成「坏了」、改写已有故事、替这次故事预定结局。

失败怎么处理（2026-09-21 修正）：**真实模式只认模型的结果**——模型拒绝（`applicable=false`）、
调用异常、或输出不符合结构时，说明原因并停止开演，不自动改走本地关键词规则；
**模拟模式**没有模型可用才走本地规则，本地规则认不出同样拒绝，不兜底成「全场发生的一件事」。
两种情况都不写起始条件、不动世界状态，也不自动重发。
"""
from __future__ import annotations

import json
import os

from . import db, scenario as scenario_mod
from .lease import DEFAULT_LEASE_MS, lease_alive
from .models import LeaseLost, ProviderError, ProviderSchemaError

DEMO_ROOT = os.path.join("local-data", "boonie-demo")
DEFAULT_BATCH_TICKS = 12
IF_EVENT_KEY = "if_start"
IF_PATCH_KINDS = ("environment", "rumor", "observed", "position", "resource")

# 本演示的用户用语要求：熊大、熊二互相称呼与旁白都用名字，不用「哥/哥哥/弟弟」代替姓名。
# 按**运行包 id** 生效，所以用户当前那份存档（库内快照里没有这段）继续生成时也拿得到，
# 不需要 reset，也不改库。这是用语要求，不改兄弟关系，也不是原作考据结论；
# 自然的代词（他、他们、两人）照常用，不做机械替换。
# 新版三人包（boonie-early-story，剧情体验改造）同样登记在这里：新包自己在快照里写了
# 这段约定，这里再兜一份，免得同一套称呼约定在换包时丢掉。
DEMO_CONVENTIONS = {
    "boonie-early": [
        "称呼约定（本演示的用语要求）：熊大与熊二互相称呼直接用「熊大」「熊二」，"
        "不要用「哥」「哥哥」「弟弟」这类亲属称谓代替姓名；旁白提到人物也按姓名写。"
        "兄弟关系不变；自然的代词（他、他们、两个人）照常用，不要做机械替换。"
    ],
    "boonie-early-story": [
        "称呼约定（本演示的用语要求）：熊大与熊二互相称呼直接用「熊大」「熊二」，"
        "不要用「哥」「哥哥」「弟弟」这类亲属称谓代替姓名；旁白提到人物也按姓名写。"
        "兄弟关系不变；自然的代词（他、他们、两个人）照常用，不要做机械替换。"
    ],
}

# 本地规则用的词表。它们只决定「这句话更像哪一类条件」，不解释内容——
# 模拟模式和模型不可用时走这条路，结果一律标注来源为本地规则。
_WEATHER = ("雨", "雪", "冰", "雾", "风", "雷", "雹", "旱", "冷", "热", "天气", "天黑", "封路", "停电")
_RUMOR = ("听说", "传言", "有人说", "带话", "电话", "消息", "风声", "口信")
_SEE = ("看到", "看见", "发现", "亲眼", "都瞧见")
_POSITION = ("一早", "不在", "去了", "跑到", "待在", "留在", "已经到", "就在")
# 损坏类：现有资源语义只有「在哪、在谁手上」，这些写法一律拒绝并说明，
# 不能因为句子里同时有物品名和人名就当成一次归属变化。
_DAMAGE = ("坏", "坏掉", "不能用了", "不能用", "报废", "失灵", "故障", "断了", "散架", "烧了", "爆了")
_HYPOTHETICAL = ("如果", "假如", "要是", "假设", "万一")


class DemoError(Exception):
    pass


# ------------------------------------------------------------------ 包与配置


def conventions_for(scenario: dict) -> list[str]:
    """本世界的用语约定（称呼等）。

    优先用运行包里声明的（进库快照）；没有就用按包 id 兜底的那份，
    这样已经存在的存档（快照里没有这段）继续生成时也遵守同一套约定。
    """
    declared = scenario.get("conventions") if isinstance(scenario, dict) else None
    out: list[str] = []
    if isinstance(declared, list):
        for item in declared:
            text = item.get("text") if isinstance(item, dict) else item
            if str(text or "").strip():
                out.append(str(text).strip())
    if out:
        return out
    scenario_id = (scenario or {}).get("scenario_id") if isinstance(scenario, dict) else None
    return list(DEMO_CONVENTIONS.get(scenario_id, []))


def batch_limit(scenario: dict) -> int:
    value = (scenario.get("demo") or {}).get("max_batch_ticks")
    try:
        limit = int(value)
    except (TypeError, ValueError):
        return DEFAULT_BATCH_TICKS
    return limit if limit > 0 else DEFAULT_BATCH_TICKS


def if_help(scenario: dict) -> dict:
    """给页面用的 IF 说明：支持什么、不支持什么、示例、范围词表。"""
    demo = scenario.get("demo") or {}
    return {
        "supported": list(demo.get("if_supported") or ["环境与现场变化", "一句传闻或消息", "人物可见的一件事",
                                                        "已有地点间的开局位置", "已有物品的开局归属"]),
        "unsupported": list(demo.get("if_unsupported") or ["新增或改写人物、地点与物品", "改人物性格与目标",
                                                            "改写已有故事或预定结局", "把已有物品写成损坏"]),
        "examples": list(demo.get("if_examples") or ["一场大雨让原定的安排被打乱了。", "有人带来一条尚未证实的消息。"]),
        "max_batch_ticks": batch_limit(scenario),
        "characters": [{"id": ch["id"], "name": ch["name"]}
                       for ch in scenario.get("characters", [])],
        "locations": [{"id": loc["id"], "name": loc["name"]}
                      for loc in scenario.get("locations", [])],
        "resources": [{"id": res["id"], "name": res.get("name", res["id"])}
                      for res in scenario.get("resources", [])],
    }


def pack_report(scenario: dict, pack_path: str) -> dict:
    """载入检查：需要什么、包里有什么、来源能不能追。

    只报事实，不替包内容背书；`script_present` 是真假包的分界线——
    正式运行包不应该带预写行动（provider_script）与模拟结算（complex_rules）。
    """
    sources = scenario.get("sources") or []
    refs = sorted({ref for item in sources for ref in (item.get("refs") or [])})
    characters = scenario.get("characters", [])
    locations = scenario.get("locations", [])
    resources = scenario.get("resources", [])
    from . import story as story_mod          # 局部导入：避免与演示层初始化顺序纠缠
    story_loop = story_mod.loop_config(scenario)
    warnings = []
    if scenario.get("provider_script"):
        warnings.append("包里带了 provider_script（预写行动），正式运行不应该有；"
                        "只有模拟覆盖数据才允许。")
    if scenario.get("complex_rules"):
        warnings.append("包里带了 complex_rules（模拟结算结果），正式运行不应该有。")
    if scenario.get("world_script"):
        warnings.append("包里带了 world_script（预写世界回合），正式运行不应该有；"
                        "只有模拟覆盖数据才允许。")
    for ch in characters:
        if not ch.get("goals"):
            warnings.append(f"人物 {ch['id']} 没有 goals（本人目标），决策输入会缺少本人目标。")
        if not ch.get("current_tendency"):
            warnings.append(f"人物 {ch['id']} 没有 current_tendency（情境倾向）。")
    if not sources:
        warnings.append("包没有 sources（来源关联），无法按字段追溯资料。")
    return {
        "pack": os.path.basename(pack_path),
        "scenario_id": scenario.get("scenario_id"),
        "version": scenario.get("version"),
        "title": scenario.get("title", ""),
        "characters": [{"id": ch["id"], "name": ch["name"],
                        "has_goals": bool(ch.get("goals")),
                        "has_tendency": bool(ch.get("current_tendency"))}
                       for ch in characters],
        "locations": [loc["name"] for loc in locations],
        "resources": [res.get("name", res["id"]) for res in resources],
        "presets": [p["key"] for p in scenario.get("presets", [])],
        "source_entries": len(sources),
        "source_refs": refs,
        "script_present": bool(scenario.get("provider_script")),
        "complex_rules_present": bool(scenario.get("complex_rules")),
        "world_script_present": bool(scenario.get("world_script")),
        "story_loop": story_loop.get("enabled", False),
        "max_batch_ticks": batch_limit(scenario),
        "warnings": warnings,
    }


def load_run_scenario(pack_path: str, overlay_path: str | None = None) -> dict:
    """载入正式运行包；可叠加一份**只给模拟模式用**的覆盖数据。

    覆盖数据只允许补 provider_script / complex_rules / world_script
    （预写行动、模拟结算结果、预写世界回合），用来在没有真实模型时走通流程；
    它不会进入正式包，也不被真实适配器读取。
    """
    scenario = scenario_mod.load_scenario(pack_path)
    if not overlay_path:
        return scenario
    with open(overlay_path, "r", encoding="utf-8") as fh:
        overlay = json.load(fh)
    base_report = pack_report(scenario, pack_path)
    if not base_report["script_present"]:
        scenario["provider_script"] = overlay.get("provider_script", [])
        scenario["complex_rules"] = overlay.get("complex_rules", [])
    if not base_report["world_script_present"]:
        scenario["world_script"] = overlay.get("world_script", [])
    demo = dict(scenario.get("demo") or {})
    demo["overlay_used"] = os.path.basename(overlay_path)
    scenario["demo"] = demo
    return scenario


# ------------------------------------------------------------------ IF 解析


def _name_index(scenario: dict) -> dict[str, str]:
    index: dict[str, str] = {}
    for ch in scenario.get("characters", []):
        index[ch["name"]] = ch["id"]
        index[ch["id"]] = ch["id"]
    return index


def _location_index(scenario: dict) -> dict[str, str]:
    index: dict[str, str] = {}
    for loc in scenario.get("locations", []):
        index[loc["name"]] = loc["id"]
        index[loc["id"]] = loc["id"]
    return index


_MEASURE = ("一罐", "一把", "一堆", "一袋", "一块", "一张", "一瓶", "一箱", "一个",
            "几罐", "那罐", "那把", "那堆")


def _resource_keys(name: str) -> list[str]:
    """物品名的可匹配写法：全名 + 去掉量词的短名（「一罐蜂蜜」→「蜂蜜」）。

    读者写「那罐蜂蜜」不会等于包里的「一罐蜂蜜」，只按全名匹配会漏掉，
    漏掉之后这句话会被当成别的类型（例如把光头强挪到自己的小屋），
    所以这里额外收一个短名。
    """
    keys = [name]
    for prefix in _MEASURE:
        if name.startswith(prefix) and len(name) > len(prefix):
            keys.append(name[len(prefix):])
    return keys


def _resource_index(scenario: dict) -> dict[str, str]:
    index: dict[str, str] = {}
    for res in scenario.get("resources", []):
        name = res.get("name", res["id"])
        for key in _resource_keys(name):
            index[key] = res["id"]
        index[res["id"]] = res["id"]
    return index


def _mentions(text: str, index: dict[str, str]) -> list[str]:
    """按名称长度从长到短匹配，避免「熊大」被「熊」之类的短名抢先命中。"""
    hits: list[str] = []
    for name in sorted(index, key=len, reverse=True):
        if name and name in text and index[name] not in hits:
            hits.append(index[name])
    return hits


def _declarative(text: str) -> str:
    """把 IF 的假设语气收成一句陈述，供世界事件使用。

    只做很轻的处理（去掉开头的「如果/假如/要是/万一」与结尾的「的话」），
    不做改写；拿不准就保留原句。
    """
    line = (text or "").strip().rstrip()
    changed = True
    while changed:
        changed = False
        for word in _HYPOTHETICAL:
            if line.startswith(word):
                line = line[len(word):].lstrip()
                changed = True
    for tail in ("的话", "的話"):
        if line.endswith(tail):
            line = line[: -len(tail)]
    line = line.strip("，,、 ")
    if line and line[-1] not in "。！？!?…":
        line += "。"
    return line


def interpret_if_local(text: str, scenario: dict, note: str | None = None) -> dict:
    """本地规则：把一句 IF 归到五类条件里的一类。

    **认不出就不接**：以前最后有一条「没匹配到就当成全场发生的一件事」的兜底，
    结果「某件东西坏了」这类条件只要句子里同时出现物品名和人名，就会被接成归属变化。
    现在没匹配上直接报错并说明原因，页面照原话显示，不静默改成本次条件。

    结果里 source 写明是本地规则；这一类映射只保证「落地点合法」，不假装理解语义。
    """
    raw = (text or "").strip()
    if not raw:
        raise DemoError("IF 不能为空。")
    if len(raw) > 200:
        raise DemoError("IF 请控制在 200 字以内（现在的做法是把它作为本次运行的开场条件）。")
    sentence = _declarative(raw)
    chars = _name_index(scenario)
    locs = _location_index(scenario)
    res = _resource_index(scenario)
    hit_chars = _mentions(raw, chars)
    hit_locs = _mentions(raw, locs)
    hit_res = _mentions(raw, res)

    # 0) 损坏类先说清楚：现有结算只表达「在哪、在谁手上」，不能表达「坏了」。
    #    这条要在物品规则之前判，否则会把它误接成一次归属变化。
    if hit_res and any(word in raw for word in _DAMAGE):
        raise DemoError(
            f"这句话说的是「{raw.strip()}」：现有世界只表达东西在哪儿、在谁手上，"
            "不能表达「坏了/不能用了」。换一种写法（比如它被放到哪里、落到谁手上）才能作为本次条件。")

    # 1) 物品归属/位置：必须同时点到物品和落点，才能动世界状态
    if hit_res and (hit_locs or hit_chars):
        change: dict = {"id": hit_res[0]}
        if hit_locs:
            change["location_id"] = hit_locs[0]
        else:
            change["holder_id"] = hit_chars[0]
        return {"applicable": True, "kind": "resource", "scope": "all", "description": sentence,
                "resource_changes": [change],
                "reason": "这句话点名了一件已有的东西和它现在的去处",
                "source": "本地规则", "note": note or "本地规则：按物品归属变化接入"}

    # 2) 开局位置：点到人和地点，且句子里有位置味道的词
    if hit_chars and hit_locs and any(word in raw for word in _POSITION):
        return {"applicable": True, "kind": "position", "scope": "all", "description": sentence,
                "character_changes": [{"id": char_id, "location_id": hit_locs[0]}
                                      for char_id in hit_chars],
                "reason": "这句话改了某个人开局的位置",
                "source": "本地规则", "note": note or "本地规则：改开局位置"}

    # 3) 传言：只有指定的人听到，按「说法」处理
    if any(word in raw for word in _RUMOR):
        scope = f"actor:{hit_chars[0]}" if hit_chars else "all"
        return {"applicable": True, "kind": "rumor", "scope": scope, "description": sentence,
                "claim": sentence, "reason": "这句话是以「听说/带话」的形式出现的",
                "source": "本地规则",
                "note": note or ("本地规则：按一条说法接入"
                                 + ("（只到这里点名的那个人）" if hit_chars else "（全场都听到了这句话）"))}

    # 4) 亲见/公开的一件事
    if any(word in raw for word in _SEE):
        scope = f"location:{hit_locs[0]}" if hit_locs else "all"
        return {"applicable": True, "kind": "observed", "scope": scope, "description": sentence,
                "reason": "这句话写成了一件被看到/发现的事",
                "source": "本地规则", "note": note or "本地规则：按范围内亲眼所见接入"}

    # 5) 环境/现场变化
    if any(word in raw for word in _WEATHER):
        outdoors = list((scenario.get("demo") or {}).get("outdoor_locations") or [])
        if not outdoors:
            outdoors = [loc["id"] for loc in scenario.get("locations", [])]
        return {"applicable": True, "kind": "environment", "scope": "all", "description": sentence,
                "location_changes": {loc_id: {"state_description": sentence,
                                              "moment": "开演前的变化"}
                                     for loc_id in outdoors},
                "reason": "这句话说的是天气/现场条件变了",
                "source": "本地规则",
                "note": note or "本地规则：写进户外地点的现场描述（三人可见）"}

    # 认不出就拒绝：不再兜底成「全场发生的一件事」
    raise DemoError(
        "这句话没有落到这次支持的条件里（环境与现场 / 一句说法 / 全场亲见 / 开局位置 / 开局物品）。"
        "它没有被接成本次条件，也没有写进存档；可以换成一件看得见、听得见的现场变化，"
        "或者一件东西开局在别处，再试一次。")


IF_SYSTEM_TEMPLATE = """你要把用户写的一句 IF 设想，转成这次故事开始时的一个有效条件；
如果这句话不能作为本次条件，就明确拒绝。

只输出一个 json 对象，字段如下：

{
  "applicable": true 或 false,
  "reason": "一句话说明：为什么这样接，或为什么不接",
  "kind": "environment | rumor | observed | position | resource",
  "scope": "all | location:<地点id> | actor:<人物id>",
  "description": "以陈述句写下这个条件本身（不要写「如果」，也不要写任何人的反应或结局）",
  "claim": null 或 "只在 kind=rumor 时使用：这句传到某人耳朵里的原话",
  "location_changes": { "地点id": { "state_description": "现场描述", "moment": "这个时刻的简短说法" } },
  "character_changes": [ { "id": "人物id", "location_id": "地点id" } ],
  "resource_changes": [ { "id": "物品id", "location_id": "地点id" } 或 { "id": "物品id", "holder_id": "人物id" } ]
}

规则：
1. **applicable 必须是布尔值**（true/false），不能省略、不能用字符串或数字代替。
2. 能作为本次条件时：applicable=true，并按上面把 kind/scope/description 等字段填全。
3. 不能作为本次条件时：applicable=false，reason 里写清为什么不接；
   **不要为了凑一个结果去伪造 kind、scope 或任何状态补丁**，也不要改成别的一类条件。
   下面这些一律属于「不能接」：要改人物性格/立场/目标，要新增角色/地点/物品，
   要把东西写成「坏了/不能用了」，要改写已经发生的事，或者要求预定结局。
4. 只改条件，不改人物。**不要**改人物的性格、立场、目标，也不要写他会怎么做。
5. 只能使用下面列出的 id；新增人物、地点、物品一律不允许。
6. kind 的含义：environment = 天气或现场条件变了；rumor = 一句话传到某人耳朵里（不可靠的说法）；
   observed = 范围内的人亲眼看到/听到；position = 某人开局位置不同；resource = 某件东西开局在别处/别人手上。
7. scope 写生效范围：all = 所有人；location:<id> = 只有该地点的人；actor:<id> = 只有那个人。
   私下发生的事不要写成 all。
8. 这件东西只能表达「在哪、在谁手上」，不能表达「坏了/不能用了」。
9. 不写任何人的行动、计划或故事结局。

可用的人物：<<characters>>
可用的地点：<<locations>>
可用的物品：<<resources>>
允许的 kind："<<kinds>>"
"""


def build_if_request(text: str, scenario: dict, tick: int = 0) -> dict:
    """渲染 IF 理解的请求。

    用占位符替换而不是 str.format：模板里有 json 示例的花括号，
    str.format 会把它们当字段名（实测直接 KeyError，真实模式一次都发不出去）。
    """
    def listing(items) -> str:
        return "、".join(f"{item['name']}（{item['id']}）" for item in items) or "（无）"

    system = (IF_SYSTEM_TEMPLATE
              .replace("<<characters>>", listing(scenario.get("characters", [])))
              .replace("<<locations>>", listing(scenario.get("locations", [])))
              .replace("<<resources>>", listing(
                  [{"id": res["id"], "name": res.get("name", res["id"])}
                   for res in scenario.get("resources", [])]))
              .replace("<<kinds>>", " | ".join(IF_PATCH_KINDS)))
    return {"system": system, "user": f"用户的 IF 设想：{text}", "tick": tick}


def validate_if_patch(raw, scenario: dict, text: str) -> dict:
    """把模型（或本地规则）的输出校验成可执行的补丁；不合法就抛 DemoError。

    协议要求 `applicable` 是**布尔值**：缺失、null、字符串 "true"、数字 1 都不算成功。
    以前只看 `applicable is False` 就拒绝，缺字段会被当成功——那等于放一个没表态的结果进世界。
    """
    if not isinstance(raw, dict):
        raise DemoError(f"IF 解析结果必须是对象，收到 {type(raw).__name__}")
    applicable = raw.get("applicable")
    if not isinstance(applicable, bool):
        shown = "缺少该字段" if "applicable" not in raw else f"收到 {applicable!r}"
        raise DemoError(f"输出没有明确表态：applicable 必须是布尔值（{shown}）")
    if not applicable:
        raise DemoError(f"输出表示不能作为本次条件：{raw.get('reason') or '未说明原因'}")
    kind = str(raw.get("kind") or "").strip()
    if kind not in IF_PATCH_KINDS:
        raise DemoError(f"IF 类型不合法：{kind!r}（只支持 {'、'.join(IF_PATCH_KINDS)}）")
    description = str(raw.get("description") or "").strip() or _declarative(text)
    scope = str(raw.get("scope") or "all").strip()
    try:
        scenario_mod.check_scope(scenario, scope)      # 非法范围在这里就被拒
    except scenario_mod.ScenarioError as exc:
        # 统一成 DemoError：调用方（页面/命令行）只需要处理一种错误
        raise DemoError(str(exc)) from exc
    patch = {"kind": kind, "scope": scope, "description": description,
             "applicable": True,
             "reason": str(raw.get("reason") or "").strip(),
             "source": str(raw.get("source") or "模型理解"),
             "note": str(raw.get("note") or "").strip()}

    claim = raw.get("claim")
    if claim:
        if kind != "rumor":
            raise DemoError("只有「传言」类条件才可以带 claim（一句说法）")
        patch["claim"] = str(claim).strip()

    loc_ids = {loc["id"] for loc in scenario.get("locations", [])}
    char_ids = {ch["id"] for ch in scenario.get("characters", [])}
    res_ids = {res["id"] for res in scenario.get("resources", [])}

    changes = raw.get("location_changes") or {}
    if changes:
        if not isinstance(changes, dict):
            raise DemoError("location_changes 必须是对象")
        clean: dict = {}
        for loc_id, fields in changes.items():
            if loc_id not in loc_ids:
                raise DemoError(f"条件指向了不存在的地点：{loc_id}")
            if not isinstance(fields, dict):
                raise DemoError(f"地点 {loc_id} 的变化必须是对象")
            allowed = {k: v for k, v in fields.items()
                       if k in ("state_description", "moment") and str(v).strip()}
            unknown = [k for k in fields if k not in ("state_description", "moment")]
            if unknown:
                raise DemoError(f"地点变化不支持这些字段：{'、'.join(unknown)}"
                                "（只能改现场描述与时刻）")
            if allowed:
                clean[loc_id] = allowed
        if clean:
            patch["location_changes"] = clean

    char_changes = raw.get("character_changes") or []
    if char_changes:
        if not isinstance(char_changes, list):
            raise DemoError("character_changes 必须是数组")
        clean_chars = []
        for item in char_changes:
            if not isinstance(item, dict) or item.get("id") not in char_ids:
                raise DemoError(f"人物调整指向了不存在的人物：{item!r}")
            if item.get("location_id") not in loc_ids:
                raise DemoError(f"人物调整指向了不存在的地点：{item.get('location_id')!r}")
            if set(item) - {"id", "location_id", "status_text"}:
                raise DemoError("人物调整只支持改开局位置（与一句状态说明），"
                                "不支持改目标、倾向或立场")
            clean_chars.append({k: v for k, v in item.items() if v is not None})
        patch["character_changes"] = clean_chars

    res_changes = raw.get("resource_changes") or []
    if res_changes:
        if not isinstance(res_changes, list):
            raise DemoError("resource_changes 必须是数组")
        clean_res = []
        for item in res_changes:
            if not isinstance(item, dict) or item.get("id") not in res_ids:
                raise DemoError(f"物品调整指向了不存在的物品：{item!r}")
            has_loc = item.get("location_id") is not None
            has_holder = item.get("holder_id") is not None
            if has_loc == has_holder:
                raise DemoError("物品调整必须且只能给出 location_id 或 holder_id 之一")
            if has_loc and item["location_id"] not in loc_ids:
                raise DemoError(f"物品调整指向了不存在的地点：{item['location_id']}")
            if has_holder and item["holder_id"] not in char_ids:
                raise DemoError(f"物品调整指向了不存在的人物：{item['holder_id']}")
            clean_res.append({k: v for k, v in item.items() if v is not None})
        patch["resource_changes"] = clean_res

    has_state_change = any(patch.get(key) for key in
                           ("location_changes", "character_changes", "resource_changes"))
    if kind == "environment" and not patch.get("location_changes"):
        raise DemoError("环境类条件没有给出任何地点变化，无法作为起始条件")
    if kind == "rumor" and not patch.get("claim"):
        patch["claim"] = description
    if kind in ("position", "resource") and not (patch.get("character_changes")
                                                 or patch.get("resource_changes")):
        raise DemoError(f"{kind} 类条件没有给出任何开局调整，无法作为起始条件")
    if kind == "resource" and not has_state_change:
        raise DemoError("物品类条件没有给出任何调整，无法作为起始条件")
    return patch


def build_if_system(scenario: dict) -> str:      # 便于单独渲染/自检
    return build_if_request("", scenario)["system"]


def interpret_if(text: str, scenario: dict, provider, tick: int = 0, chapter_mode: bool = False) -> dict:
    """把一句 IF 变成可执行的起始条件补丁。

    真实模式**只认模型的结果**：模型拒绝、调用失败、或结果不符合结构时，说明原因并停止开演，
    不自动改走本地关键词规则——否则用户以为模型理解了，实际是按关键词接的。
    模拟模式没有模型可用，才走本地规则；本地规则认不出也一样拒绝（不兜底成别的类型）。
    无论哪条路，最后都由 validate_if_patch 做本地校验：范围、id、字段必须是包里真有的。
    """
    if getattr(provider, "mode", "fake") == "fake":
        return interpret_if_local(text, scenario, note="模拟模式不做模型理解，改用本地规则")

    prefix = "真实模式：模型这一步没有给出可用的理解"
    try:
        request = build_if_request(text, scenario, tick)
        request["chapter_mode"] = chapter_mode
        raw = provider.interpret(request)
    except (ProviderError, ProviderSchemaError, LeaseLost) as exc:
        raise DemoError(
            f"{prefix}（{type(exc).__name__}：{exc}）。本次没有开演：没有写入条件，"
            "也没有改用本地关键词规则。可以换一种说法再试，或稍后重试。") from exc
    except Exception as exc:          # 兜底：任何异常都停在开演前，不静默降级
        raise DemoError(
            f"{prefix}（{type(exc).__name__}：{exc}）。本次没有开演，也没有写入条件。") from exc

    if not isinstance(raw, dict):
        raise DemoError(f"{prefix}（输出不是对象，收到 {type(raw).__name__}）。"
                        "本次没有开演，也没有写入条件。")
    if raw.get("applicable") is False:
        raise DemoError(f"模型认为这句话不能作为本次条件：{raw.get('reason') or '未说明原因'}。"
                        "本次没有开演，也没有写入条件；可以换一种说法再试。")
    try:
        return validate_if_patch(raw, scenario, text)
    except DemoError as exc:
        raise DemoError(f"{prefix}（{exc}）。本次没有开演，也没有写入条件。") from exc


# ------------------------------------------------------------------ 应用与结束


def _read_state(conn) -> dict:
    row = conn.execute("SELECT tick, status, if_condition, if_patch, ended_at, ending_note"
                       " FROM run WHERE run_id=1").fetchone()
    if row is None:
        raise DemoError("数据库未初始化：缺少 run 记录")
    return dict(row)


def apply_if(db_path: str, scenario: dict, patch: dict, text: str) -> dict:
    """把 IF 一次性写成本次运行的起始条件。

    只允许在世界还没走过（tick=0）、本次条件还没写过、故事还没结束时调用：
    重复点击「开始」不会重复入队，也不会叠加第二份条件。
    """
    conn = db.connect(db_path)
    try:
        state = _read_state(conn)
        if state["status"] == "ended":
            raise DemoError("这次故事已经结束了，不能再改条件。")
        if state["tick"] != 0:
            raise DemoError(f"世界已经走到第 {state['tick']} 刻，起始条件只能在开演前写入；"
                            "要换条件请新开一个存档。")
        if (state["if_condition"] or "").strip():
            raise DemoError("这次运行已经有过起始条件；重复开始不会叠加第二个条件。")

        stamp = db.now()
        with db.write_txn(conn):
            for change in patch.get("character_changes") or []:
                conn.execute("UPDATE character SET location_id=?, status_text=COALESCE(?, status_text),"
                             " updated_tick=0 WHERE id=?",
                             (change["location_id"], change.get("status_text"), change["id"]))
            for change in patch.get("resource_changes") or []:
                conn.execute("UPDATE resource SET location_id=?, holder_id=?, updated_tick=0"
                             " WHERE id=?",
                             (change.get("location_id"), change.get("holder_id"), change["id"]))
            payload: dict = {}
            if patch.get("claim"):
                payload["claim"] = patch["claim"]
            if patch.get("location_changes"):
                payload["location_changes"] = patch["location_changes"]
            elif patch["kind"] == "observed":
                payload["direct_observation"] = True
            conn.execute(
                "INSERT INTO external_event(preset_key, scope, description, payload, status,"
                " created_tick, created_at) VALUES(?, ?, ?, ?, 'pending', 0, ?)",
                (IF_EVENT_KEY, patch["scope"], patch["description"],
                 json.dumps(payload, ensure_ascii=False), stamp))
            conn.execute("UPDATE run SET if_condition=?, if_patch=?, updated_at=?"
                         " WHERE run_id=1",
                         (text.strip(), json.dumps(patch, ensure_ascii=False), stamp))
        return {"applied": True, "scope": patch["scope"], "kind": patch["kind"],
                "description": patch["description"], "source": patch["source"],
                "note": patch.get("note", ""), "reason": patch.get("reason", ""),
                "character_changes": len(patch.get("character_changes") or []),
                "resource_changes": len(patch.get("resource_changes") or []),
                "location_changes": len(patch.get("location_changes") or {})}
    finally:
        conn.close()


def end_run(db_path: str, note: str | None = None) -> dict:
    """结束本次演示并保存：冻结故事，之后不再推进。

    和在途推进的关系：还有一步正在跑就先拒绝，让用户等它落地再结束——
    避免界面说「已结束」之后世界还在往前走。
    """
    conn = db.connect(db_path)
    try:
        state = _read_state(conn)
        if state["status"] == "ended":
            raise DemoError("这次故事已经结束了。")
        alive = [row["request_id"] for row in conn.execute(
            "SELECT request_id, heartbeat_ms FROM step_request WHERE status='in_progress'")
            if lease_alive(row["heartbeat_ms"], db.now_ms(), DEFAULT_LEASE_MS)]
        if alive:
            raise DemoError(f"还有一步正在跑（{alive[0]}），等它落地再结束；"
                            "已发出的请求可能仍会完成并保存。")
        stamp = db.now()
        text = (note or "读者手动结束本次演示。").strip()
        with db.write_txn(conn):
            conn.execute("UPDATE run SET status='ended', ended_at=?, ending_note=?, updated_at=?"
                         " WHERE run_id=1", (stamp, text, stamp))
            from . import chapter_store
            if chapter_store.live_requests(conn):
                raise DemoError("章节仍在生成，请等本章完成后再结束故事")
            chapter_store.invalidate(conn, "故事已结束")
        return {"ended": True, "ended_at": stamp, "note": text, "tick": state["tick"]}
    finally:
        conn.close()


def start_run(db_path: str, provider, text: str) -> dict:
    """开演：把一句 IF 解析并写成本次运行的起始条件（只此一次）。

    解析走 interpret_if（真实模式先问模型，模拟模式或模型不可用时用本地规则），
    落地全在 apply_if 的一个事务里；重复调用会被 apply_if 挡下。
    """
    from .intervention import scope_label
    conn = db.connect(db_path)
    try:
        scenario = scenario_mod.read_scenario(conn)
        state = _read_state(conn)
        from . import chapter_store
        chapter_mode = chapter_store.enabled(conn)
    finally:
        conn.close()
    patch = interpret_if(text, scenario, provider, state["tick"], chapter_mode)
    applied = apply_if(db_path, scenario, patch, text)
    return {**applied, "if_text": text.strip(),
            "scope_label": scope_label(scenario, patch["scope"]),
            "accounting": provider.take_stats()}


def demo_state(db_path: str) -> dict:
    """阅读页需要的运行状态：条件、结束信息、批次上限。"""
    conn = db.connect(db_path)
    try:
        state = _read_state(conn)
    finally:
        conn.close()
    patch = {}
    if state.get("if_patch"):
        try:
            patch = json.loads(state["if_patch"])
        except json.JSONDecodeError:
            patch = {}
    return {"if_condition": state.get("if_condition") or "",
            "if_kind": patch.get("kind", ""),
            "if_scope": patch.get("scope", ""),
            "if_source": patch.get("source", ""),
            "ended_at": state.get("ended_at") or "",
            "ending_note": state.get("ending_note") or ""}
