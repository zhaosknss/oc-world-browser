"""角色个人状态：本人写下的短期状态，以及它的校验、合并与落库。

为什么和 character 表分开：

- character 保存的是**开局设定**——原始人设描述与稳定目标，一次经历不该改写它；
- character_note 保存**会随经历变化的那一层**——此刻在意的事与短期打算、
  对当前处境的主观理解、试过的什么有用、还没做完的事。
  这一层由角色本人根据自己的信息写，写错了也留在自己这里，不当世界真相。

写入时机只有一个：该刻推进真正提交时（见 src/engine.py 的提交事务）。
技术失败（输出校验错、超时、租约失效等）整步回滚，因此不会留下半截个人状态。

读取只按 actor_id 取本人一行，别人看不到；它不参与叙述，也不进阅读页。
"""
from __future__ import annotations

FIELDS = ("focus", "situation", "lessons", "pending")

FIELD_LABELS = {
    "focus": "当前在意的事与短期打算",
    "situation": "对当前处境的理解",
    "lessons": "试过的结果（什么有用、什么没用）",
    "pending": "还没做完的事",
}

# 每项都是一句话，不保存长篇推理过程；超长直接截断，不因为一个字段过长整步回滚。
MAX_CHARS = 240

# 表示「这一项不变」的写法。角色没变化时不需要重写一次；把这些当成沿用原值，
# 而不是把「无」真的存成一项内容。
KEEP_VALUES = frozenset({"", "无", "沒有", "没有", "不变", "保持", "沿用", "同上", "同前",
                         "none", "null", "nil", "-", "--", "—", "－", "n/a"})

TABLE = "character_note"


def empty_state() -> dict:
    return {key: "" for key in FIELDS}


def is_keep(value: str) -> bool:
    """这个值是不是「不改动」。"""
    return str(value).strip().lower() in KEEP_VALUES


def normalize(raw) -> tuple[dict, list[str]]:
    """把模型给的 state 归一成「真正要改的字段」。

    返回 (要改的字段, 被忽略的字段名)。

    - 整项没写、写成 null、写成空串或「无」这类哨兵 → 沿用原值，不算改动；
    - 已知字段的值必须是字符串：布尔/数字/数组/对象是明确的协议错误，抛 ValueError
      （调用方翻成 ProviderSchemaError，本步回滚）；
    - 未知字段名忽略：多写一个字段不该让整步回滚，也不该被静默存进库里。
    """
    if raw is None:
        return {}, []
    if not isinstance(raw, dict):
        raise ValueError(f"必须是对象，收到 {type(raw).__name__}")
    update: dict[str, str | None] = {}
    ignored: list[str] = []
    for key, value in raw.items():
        if key == "clear":
            if not isinstance(value, list) or any(field not in FIELDS for field in value):
                raise ValueError("state.clear 必须是可清空字段的数组")
            continue
        if key not in FIELDS:
            ignored.append(str(key))
            continue
        if value is None:
            continue
        if isinstance(value, bool) or not isinstance(value, str):
            raise ValueError(f"{key} 必须是字符串（收到 {type(value).__name__}）")
        if is_keep(value):
            continue
        update[key] = value.strip()[:MAX_CHARS]
    for field in raw.get("clear", []):
        update[field] = None
    return update, sorted(ignored)


def merge(current: dict | None, update: dict, tick: int) -> tuple[dict, bool]:
    """把一次更新并进现有个人状态，返回 (合并后的状态, 是否真的有变化)。

    「没变化就沿用」在这里落实：新值与旧值相同、或这次没有任何要改的字段时，
    返回 changed=False，调用方不写库，updated_tick 也保持原来那一刻。
    """
    base = {key: str((current or {}).get(key) or "") for key in FIELDS}
    changed = False
    for key, value in (update or {}).items():
        if key not in FIELDS or (not value and value is not None):
            continue
        if value is None:
            value = ""
        if base[key] != value:
            base[key] = value
            changed = True
    base["updated_tick"] = (int(tick) if changed
                            else int((current or {}).get("updated_tick") or 0))
    return base, changed


def state_view(state: dict | None) -> dict:
    """给角色决策输入用的状态视图：四个字段 + 写入时刻。"""
    view = {key: str((state or {}).get(key) or "") for key in FIELDS}
    view["updated_tick"] = int((state or {}).get("updated_tick") or 0)
    return view


# --------------------------------------------------------------------- 存取


def has_table(conn) -> bool:
    """旧存档可能还没有这张表：没有就当成「这个人还没写下任何东西」。"""
    row = conn.execute("SELECT name FROM sqlite_master WHERE type='table' AND name=?",
                       (TABLE,)).fetchone()
    return row is not None


def ensure_table(conn) -> None:
    """幂等建表：旧存档在补上这张表之前也能正常写入个人状态。

    正常启动路径上 `db.init_schema` 已经执行过 schema.sql（含这张表）；这里只是兜底，
    保证「拿旧库直接跑一轮」不会因为缺表把整步推进打回。
    """
    if has_table(conn):
        return
    conn.execute(
        f"CREATE TABLE IF NOT EXISTS {TABLE} ("
        " actor_id TEXT PRIMARY KEY,"
        " focus TEXT NOT NULL DEFAULT '',"
        " situation TEXT NOT NULL DEFAULT '',"
        " lessons TEXT NOT NULL DEFAULT '',"
        " pending TEXT NOT NULL DEFAULT '',"
        " updated_tick INTEGER NOT NULL DEFAULT 0,"
        " updated_at TEXT NOT NULL)")


def load_all(conn) -> dict[str, dict]:
    """读出全部角色的个人状态；表不存在时返回空表（不报错）。"""
    if not has_table(conn):
        return {}
    out: dict[str, dict] = {}
    for row in conn.execute(
            f"SELECT actor_id, focus, situation, lessons, pending, updated_tick FROM {TABLE}"):
        state = {key: row[key] or "" for key in FIELDS}
        state["updated_tick"] = int(row["updated_tick"] or 0)
        out[row["actor_id"]] = state
    return out


def save(conn, actor_id: str, state: dict, stamp: str) -> None:
    """写入本人一行；只在本刻推进的提交事务里调用。"""
    conn.execute(
        f"INSERT OR REPLACE INTO {TABLE}(actor_id, focus, situation, lessons, pending,"
        " updated_tick, updated_at) VALUES(?,?,?,?,?,?,?)",
        (actor_id, state.get("focus", ""), state.get("situation", ""),
         state.get("lessons", ""), state.get("pending", ""),
         int(state.get("updated_tick") or 0), stamp))
