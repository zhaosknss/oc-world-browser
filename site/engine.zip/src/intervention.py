"""读者输入的自由文本 → 世界里真正发生的一件外部事件。

这一层只做两件事：**理解**（把一句话落成范围 + 一句客观描述，必要时带上「有人这么说」的说法）
与**入队**（写进 external_event，下一步开始时按已有路径生效）。

为什么不能只在页面加个输入框：引擎只认 external_event 表里的行，范围、感知者、
后续角色反应全部由那条路径决定。所以这里宁可多一步解释与校验，也不让输入停留在聊天框里。

理解有两条路：
- 真实模式：交给模型，按固定 json 协议返回，再由这里校验（未知地点/人物一律拒绝）；
- 模拟模式或模型明确表示「落不进来」：用场景里的预设关键词做本地匹配，匹配不上就按
  「全场发生的一件事」接入。两条路的结果都会如实告诉用户是怎么来的。
"""
from __future__ import annotations

import json
import re

from . import db, scenario as scenario_mod
from .models import ProviderSchemaError, stage_label

MAX_DESCRIPTION = 120
MAX_CLAIM = 160

# 明显超出本轮范围的要求：与其糊一句含糊的事件，不如直接说清为什么不接。
OUT_OF_SCOPE_HINTS = (
    ("新增角色", "本轮不支持在运行中新增角色。可以换成场景里已有的人物，或把这件事写在他身上。"),
    ("新角色", "本轮不支持在运行中新增角色。可以换成场景里已有的人物，或把这件事写在他身上。"),
    ("加一个人", "本轮不支持在运行中新增角色。可以换成场景里已有的人物，或把这件事写在他身上。"),
    ("重来", "本轮不支持改写已经发生的事或重设故事起点。可以投入一件接下来要发生的事。"),
    ("重新开始", "本轮不支持改写已经发生的事或重设故事起点。可以投入一件接下来要发生的事。"),
    ("改写结局", "本轮不支持改写已经发生的事或重设故事起点。可以投入一件接下来要发生的事。"),
    ("换一个世界", "本轮不支持换世界。可以投入一件在这个场景里能发生的事。"),
)

INTERPRET_SYSTEM = """你在把读者的输入，理解成这个世界里即将发生的一件外部事件。

只使用给定的场景设定、地点、人物与预设事件；不要新增地点或人物，不要改写已经发生的事，
不要替人物做决定，不要写出故事的结局。只描述「发生了什么事、谁在场看到或听到了什么」。

只输出一个 json 对象，不要输出解释或 markdown 代码块。格式：
{"applicable": true 或 false, "scope": "范围", "description": "一句话的事件描述",
 "claim": null 或 "一种说法", "reason": "为什么这样理解"}

- scope 只能是三种之一："all"（全场）、"location:<地点 id>"（只在某个地点）、
  "actor:<人物 id>"（只发生在某个人身上，比如他收到一张纸条）；
- description 是一句客观的世界事件描述，不超过 60 个汉字，写「发生了什么」；
- 如果这件事更适合让某人「听到一种说法」，把说法写进 claim（不超过 80 个汉字），
  否则 claim 写 null。claim 里的内容会被当作未经证实的说法，不会被当成世界事实；
- 如果输入落不进这个场景（要求新增人物、改写已经发生的事、与场景无关、无法判断），
  把 applicable 写成 false，并在 reason 里说清原因。

只输出这一个 json 对象。"""


class InterventionError(Exception):
    """读者的输入无法落成一件世界事件。这不是基础设施失败，要如实告诉用户。"""


def preset_keywords(preset: dict) -> list[str]:
    """预设事件的匹配词：场景里显式写的 keywords，加上标签的主体词。

    场景 JSON 是这份词表的唯一维护位置（见 scenarios/*.json 的 presets[].keywords）。
    括号里的补充说明（「停电（全场）」里的「全场」）不当关键词用：太泛，容易误匹配。
    """
    words = [str(word).strip() for word in preset.get("keywords", []) if str(word).strip()]
    label = str(preset.get("label") or "").strip()
    if label:
        core = re.split(r"[（(]", label)[0].strip()
        if core:
            words.append(core)
    return sorted(set(words), key=len, reverse=True)


def _out_of_scope_reason(text: str) -> str | None:
    for token, message in OUT_OF_SCOPE_HINTS:
        if token in text:
            return message
    return None


def local_match(text: str, scenario: dict) -> dict | None:
    """在预设事件里找最贴近的一个（取命中的最长关键词，最长者最具体）。"""
    best = None
    for preset in scenario.get("presets", []):
        for word in preset_keywords(preset):
            if word and word in text:
                if best is None or len(word) > best[1]:
                    best = (preset, len(word))
                break
    return best[0] if best else None


def interpret_locally(text: str, scenario: dict, note: str | None = None) -> dict:
    preset = local_match(text, scenario)
    if preset is not None:
        payload = preset.get("payload") or {}
        return {
            "source": "预设匹配",
            "matched_preset": preset["key"],
            "scope": preset["scope"],
            "description": preset.get("description") or text,
            "claim": payload.get("claim"),
            "payload": dict(payload),
            "note": (f"匹配到场景预设事件「{preset.get('label', preset['key'])}」，"
                     f"按它的范围与效果接入。" + (f"（{note}）" if note else "")),
        }
    return {
        "source": "本地默认",
        "matched_preset": None,
        "scope": "all",
        "description": text,
        "claim": None,
        "payload": {},
        "note": ("没有匹配到场景预设，按「全场发生的一件事」接入："
                 "所有角色都会把它当成亲眼所见。" + (f"（{note}）" if note else "")),
    }


def build_interpret_request(text: str, scenario: dict, tick: int) -> dict:
    presets = [{"key": preset.get("key"), "label": preset.get("label"),
                "scope": preset.get("scope"), "description": preset.get("description"),
                "keywords": preset_keywords(preset)}
               for preset in scenario.get("presets", [])]
    payload = {
        "tick": tick,
        "reader_input": text,
        "world": {"title": scenario.get("title", ""),
                  "description": (scenario.get("world") or {}).get("description", "")},
        "locations": [{"id": loc["id"], "name": loc["name"], "description": loc["description"]}
                      for loc in scenario.get("locations", [])],
        "characters": [{"id": ch["id"], "name": ch["name"], "description": ch["description"],
                        "location_id": ch["location_id"]}
                       for ch in scenario.get("characters", [])],
        "presets": presets,
        "rule": ("范围只能用 all、location:<地点 id>、actor:<人物 id>；"
                 "不要新增地点或人物，不要改写已经发生的事。"),
    }
    return {"system": INTERPRET_SYSTEM, "user": json.dumps(payload, ensure_ascii=False),
            "text": text, "tick": tick, "payload": payload}


def _clean_text(value, limit: int, field: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ProviderSchemaError(f"事件理解的 {field} 必须是非空字符串")
    text = " ".join(value.split())
    if len(text) > limit:
        raise ProviderSchemaError(f"事件理解的 {field} 太长（上限 {limit} 字）：{text[:40]}…")
    return text


def validate_interpretation(raw, scenario: dict, text: str) -> dict:
    """校验模型给出的事件理解；未知地点/人物、越界要求都当成「无法应用」。"""
    if not isinstance(raw, dict):
        raise ProviderSchemaError(f"事件理解必须是对象，收到 {type(raw).__name__}")
    applicable = raw.get("applicable")
    if applicable is False:
        reason = raw.get("reason")
        raise InterventionError(
            "这件事没有落进当前场景，未生效。" + (f"原因：{reason}" if isinstance(reason, str)
                                            and reason.strip() else ""))
    if applicable is not True:
        raise ProviderSchemaError("事件理解的 applicable 必须是 true 或 false")

    scope = raw.get("scope")
    try:
        scope = scenario_mod.check_scope(scenario, scope)
    except scenario_mod.ScenarioError as exc:
        raise InterventionError(f"这件事没有落进当前场景，未生效。{exc}") from exc

    description = _clean_text(raw.get("description"), MAX_DESCRIPTION, "description")
    claim = raw.get("claim")
    if claim is not None:
        claim = _clean_text(claim, MAX_CLAIM, "claim")
    reason = raw.get("reason")
    return {
        "source": "模型理解",
        "matched_preset": None,
        "scope": scope,
        "description": description,
        "claim": claim,
        "payload": {"claim": claim} if claim else {},
        "note": (f"由模型按当前场景理解（原始输入：{text[:40]}）。"
                 + (f"理由：{reason}" if isinstance(reason, str) and reason.strip() else "")),
    }


def interpret(text: str, scenario: dict, provider, tick: int, chapter_mode: bool = False) -> dict:
    """理解一条读者输入；不合法就抛 InterventionError（人话说明），不静默丢弃。"""
    text = (text or "").strip()
    if not text:
        raise InterventionError("请先写一件希望发生的事。")
    if len(text) > 200:
        raise InterventionError(f"输入太长了（上限 200 字，现在 {len(text)} 字），请写短一点。")
    blocked = _out_of_scope_reason(text)
    if blocked:
        raise InterventionError(blocked)

    if getattr(provider, "mode", "fake") == "fake":
        return interpret_locally(text, scenario, note="模拟模式不做模型理解")
    request = build_interpret_request(text, scenario, tick)
    request["chapter_mode"] = chapter_mode
    raw = provider.interpret(request)
    if isinstance(raw, dict) and raw.get("applicable") is None:
        # provider 明确表示「这一层没有意见」（模拟提供方），退到本地规则
        return interpret_locally(text, scenario, note=str(raw.get("reason") or ""))
    return validate_interpretation(raw, scenario, text)


def scope_label(scenario: dict, scope: str) -> str:
    if scope == "all":
        return "全场"
    kind, _, target = scope.partition(":")
    if kind == "location":
        for loc in scenario.get("locations", []):
            if loc["id"] == target:
                return f"只在{loc['name']}"
    if kind == "actor":
        for ch in scenario.get("characters", []):
            if ch["id"] == target:
                return f"只发生在{ch['name']}身上"
    return scope


def queue_intervention(db_path: str, provider, text: str) -> dict:
    """总入口：理解 → 入队 → 返回一段可以直接显示给用户的说明。"""
    conn = db.connect(db_path)
    try:
        scenario = scenario_mod.read_scenario(conn)
        tick = conn.execute("SELECT tick FROM run WHERE run_id=1").fetchone()["tick"]
        from . import chapter_store
        chapter_mode = chapter_store.enabled(conn)
    finally:
        conn.close()

    interpretation = interpret(text, scenario, provider, tick, chapter_mode)
    try:
        event_id = scenario_mod.queue_custom_external(
            db_path, interpretation["scope"], interpretation["description"],
            interpretation["payload"],
            preset_key=interpretation.get("matched_preset") or "intervention",
            scenario=scenario)
    except scenario_mod.ScenarioError as exc:
        raise InterventionError(f"这件事没有落进当前场景，未生效。{exc}") from exc

    return {
        "queued": True,
        "event_id": event_id,
        "scope": interpretation["scope"],
        "scope_label": scope_label(scenario, interpretation["scope"]),
        "description": interpretation["description"],
        "claim": interpretation.get("claim"),
        "preset_key": interpretation.get("matched_preset") or "intervention",
        "source": interpretation["source"],
        "note": interpretation.get("note", ""),
        "stage": stage_label("interpret"),
    }


def hints(scenario: dict) -> list[str]:
    """给阅读页的示例（来自场景本身，页面不硬编码任何故事内容）。"""
    out = []
    for preset in scenario.get("presets", []):
        label = preset.get("label") or preset.get("key")
        description = preset.get("description") or ""
        out.append(f"{label} — 例如：{description}")
    return out


__all__ = ["InterventionError", "interpret", "interpret_locally", "local_match",
           "validate_interpretation", "build_interpret_request", "queue_intervention",
           "scope_label", "preset_keywords", "hints", "MAX_DESCRIPTION", "MAX_CLAIM",
           "INTERPRET_SYSTEM"]
