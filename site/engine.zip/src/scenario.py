"""场景输入：JSON 是场景输入，数据库是运行状态的正式保存位置。

初始化时把场景整体快照进 meta.scenario_json，重启后不再依赖外部文件内容，
但会校验 scenario_version 是否一致。
"""
from __future__ import annotations

import copy
import json
import os

from . import db

REQUIRED_TOP = ("scenario_id", "version", "world", "locations", "characters")
DEFAULT_CHARACTER_SELECTION = object()
_ACTOR_REFERENCE_FIELDS = frozenset(("actor_id", "character_id", "holder_id", "source_actor_id",
                                    "claim_source_actor", "target_actor_id", "target_character_id",
                                    "source_character_id", "partner_id"))
_ACTOR_REFERENCE_LISTS = frozenset(("actor_ids", "character_ids", "actors"))


class ScenarioError(Exception):
    pass


def load_scenario(path: str) -> dict:
    with open(path, "r", encoding="utf-8") as fh:
        data = json.load(fh)
    return validate_scenario(data)


def validate_scenario(data: dict) -> dict:
    if not isinstance(data, dict):
        raise ScenarioError("场景必须是 JSON 对象")
    for key in REQUIRED_TOP:
        if key not in data:
            raise ScenarioError(f"场景缺少字段：{key}")
    if not isinstance(data["locations"], list) or not data["locations"]:
        raise ScenarioError("场景至少需要一个地点")
    if not isinstance(data["characters"], list):
        raise ScenarioError("characters 必须是数组")
    if len(data["characters"]) < 1:
        raise ScenarioError("场景至少需要一个角色")
    loc_ids = {loc["id"] for loc in data["locations"]}
    for loc in data["locations"]:
        for conn_id in loc.get("connections", []):
            if conn_id not in loc_ids:
                raise ScenarioError(f"地点 {loc['id']} 连接了不存在的地点 {conn_id}")
    char_ids = {ch["id"] for ch in data["characters"]}
    for ch in data["characters"]:
        if ch["location_id"] not in loc_ids:
            raise ScenarioError(f"角色 {ch['id']} 位于不存在的地点 {ch['location_id']}")
        _check_character_profile(ch, char_ids)
    _check_world_options(data, char_ids)
    presets = data.get("presets", [])
    if not isinstance(presets, list):
        raise ScenarioError("presets 必须是数组")
    preset_keys = set()
    for preset in presets:
        if not isinstance(preset, dict) or "key" not in preset or "scope" not in preset:
            raise ScenarioError("preset 需要 key 与 scope")
        if not isinstance(preset["key"], str) or not preset["key"]:
            raise ScenarioError("preset.key 必须是非空文字")
        if preset["key"] in preset_keys:
            raise ScenarioError(f"preset key 重复：{preset['key']}")
        preset_keys.add(preset["key"])
        check_scope(data, preset["scope"])
        _check_explicit_actor_references(preset, char_ids, f"preset {preset['key']}")
    initial_events = data.get("initial_external_events", [])
    if not isinstance(initial_events, list):
        raise ScenarioError("initial_external_events 必须是数组")
    for event in initial_events:
        if not isinstance(event, dict) or event.get("preset_key") not in preset_keys:
            raise ScenarioError("初始事件需要引用已有 preset_key")
    for convention in data.get("conventions", []):
        if isinstance(convention, dict) and "characters" in convention:
            _check_character_ids(convention["characters"], char_ids, "conventions.characters", allow_empty=True)
    _check_resources(data.get("resources", []), loc_ids, char_ids)
    return data


def _check_character_ids(value, char_ids: set[str], field: str, *, allow_empty=False) -> None:
    if (not isinstance(value, list) or (not value and not allow_empty)
            or any(not isinstance(item, str) for item in value)):
        raise ScenarioError(f"{field} 必须是{'文字数组' if allow_empty else '非空文字数组'}")
    if len(value) != len(set(value)):
        raise ScenarioError(f"{field} 不能包含重复人物")
    unknown = set(value) - char_ids
    if unknown:
        raise ScenarioError(f"{field} 引用了不存在的人物：{'、'.join(sorted(unknown))}")


def _check_character_profile(ch: dict, char_ids: set[str]) -> None:
    label = f"人物 {ch['id']}"
    for field in ("voice", "entrance_cues"):
        if field in ch and not isinstance(ch[field], str):
            raise ScenarioError(f"{label} 的 {field} 必须是文字")
    for field, required in (("dialogue_examples", ("situation", "text")),
                            ("relationships", ("target_id", "description"))):
        if field not in ch:
            continue
        if not isinstance(ch[field], list):
            raise ScenarioError(f"{label} 的 {field} 必须是数组")
        for item in ch[field]:
            if not isinstance(item, dict) or any(not isinstance(item.get(key), str) for key in required):
                raise ScenarioError(f"{label} 的 {field} 条目需要 {'、'.join(required)} 文字")
            reference = "partner_id" if field == "dialogue_examples" else "target_id"
            if reference in item and (not isinstance(item[reference], str) or item[reference] not in char_ids):
                raise ScenarioError(f"{label} 的 {field}.{reference} 必须引用已有角色")
            if "reader_safe" in item and not isinstance(item["reader_safe"], bool):
                raise ScenarioError(f"{label} 的 {field}.reader_safe 必须是布尔值")


def _check_world_options(data: dict, char_ids: set[str]) -> None:
    world = data["world"]
    if not isinstance(world, dict):
        raise ScenarioError("world 必须是对象")
    if "casting" in world:
        casting = world["casting"]
        if not isinstance(casting, dict):
            raise ScenarioError("world.casting 必须是对象")
        if "default_character_ids" in casting:
            _check_character_ids(casting["default_character_ids"], char_ids, "world.casting.default_character_ids")
        if "guidance" in casting and not isinstance(casting["guidance"], str):
            raise ScenarioError("world.casting.guidance 必须是文字")
    if "narration" in data:
        narration = data["narration"]
        if not isinstance(narration, dict):
            raise ScenarioError("narration 必须是对象")
        for field in ("pov", "person", "tense", "tone"):
            if field in narration and not isinstance(narration[field], str):
                raise ScenarioError(f"narration.{field} 必须是文字")
        if "extra_rules" in narration and (not isinstance(narration["extra_rules"], list)
                or any(not isinstance(rule, str) for rule in narration["extra_rules"])):
            raise ScenarioError("narration.extra_rules 必须是文字数组")


def _check_explicit_actor_references(value, char_ids: set[str], label: str) -> None:
    """Check declared actor references, without treating prose or generic target ids as actors."""
    if isinstance(value, dict):
        for key, content in value.items():
            if key in _ACTOR_REFERENCE_FIELDS and content is not None:
                if not isinstance(content, str) or content not in char_ids:
                    raise ScenarioError(f"{label}.{key} 必须引用已有角色")
            elif key in _ACTOR_REFERENCE_LISTS:
                _check_character_ids(content, char_ids, f"{label}.{key}", allow_empty=True)
            _check_explicit_actor_references(content, char_ids, label)
    elif isinstance(value, list):
        for content in value:
            _check_explicit_actor_references(content, char_ids, label)


def _references_unselected_actor(value, selected: set[str]) -> bool:
    if isinstance(value, dict):
        for key, content in value.items():
            if key in _ACTOR_REFERENCE_FIELDS and content is not None and content not in selected:
                return True
            if key in _ACTOR_REFERENCE_LISTS and set(content) - selected:
                return True
            if _references_unselected_actor(content, selected):
                return True
    elif isinstance(value, list):
        return any(_references_unselected_actor(content, selected) for content in value)
    return False


def select_story_characters(data: dict, character_ids=DEFAULT_CHARACTER_SELECTION) -> dict:
    """Create a run snapshot; the reusable world and existing archives stay intact."""
    validate_scenario(data)
    all_ids = [ch["id"] for ch in data["characters"]]
    if character_ids is DEFAULT_CHARACTER_SELECTION:
        character_ids = data["world"].get("casting", {}).get("default_character_ids", all_ids)
    _check_character_ids(character_ids, set(all_ids), "character_ids")
    selected = set(character_ids)
    snapshot = copy.deepcopy(data)
    snapshot["characters"] = [ch for ch in snapshot["characters"] if ch["id"] in selected]
    for ch in snapshot["characters"]:
        if "relationships" in ch:
            ch["relationships"] = [item for item in ch["relationships"] if item["target_id"] in selected]
        if "dialogue_examples" in ch:
            ch["dialogue_examples"] = [item for item in ch["dialogue_examples"]
                                      if "partner_id" not in item or item["partner_id"] in selected]
    if "resources" in snapshot:
        snapshot["resources"] = [item for item in snapshot["resources"]
                                 if item.get("holder_id") is None or item["holder_id"] in selected]
    if "presets" in snapshot:
        snapshot["presets"] = [item for item in snapshot["presets"]
                               if (not item["scope"].startswith("actor:")
                                   or item["scope"].partition(":")[2] in selected)
                               and not _references_unselected_actor(item, selected)]
    retained_presets = {item["key"] for item in snapshot.get("presets", [])}
    if "initial_external_events" in snapshot:
        snapshot["initial_external_events"] = [item for item in snapshot["initial_external_events"]
                                              if item["preset_key"] in retained_presets]
    if "conventions" in snapshot:
        conventions = []
        for item in snapshot["conventions"]:
            if isinstance(item, dict) and "characters" in item:
                item["characters"] = [cid for cid in item["characters"] if cid in selected]
                if not item["characters"]:
                    continue
            conventions.append(item)
        snapshot["conventions"] = conventions
    if "casting" in snapshot["world"]:
        snapshot["world"]["casting"]["default_character_ids"] = [ch["id"] for ch in snapshot["characters"]]
    return validate_scenario(snapshot)


def _check_resources(resources: list, loc_ids: set[str], char_ids: set[str]) -> None:
    """资源初始状态必须是明确的：要么在某个地点，要么在某个角色手上，二者不可同时成立。

    这与引擎的取得/放下语义一致（见 src/settlement.py），保证初始快照本身不自相矛盾。
    """
    if not isinstance(resources, list):
        raise ScenarioError("resources 必须是数组")
    seen: set[str] = set()
    for res in resources:
        if not isinstance(res, dict) or not res.get("id"):
            raise ScenarioError("resource 需要 id")
        if res["id"] in seen:
            raise ScenarioError(f"resource id 重复：{res['id']}")
        seen.add(res["id"])
        place = res.get("location_id")
        holder = res.get("holder_id")
        if place is not None and holder is not None:
            raise ScenarioError(f"资源 {res['id']} 不能同时声明所在地点与持有者")
        if place is None and holder is None:
            raise ScenarioError(f"资源 {res['id']} 必须声明所在地点或持有者之一")
        if place is not None and place not in loc_ids:
            raise ScenarioError(f"资源 {res['id']} 位于不存在的地点 {place}")
        if holder is not None and holder not in char_ids:
            raise ScenarioError(f"资源 {res['id']} 的持有者不是已知角色 {holder}")


def bootstrap(db_path: str, scenario: dict) -> None:
    """首次初始化：建表并写入场景初始状态。已初始化的库不会被覆盖。"""
    conn = db.connect(db_path)
    try:
        db.init_schema(conn)
        row = conn.execute("SELECT value FROM meta WHERE key='scenario_json'").fetchone()
        if row is not None:
            existing = json.loads(row["value"])
            if existing.get("version") != scenario["version"]:
                raise ScenarioError(
                    "库中场景版本 %s 与输入 %s 不一致；如需换场景请用 --reset"
                    % (existing.get("version"), scenario["version"]))
            return

        stamp = db.now()
        with db.write_txn(conn):
            conn.execute("INSERT INTO meta(key, value) VALUES(?, ?)",
                         ("scenario_json", json.dumps(scenario, ensure_ascii=False)))
            conn.execute("INSERT INTO meta(key, value) VALUES(?, ?)", ("schema_version", "1"))
            conn.execute(
                "INSERT INTO run(run_id, scenario_id, scenario_version, tick, status,"
                " world_revision, actor_cursor, provider_mode, created_at, updated_at)"
                " VALUES(1, ?, ?, 0, 'paused', 0, 0, ?, ?, ?)",
                (scenario["scenario_id"], scenario["version"], scenario.get("provider_mode", "fake"),
                 stamp, stamp))
            for loc in scenario["locations"]:
                conn.execute(
                    "INSERT INTO location(id, name, description, connections, moment,"
                    " state_description) VALUES(?, ?, ?, ?, ?, ?)",
                    (loc["id"], loc["name"], loc["description"],
                     json.dumps(loc.get("connections", [])), loc.get("moment", "第 0 刻"),
                     loc.get("state_description", "")))
            for ch in scenario["characters"]:
                conn.execute(
                    "INSERT INTO character(id, name, description, goals, current_tendency,"
                    " change_reason, location_id, status_text, updated_tick)"
                    " VALUES(?, ?, ?, ?, ?, ?, ?, ?, 0)",
                    (ch["id"], ch["name"], ch["description"],
                     json.dumps(ch.get("goals", []), ensure_ascii=False),
                     ch.get("current_tendency", ""), ch.get("change_reason", ""),
                     ch["location_id"], ch.get("status_text", "正常")))
            for res in scenario.get("resources", []):
                conn.execute(
                    "INSERT INTO resource(id, name, description, location_id, holder_id,"
                    " unique_item, updated_tick) VALUES(?, ?, ?, ?, ?, ?, 0)",
                    (res["id"], res.get("name", res["id"]), res.get("description", ""),
                     res.get("location_id"), res.get("holder_id"),
                     1 if res.get("unique_item", True) else 0))
            for ev in scenario.get("initial_external_events", []):
                _insert_external(conn, scenario, ev["preset_key"], 0, stamp)
    finally:
        conn.close()


def _insert_external(conn, scenario: dict, preset_key: str, tick: int, stamp: str) -> int:
    preset = find_preset(scenario, preset_key)
    cur = conn.execute(
        "INSERT INTO external_event(preset_key, scope, description, payload, status,"
        " created_tick, created_at) VALUES(?, ?, ?, ?, 'pending', ?, ?)",
        (preset_key, preset["scope"], preset.get("description", ""),
         json.dumps(preset.get("payload", {}), ensure_ascii=False), tick, stamp))
    return int(cur.lastrowid)


def find_preset(scenario: dict, preset_key: str) -> dict:
    for preset in scenario.get("presets", []):
        if preset["key"] == preset_key:
            return preset
    raise ScenarioError(f"未知预设事件：{preset_key}")


def queue_external(db_path: str, preset_key: str) -> int:
    conn = db.connect(db_path)
    try:
        scenario = read_scenario(conn)
        tick = conn.execute("SELECT tick FROM run WHERE run_id=1").fetchone()["tick"]
        with db.write_txn(conn):
            from . import chapter_store
            if chapter_store.live_requests(conn):
                raise ScenarioError("章节正在生成，请等到阅读停顿处再投入事件")
            event_id = _insert_external(conn, scenario, preset_key, tick, db.now())
            chapter_store.invalidate(conn, "读者投入新事件，重排未读后续")
        return event_id
    finally:
        conn.close()


def known_scopes(scenario: dict) -> dict[str, list[str]]:
    """合法的外部事件范围：全场 / 某个地点 / 某个角色。"""
    return {"all": [],
            "location": [loc["id"] for loc in scenario.get("locations", [])],
            "actor": [ch["id"] for ch in scenario.get("characters", [])]}


def check_scope(scenario: dict, scope: str) -> str:
    """校验范围写法；不合法就抛 ScenarioError（调用方负责翻成人话）。"""
    if scope == "all":
        return scope
    if not isinstance(scope, str) or ":" not in scope:
        raise ScenarioError(f"范围写法不合法：{scope!r}（只允许 all、location:<地点>、actor:<人物>）")
    kind, _, target = scope.partition(":")
    allowed = known_scopes(scenario)
    if kind not in ("location", "actor"):
        raise ScenarioError(f"范围写法不合法：{scope!r}（只允许 all、location:<地点>、actor:<人物>）")
    if target not in allowed[kind]:
        raise ScenarioError(f"范围 {scope!r} 指向了场景里没有的{'地点' if kind == 'location' else '人物'}：{target}")
    return scope


def queue_custom_external(db_path: str, scope: str, description: str,
                          payload: dict | None = None, preset_key: str = "intervention",
                          scenario: dict | None = None) -> int:
    """把一件自定义外部事件排进待处理队列：读者自由输入的入口。

    只走一张表、一个事务；生效时机与预设事件完全一致（下一步开始时应用），
    因此角色感知与后续反应走的是同一条已经验证过的路径，不在页面里另起一套。
    """
    text = (description or "").strip()
    if not text:
        raise ScenarioError("外部事件的描述不能为空")
    conn = db.connect(db_path)
    try:
        scenario = scenario if scenario is not None else read_scenario(conn)
        check_scope(scenario, scope)
        tick = conn.execute("SELECT tick FROM run WHERE run_id=1").fetchone()["tick"]
        with db.write_txn(conn):
            cur = conn.execute(
                "INSERT INTO external_event(preset_key, scope, description, payload, status,"
                " created_tick, created_at) VALUES(?, ?, ?, ?, 'pending', ?, ?)",
                (preset_key, scope, text,
                 json.dumps(payload or {}, ensure_ascii=False), tick, db.now()))
            from . import chapter_store
            if chapter_store.live_requests(conn):
                raise ScenarioError("章节正在生成，请等到阅读停顿处再投入事件")
            chapter_store.invalidate(conn, "读者投入新事件，重排未读后续")
        return int(cur.lastrowid)
    finally:
        conn.close()


def read_scenario(conn) -> dict:
    row = conn.execute("SELECT value FROM meta WHERE key='scenario_json'").fetchone()
    if row is None:
        raise ScenarioError("数据库尚未初始化")
    return json.loads(row["value"])


def default_db_path(root: str) -> str:
    return os.path.join(root, "local-data", "oc-world.db")
