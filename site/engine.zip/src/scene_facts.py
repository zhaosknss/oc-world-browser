"""Minimal, POV-scoped physical facts for scene writing consistency.

Use a staging snapshot captured at the scene's start, not a later world state.
This follows the actor context's resource boundary: objects placed at the POV's
location and the POV's own carried objects. Other people's carried objects are
excluded even when their holders are present. The snapshot constrains prose; it
does not mean the POV noticed every object or that all objects must be revealed.
"""
from __future__ import annotations

from copy import deepcopy


_RESOURCE_FIELDS = ("id", "name", "location_id", "holder_id", "unique_item")


def visible_scene_facts(state: dict, pov_id: str) -> dict:
    """Return public physical structure without descriptions or private records.

    ``state`` is the shape returned by ``Runner.load_staging``. An absent POV or
    location yields an empty scope rather than exposing unlocated resources.
    The result shares no mutable values with the caller's staging snapshot.
    """
    characters = state.get("characters") or {}
    pov = characters.get(pov_id) or {}
    location_id = pov.get("location_id")
    if not isinstance(location_id, str) or not location_id:
        return {"location_id": None, "characters": [], "resources": []}

    present = [{"id": character["id"], "location_id": character["location_id"]}
               for character in characters.values()
               if character.get("location_id") == location_id]
    resources = []
    for resource in (state.get("resources") or {}).values():
        holder_id = resource.get("holder_id")
        if (holder_id == pov_id or
                (holder_id is None and resource.get("location_id") == location_id)):
            resources.append({key: resource.get(key) for key in _RESOURCE_FIELDS})

    present.sort(key=lambda item: item["id"])
    resources.sort(key=lambda item: item["id"])
    return deepcopy({"location_id": location_id, "characters": present,
                     "resources": resources})
