"""数据结构校验：意图、结算结果、受限上下文。

分层约定（依据 docs/第一阶段实施任务.md「失败与认知」）：
- ProviderError 及其子类 = 基础设施失败（无效返回、超时、取消）。
  这类失败整步丢弃，步数不增加，外部队列不消费。
- 条件不足 / 意图过期 = 世界内行动失败（action.success=false），
  带原因正常提交，不算基础设施失败。失败结果必须无副作用：success=false 时
  resource_actions / actor_changes / location_changes 都必须是空的；附带非空
  变更属于自相矛盾的输出，按输出校验错误在应用之前拒绝，整步回滚。
- 结构无效 / 依赖缺失 = 输出校验错误（ProviderSchemaError），中止本步，
  在应用与提交之前失败，不能拖到数据库层才报错。
"""
from __future__ import annotations

import asyncio
import json
from typing import Any

from . import notes

VALID_ACTIONS = ("wait", "move", "speak", "act")

# 引擎允许结算结果改动的字段白名单，以及每个字段的值类型。
# 说明：这些是字符串型世界状态字段，拒绝数组/对象，也拒绝 null 与空白串。
ACTOR_FIELD_TYPES = {"status_text": "str"}
LOCATION_FIELD_TYPES = {"state_description": "str", "moment": "str"}

# 复杂行动的显式前置条件类型。
REQUIRE_TYPES = ("resource_state", "location_state")

# 引擎自己实现的结构化资源动作；只有这两种，语义由引擎保证，patch 绕不过去。
RESOURCE_ACTIONS = ("take", "drop")

# 失败结算不得附带的副作用字段：success=false 时这些都必须为空。
SIDE_EFFECT_GROUPS = ("resource_actions", "actor_changes", "location_changes")

# 退出信号：不得被收尾逻辑吞掉。
EXIT_SIGNALS = (KeyboardInterrupt, SystemExit, GeneratorExit)

# 失败定位用的阶段标签：推进失败后要能一眼看出是「角色决策」还是「复杂结算」出的问题，
# 以及涉及哪个角色。阶段名取自 engine 的 stage 与适配器的 stage，两处共用这一份映射，
# 避免同一个阶段在日志里出现两种叫法。
STAGE_LABELS = {"decide": "角色决策", "intent": "角色决策", "settle": "复杂结算",
                "narrate": "正文叙述", "interpret": "事件理解", "world_turn": "世界回合"}


def stage_label(stage: str, actors=None) -> str:
    """把内部阶段名翻成定位标签；未登记的阶段名原样返回。

    actors 可以是单个角色 id，也可以是 id 列表（批次结算一次涉及多个角色）。
    """
    name = STAGE_LABELS.get(stage, stage)
    if not actors:
        return name
    joined = actors if isinstance(actors, str) else "、".join(actors)
    return f"{name}（{joined}）"


class EngineError(Exception):
    """引擎自身错误（并发修改、状态不一致、登记被接管等）。"""


class StepBusy(EngineError):
    """同一 run 已有推进请求在进行中。"""


class LeaseLost(EngineError):
    """推进租约失效：登记被别的实例接管，或心跳持续失败到保不住租约。

    这是引擎错误而不是 provider 错误：当前推进必须中止，已经拿到的迟到结果
    不得提交（提交时的所有权复核是最后一道闸门）。
    """

    error_type = "lease_lost"


class ProviderError(Exception):
    """基础设施失败基类。"""

    error_type = "provider_error"


class ProviderInvalidOutput(ProviderError):
    error_type = "invalid_output"


class ProviderTimeout(ProviderError):
    error_type = "timeout"


class ProviderCancelled(ProviderError):
    error_type = "cancelled"


class ProviderSchemaError(ProviderInvalidOutput):
    """结构/依赖不合法的模型输出；归类为输出校验错误，不是存储故障。"""

    error_type = "schema"


class ProviderFailure(ProviderError):
    """provider 边界捕获到的未归一化异常（如 SDK 直接抛出 RuntimeError）。"""

    error_type = "provider_exception"


# ---- 真实 API 适配器细分错误（都属基础设施失败，语义见 docs/最小官方API接入任务.md）----
# 共同点：整步丢弃、步数不增加、外部队列不消费；差别只在 error_type 与用户该怎么处理。

class ProviderConfigError(ProviderError):
    """本机配置问题（缺少密钥、base_url 不合法）：调用前就失败，不发起任何请求。"""

    error_type = "config"


class ProviderAuthError(ProviderError):
    """认证失败（401）：密钥错误或失效。不重试，交用户修正配置。"""

    error_type = "auth"


class ProviderQuotaError(ProviderError):
    """余额不足（402）：不重试，交用户充值或调整预算。"""

    error_type = "quota"


class ProviderRateLimit(ProviderError):
    """触发限流（429）：官方说明并发超限时才返回，但首版仍不自动重发。"""

    error_type = "rate_limit"


class ProviderRequestRejected(ProviderError):
    """请求本身被拒（400 格式错误 / 422 参数无效）：属我方请求构造问题，不重试。"""

    error_type = "request_rejected"


class ProviderServiceError(ProviderError):
    """服务端错误或过载（500 / 503 及其它 5xx）：官方建议稍后重试，首版交用户显式决定。"""

    error_type = "service"


class ProviderNetworkError(ProviderError):
    """网络层失败（连接被拒、连接重置、传输中断）：请求是否已被受理不明确。"""

    error_type = "network"


class ProviderEmptyResponse(ProviderError):
    """HTTP 成功但内容为空：官方文档说明 JSON 模式偶发空响应。"""

    error_type = "empty_response"


class ProviderTruncated(ProviderError):
    """输出被 max_tokens 截断（finish_reason=length）：JSON 不完整，不能当有效输出用。"""

    error_type = "truncated"


# ---- 密钥擦除 ---------------------------------------------------------------
# 适配器在构造错误信息时已经做过一次擦除；这里再留一个出口，保证任何
# 「未归一的异常文本」在写入 error_log / 返回接口之前也过一次擦除。

_SECRET_SCRUBBERS: list = []


def register_secret_scrubber(fn) -> None:
    """注册密钥擦除函数：str -> str。重复注册同一个函数不会叠加。"""
    if fn not in _SECRET_SCRUBBERS:
        _SECRET_SCRUBBERS.append(fn)


def scrub_secrets(text) -> str:
    """把所有已注册的擦除规则应用到错误文本上。

    擦除器自身出错不影响错误上报：出错就跳过这一条。
    """
    out = text if isinstance(text, str) else str(text)
    for fn in _SECRET_SCRUBBERS:
        try:
            out = fn(out)
        except Exception:          # noqa: BLE001 - 擦除器不能反过来中断收尾路径
            continue
    return out


def classify_provider_exception(exc: BaseException, stage: str) -> ProviderError:
    """把 provider 边界上的任意异常归一化成 ProviderError。

    这不是模型错误分类的替代品：它只保证「未归一的异常」不会绕开引擎的收尾路径。
    """
    if isinstance(exc, ProviderError):
        return exc
    detail = f"{stage} 阶段 provider 异常：{type(exc).__name__}: {exc}"
    if isinstance(exc, asyncio.CancelledError):
        return ProviderCancelled(detail)
    if isinstance(exc, TimeoutError):
        return ProviderTimeout(detail)
    return ProviderFailure(detail)


def _as_json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"))


def _check_text_fields(changes: Any, field_types: dict[str, str], scope: str) -> dict:
    """逐项校验可变字段：先看字段名在白名单内，再看值类型。

    字段值一律是字符串型世界状态：拒绝数组/对象/布尔/null，也拒绝空白串。
    无效输出在这里就失败（输出校验错误），不会拖到数据库层才报错。
    """
    if not isinstance(changes, dict):
        raise ProviderSchemaError(f"{scope}变更必须是对象")
    unknown = sorted(set(changes) - set(field_types))
    if unknown:
        raise ProviderSchemaError(f"不允许改动的{scope}字段：{unknown}")
    for key, value in changes.items():
        if isinstance(value, bool) or not isinstance(value, str):
            raise ProviderSchemaError(
                f"{scope}字段 {key} 必须是字符串，收到 {type(value).__name__}")
        if not value.strip():
            raise ProviderSchemaError(f"{scope}字段 {key} 不能是空白串")
    return dict(changes)


def validate_intent(raw: Any, actor_id: str, character_ids: set[str],
                    location_ids: set[str], location_of: dict[str, str]) -> dict:
    """校验并规范化一次角色决策返回。

    引擎校验行动者、引用与允许的状态变化；无效即基础设施失败。
    """
    if not isinstance(raw, dict):
        raise ProviderSchemaError(f"意图必须是对象，收到 {type(raw).__name__}")

    got_actor = raw.get("actor_id")
    if got_actor is not None and got_actor != actor_id:
        raise ProviderSchemaError(f"意图行动者不匹配：期望 {actor_id}，收到 {got_actor}")

    action = raw.get("action")
    if action not in VALID_ACTIONS:
        raise ProviderSchemaError(f"未知行动类型：{action!r}")

    tone = raw.get("tone") or "平静"
    if not isinstance(tone, str):
        raise ProviderSchemaError("tone 必须是字符串")

    target = raw.get("target")
    text = raw.get("text")

    if action == "wait":
        if target not in (None, ""):
            raise ProviderSchemaError("wait 不应带 target")
        target = None
        text = None
    elif action == "move":
        if not isinstance(target, str) or not target:
            raise ProviderSchemaError("move 缺少 target 地点")
        if target not in location_ids:
            raise ProviderSchemaError(f"move 引用了不存在的地点：{target}")
        cur = location_of.get(actor_id)
        if target == cur:
            raise ProviderSchemaError(f"move 目标与当前地点相同：{target}")
        text = None
    elif action == "speak":
        if not isinstance(target, str) or not target:
            raise ProviderSchemaError("speak 缺少 target 人物")
        if target not in character_ids:
            raise ProviderSchemaError(f"speak 引用了不存在的人物：{target}")
        if target == actor_id:
            raise ProviderSchemaError("speak 目标不能是自己")
        if not isinstance(text, str) or not text.strip():
            raise ProviderSchemaError("speak 缺少内容 text")
    elif action == "act":
        if not isinstance(target, str) or not target.strip():
            raise ProviderSchemaError("act 缺少 target 描述")
        if text is not None and not isinstance(text, str):
            raise ProviderSchemaError("act 的 text 必须是字符串")

    # 个人状态更新（可选）：本人写下的打算与理解，随本次行动一起提交。
    # 结构错误在这里按输出校验错误失败（本步回滚）；空值/哨兵值表示沿用原值。
    # 未知字段名忽略（多写一个字段不该让整步回滚），记录在 state_ignored 里供核对。
    try:
        state_update, state_ignored = notes.normalize(raw.get("state"))
    except ValueError as exc:
        raise ProviderSchemaError(f"state 不合法：{exc}") from exc

    return {"actor_id": actor_id, "action": action, "target": target,
            "tone": tone, "text": text,
            "state_update": state_update, "state_ignored": state_ignored}


def _validate_requires(raw: Any, resource_ids: set[str], location_ids: set[str],
                       character_ids: set[str]) -> list[dict]:
    """校验结算声明的显式前置条件。

    只允许两类：资源状态与地点状态。结构无效或引用不存在 → 输出校验错误，
    中止本步（不是世界内失败）。真正「条件不满足」留到应用时按暂存状态复核。
    """
    if raw is None:
        return []
    if not isinstance(raw, list):
        raise ProviderSchemaError("requires 必须是数组")
    clauses: list[dict] = []
    for index, item in enumerate(raw):
        if not isinstance(item, dict):
            raise ProviderSchemaError(f"requires[{index}] 必须是对象")
        kind = item.get("type")
        if kind not in REQUIRE_TYPES:
            raise ProviderSchemaError(f"requires[{index}] 未知前置条件类型：{kind!r}")
        if kind == "resource_state":
            resource_id = item.get("resource_id")
            if not isinstance(resource_id, str) or not resource_id:
                raise ProviderSchemaError(f"requires[{index}] 缺少 resource_id")
            if resource_id not in resource_ids:
                raise ProviderSchemaError(
                    f"requires[{index}] 引用了不存在的资源：{resource_id}")
            clause: dict[str, Any] = {"type": "resource_state", "resource_id": resource_id}
            if "holder_id" in item:
                holder = item["holder_id"]
                if holder is not None and (not isinstance(holder, str)
                                           or holder not in character_ids):
                    raise ProviderSchemaError(
                        f"requires[{index}] holder_id 必须是 null 或已知人物：{holder!r}")
                clause["holder_id"] = holder
            if "location_id" in item:
                where = item["location_id"]
                if where is not None and (not isinstance(where, str)
                                          or where not in location_ids):
                    raise ProviderSchemaError(
                        f"requires[{index}] location_id 必须是 null 或已知地点：{where!r}")
                clause["location_id"] = where
            if "holder_id" not in clause and "location_id" not in clause:
                raise ProviderSchemaError(
                    f"requires[{index}] resource_state 至少要声明 holder_id 或 location_id")
            clauses.append(clause)
        else:
            location_id = item.get("location_id")
            if not isinstance(location_id, str) or location_id not in location_ids:
                raise ProviderSchemaError(
                    f"requires[{index}] location_id 不是已知地点：{location_id!r}")
            equals = item.get("equals")
            if not isinstance(equals, str) or not equals.strip():
                raise ProviderSchemaError(f"requires[{index}] location_state 缺少 equals 文本")
            clauses.append({"type": "location_state", "location_id": location_id,
                            "equals": equals})
    return clauses


def _validate_resource_actions(raw: Any, requires: list[dict],
                               resource_ids: set[str]) -> list[dict]:
    """校验结构化资源动作。

    依赖必须显式：每个被改动的资源都必须在 requires 里声明它依赖的状态，
    否则视为「条件缺失」的输出错误，中止本步。
    """
    if raw is None:
        return []
    if not isinstance(raw, list):
        raise ProviderSchemaError("resource_actions 必须是数组")
    declared = {clause["resource_id"] for clause in requires
                if clause["type"] == "resource_state"}
    actions: list[dict] = []
    for index, item in enumerate(raw):
        if not isinstance(item, dict):
            raise ProviderSchemaError(f"resource_actions[{index}] 必须是对象")
        action = item.get("action")
        if action not in RESOURCE_ACTIONS:
            raise ProviderSchemaError(
                f"resource_actions[{index}] 未知资源动作：{action!r}（只支持 "
                f"{list(RESOURCE_ACTIONS)}）")
        resource_id = item.get("resource_id")
        if not isinstance(resource_id, str) or not resource_id:
            raise ProviderSchemaError(f"resource_actions[{index}] 缺少 resource_id")
        if resource_id not in resource_ids:
            raise ProviderSchemaError(
                f"resource_actions[{index}] 引用了不存在的资源：{resource_id}")
        if resource_id not in declared:
            raise ProviderSchemaError(
                f"resource_actions[{index}] 缺少依赖声明：资源 {resource_id} 必须在"
                " requires 里声明所依赖的状态")
        actions.append({"action": action, "resource_id": resource_id})
    return actions


def validate_settlement(raw: Any, intent: dict, allowed_witnesses: set[str],
                        location_ids: set[str], character_ids: set[str],
                        actor_location: str, resource_ids: set[str] | None = None) -> dict:
    """校验一次复杂行动的结算返回。

    除结构、引用与观察范围外，还检查「失败」与「变更」互斥：success=false 时
    三类副作用字段必须为空，否则是矛盾输出，在这里（应用之前）就失败。
    """
    resource_ids = set(resource_ids or ())
    if not isinstance(raw, dict):
        raise ProviderSchemaError(f"结算必须是对象，收到 {type(raw).__name__}")

    actor_id = raw.get("actor_id")
    if actor_id != intent["actor_id"]:
        raise ProviderSchemaError(
            f"结算行动者不匹配：期望 {intent['actor_id']}，收到 {actor_id}")

    if not isinstance(raw.get("success"), bool):
        raise ProviderSchemaError("结算缺少布尔 success")
    success = bool(raw["success"])
    reason = raw.get("reason")
    if not isinstance(reason, str) or not reason.strip():
        raise ProviderSchemaError("结算缺少原因 reason")
    fact_text = raw.get("fact_text")
    if not isinstance(fact_text, str) or not fact_text.strip():
        raise ProviderSchemaError("结算缺少 fact_text")

    # 失败与状态变更不能同时成立：失败结算附带资源动作/角色变更/地点变更，
    # 会让事件叙述与持久化世界互相矛盾（复核复现：事件失败但钥匙真的换了手）。
    # 这类矛盾输出在本步应用之前就按输出校验错误拒绝，整步回滚。
    if not success:
        conflicts = [key for key in SIDE_EFFECT_GROUPS if raw.get(key)]
        if conflicts:
            raise ProviderSchemaError(
                "结算声明 success=false 却附带变更：" + "、".join(conflicts)
                + "（失败结果不得携带资源动作、角色变更或地点变更）")

    witnesses = raw.get("witnesses", [])
    if not isinstance(witnesses, list) or any(not isinstance(w, str) for w in witnesses):
        raise ProviderSchemaError("witnesses 必须是字符串数组")
    out_of_scope = sorted(set(witnesses) - allowed_witnesses)
    if out_of_scope:
        raise ProviderSchemaError(f"结算观察范围越界：{out_of_scope}")
    unknown = sorted(set(witnesses) - character_ids)
    if unknown:
        raise ProviderSchemaError(f"结算引用了不存在的人物：{unknown}")

    requires = _validate_requires(raw.get("requires"), resource_ids, location_ids,
                                  character_ids)
    resource_actions = _validate_resource_actions(raw.get("resource_actions"), requires,
                                                  resource_ids)

    if not isinstance(raw.get("actor_changes") or {}, dict):
        raise ProviderSchemaError("actor_changes 必须是对象")
    if not isinstance(raw.get("location_changes") or {}, dict):
        raise ProviderSchemaError("location_changes 必须是对象")
    actor_changes = _check_text_fields(raw.get("actor_changes") or {},
                                       ACTOR_FIELD_TYPES, "角色")
    location_changes = _check_text_fields(raw.get("location_changes") or {},
                                          LOCATION_FIELD_TYPES, "地点")

    target_location = raw.get("target_location") or actor_location
    if target_location not in location_ids:
        raise ProviderSchemaError(f"结算引用了不存在的地点：{target_location}")
    if target_location != actor_location:
        raise ProviderSchemaError("复杂行动只能结算本人所在地点；移动必须使用 move")

    return {
        "actor_id": actor_id,
        "success": success,
        "reason": reason.strip(),
        "fact_text": fact_text.strip(),
        "witnesses": sorted(set(witnesses)),
        "actor_changes": actor_changes,
        "location_changes": location_changes,
        "requires": requires,
        "resource_actions": resource_actions,
        "target_location": target_location,
    }
