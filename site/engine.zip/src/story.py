"""世界回合：每刻一条短局面记录 + 零或一件外界变化。

为什么单独一层：

- 已经结算的事实（event / observation）说明「发生过什么」，但没有任何一层负责
  「开场 IF 之后，世界还该不该继续把条件推到人物面前」。原来的路径只在开场排一次
  外部事件，此后完全靠人物自己行动与个人记忆，IF 的影响会自然衰减。
- 这一层只补这一个缺口：读 IF、上一次局面、近几刻已结算事件与后果、当前世界状态，
  给出**一句未解决的问题**、**建议关注的人与地点**，以及**零或一件外界变化**。

三条边界（写进提示词，也由本地校验兜住）：

1. 局面记录不是世界事实。它只给叙述组织篇幅用（见 src/narrate.py 的 focus），
   不进角色共同知识，不进任何人的决策输入。
2. 开场 IF 里的传言仍是**未核实的说法**。世界回合可以用它当条件来源，但不能把它
   写成已经证实的事实，也不能替人物认定真假。
3. 世界回合不替熊大、熊二、光头强决定态度、行动或台词，也不预定结局。

开关是显式的：场景快照里的 `story_loop.enabled`（可分别关掉 world_turn /
sequential_actions / public_speech / focus_hint）。旧运行包没有这一段，因此旧包与
旧存档完全走原来的推进路径，不会因为有 IF 就默默多出一次世界调用。
"""
from __future__ import annotations

import json

from . import scenario as scenario_mod
from .models import ProviderSchemaError

CONFIG_KEY = "story_loop"
SUB_FLAGS = ("world_turn", "sequential_actions", "public_speech", "focus_hint")
TABLE = "story_turn"

# 输出上限：世界回合是短局面，不是正文。超长直接截断（与 notes 同款取舍：
# 一个字段写长了不该让整步回滚），但事件描述过长同样只是截断，不额外补写。
MAX_OPEN_QUESTIONS = 300
MAX_EVENT_TEXT = 240
MAX_BASIS = 200
MAX_FOCUS = 4

WORLD_SYSTEM = """你在一个文字世界里担任「世界回合」的主持人。这一刻人物还没行动，你要判断：世界该不该把新的条件推到他们面前。

只依据用户给出的局面材料：开场 IF 及其类型、上一次世界回合留下的局面、近几刻**已经结算**的事件与成败、当前世界状态（地点、人物所在位置、物品归属），以及本刻刚生效的外部事件。

你要给出三样东西，尽量短：

1. open_questions：这一刻还没有解决的问题。一到两句，写具体的人、事、条件。
2. focus：建议接下来重点看哪几个人、哪个地点。只能从给定材料里的 id 里选，可以为空。
   它只是给叙述组织篇幅用的提示，**不是事实**，也不代表世界已经发生了什么。
3. event：零点或一件外界变化。**允许为 null**，不要求每刻都升级冲突。
   如果要给，必须与开场 IF 或已结算的后果有可追溯的联系，并写清 basis。

硬性要求：
- 开场 IF 里的「传言/说法」仍然是**未核实的说法**：不能写成已经证实的事实，也不能替任何人认定它是真是假。
- **不替人物决定态度、行动或台词**，不预测他们会怎么反应，不预定结局。
- 不新增人物；不使用材料之外的地点、人物、物品。
- 只写这个世界里正在发生的条件（传来新消息、现场留下痕迹、天气与工期变化、老板再次施压等）。
- 只输出一个 json 对象，不要解释、不要 markdown 代码块、不要在 json 之外写任何文字。

格式：
{
  "open_questions": "这一刻还没有解决的问题，一到两句",
  "focus": {"actors": ["<人物 id>"], "locations": ["<地点 id>"]},
  "event": null 或 {
    "scope": "all | location:<地点 id> | actor:<人物 id>",
    "description": "以陈述句写这件外界变化本身，不要写任何人的反应",
    "claim": null 或 "只在这是『一句传到某人耳朵里的话』时填写：这句说法本身",
    "claim_source_actor": null 或 "<人物 id>",
    "location_changes": {"<地点 id>": {"state_description": "现场描述", "moment": "短时刻说法"}},
    "basis": "一句话说明它和开场 IF 或哪件已结算的后果有关"
  }
}

字段规则：
- scope：all = 全场都能感知；location:<id> = 只有该地点的人；actor:<id> = 只有那个人。私下发生的事不要写 all。
- claim 非空时，落进人物认知的是「某人的说法」，不等于世界事实；没有说法就不要编。
- location_changes 只能改指定地点的 state_description 与 moment（现场描述与时刻），值是非空字符串。
- event 里的 id 必须来自下面的可用清单，写错会被引擎拒绝，本次推进整步回滚。

可用的人物（id）：<<characters>>
可用的地点（id）：<<locations>>
可用的资源（id）：<<resources>>
"""


# ------------------------------------------------------------------ 开关


def loop_config(scenario) -> dict:
    """读场景里的显式开关。没有这一段（旧包）＝全关，走原推进路径。

    `enabled` 是总开关；四个子项只在总开关打开时才有意义，缺省跟随总开关。
    """
    raw = (scenario or {}).get(CONFIG_KEY) if isinstance(scenario, dict) else None
    enabled = bool(isinstance(raw, dict) and raw.get("enabled"))
    cfg = {"enabled": enabled}
    for flag in SUB_FLAGS:
        value = raw.get(flag) if isinstance(raw, dict) else None
        cfg[flag] = bool(enabled and (True if value is None else value))
    return cfg


def is_enabled(scenario) -> bool:
    return loop_config(scenario)["enabled"]


# ------------------------------------------------------------------ 存取


def has_table(conn) -> bool:
    row = conn.execute("SELECT name FROM sqlite_master WHERE type='table' AND name=?",
                       (TABLE,)).fetchone()
    return row is not None


def ensure_table(conn) -> None:
    """幂等建表：旧存档直接跑一轮时也能写下局面记录（与 notes.ensure_table 同款兜底）。"""
    if has_table(conn):
        return
    conn.execute(
        f"CREATE TABLE IF NOT EXISTS {TABLE} ("
        " tick INTEGER PRIMARY KEY,"
        " open_questions TEXT NOT NULL DEFAULT '',"
        " focus_actors TEXT NOT NULL DEFAULT '[]',"
        " focus_locations TEXT NOT NULL DEFAULT '[]',"
        " event_scope TEXT,"
        " event_description TEXT,"
        " event_basis TEXT,"
        " auto_event_id INTEGER,"
        " source TEXT NOT NULL DEFAULT '',"
        " created_at TEXT NOT NULL)")


def _row_view(row) -> dict:
    event = None
    if row["event_scope"] is not None:
        event = {"scope": row["event_scope"], "description": row["event_description"] or "",
                 "basis": row["event_basis"] or ""}
    return {
        "tick": int(row["tick"]),
        "open_questions": row["open_questions"] or "",
        "focus": {"actors": json.loads(row["focus_actors"] or "[]"),
                  "locations": json.loads(row["focus_locations"] or "[]")},
        "event": event,
        "auto_event_id": row["auto_event_id"],
        "source": row["source"] or "",
    }


def load_turns(conn) -> dict[int, dict]:
    """读出全部局面记录；旧档还没有这张表时返回空表（不报错）。"""
    if not has_table(conn):
        return {}
    out: dict[int, dict] = {}
    for row in conn.execute(f"SELECT * FROM {TABLE} ORDER BY tick"):
        out[int(row["tick"])] = _row_view(row)
    return out


def load_turn(conn, tick: int) -> dict | None:
    """只读**目标刻自己**的那条记录：补写历史时不会拿到后来的局面。"""
    if not has_table(conn):
        return None
    row = conn.execute(f"SELECT * FROM {TABLE} WHERE tick=?", (int(tick),)).fetchone()
    return _row_view(row) if row is not None else None


def save_turn(conn, turn: dict, stamp: str) -> None:
    """写入本刻局面记录；只在本刻推进的提交事务里调用，技术失败不会留下半条。"""
    ensure_table(conn)
    event = turn.get("event") or {}
    focus = turn.get("focus") or {}
    conn.execute(
        f"INSERT OR REPLACE INTO {TABLE}(tick, open_questions, focus_actors, focus_locations,"
        " event_scope, event_description, event_basis, auto_event_id, source, created_at)"
        " VALUES(?,?,?,?,?,?,?,?,?,?)",
        (int(turn["tick"]), turn.get("open_questions") or "",
         json.dumps(list(focus.get("actors") or []), ensure_ascii=False),
         json.dumps(list(focus.get("locations") or []), ensure_ascii=False),
         event.get("scope"), event.get("description"), event.get("basis"),
         turn.get("auto_event_id"), turn.get("source") or "", stamp))


def turn_view(turn: dict | None) -> dict | None:
    """给推进结果/诊断看的一份拷贝（含本刻实际落下的自动事件 id）。"""
    if not turn:
        return None
    return {"tick": turn.get("tick"), "open_questions": turn.get("open_questions") or "",
            "focus": {"actors": list((turn.get("focus") or {}).get("actors") or []),
                      "locations": list((turn.get("focus") or {}).get("locations") or [])},
            "event": turn.get("event"),
            "auto_event_id": turn.get("auto_event_id"),
            "source": turn.get("source") or ""}


# ------------------------------------------------------------------ 请求


def _listing(items) -> str:
    return "、".join(str(item) for item in items) or "（无）"


def build_world_request(staging: dict, previous: dict | None, recent: list[dict],
                        applied: list[dict]) -> dict:
    """渲染世界回合的请求。

    输入里 rumor（说法）与已结算事实分开：`if.claim` 与 `just_effective_external[].claim`
    是说法，`recent_settled` 是已经结算的事实。人物的私有目标、个人状态与心理一律不进
    这里——世界回合不需要它们，也就无从把它们泄漏成「共同知识」。
    """
    scenario = staging["scenario"]
    run = staging["run"]
    patch = run.get("if_patch") or {}
    names = {cid: ch["name"] for cid, ch in staging["characters"].items()}

    def actor_name(actor_id):
        return names.get(actor_id, actor_id) if actor_id else None

    payload = {
        "tick": run["tick"],
        "if": {
            "text": run.get("if_condition") or "",
            "kind": patch.get("kind") or "",
            "scope": patch.get("scope") or "",
            "claim": patch.get("claim"),
            "description": patch.get("description") or "",
            "note": "if.claim（如果有）是未核实的说法，不是世界事实。",
        } if (run.get("if_condition") or "").strip() else None,
        "previous_turn": None,
        "recent_settled": [
            {"tick": ev["tick"], "kind": ev["kind"], "actor": actor_name(ev.get("actor_id")),
             "text": ev["text"], "success": bool(ev["success"]),
             "reason": (ev.get("reason") or "") or None}
            for ev in recent
        ],
        "just_effective_external": [
            {"scope": item["scope"], "description": item["description"],
             "claim": (item.get("payload") or {}).get("claim")}
            for item in applied
        ],
        "world": {
            "description": (scenario.get("world") or {}).get("description", ""),
            "locations": [
                {"id": loc["id"], "name": loc["name"], "description": loc["description"],
                 "state_description": loc["state_description"],
                 "moment": loc["moment"]}
                for loc in sorted(staging["locations"].values(), key=lambda item: item["id"])],
            "characters": [
                {"id": ch["id"], "name": ch["name"], "location_id": ch["location_id"],
                 "status_text": ch["status_text"]}
                for ch in sorted(staging["characters"].values(), key=lambda item: item["id"])],
            "resources": [
                {"id": res["id"], "name": res["name"], "location_id": res["location_id"],
                 "holder_id": res["holder_id"]}
                for res in sorted(staging["resources"].values(), key=lambda item: item["id"])],
        },
        "allowed": scenario_mod.known_scopes(scenario),
    }
    if previous:
        payload["previous_turn"] = {
            "tick": previous.get("tick"),
            "open_questions": previous.get("open_questions") or "",
            "focus": previous.get("focus") or {},
            "event": (previous.get("event") or {}).get("description"),
        }

    allowed = payload["allowed"]
    system = (WORLD_SYSTEM
              .replace("<<characters>>", _listing(
                  [f"{ch['name']}（{ch['id']}）" for ch in scenario.get("characters", [])]))
              .replace("<<locations>>", _listing(
                  [f"{loc['name']}（{loc['id']}）" for loc in scenario.get("locations", [])]))
              .replace("<<resources>>", _listing(
                  [f"{res.get('name', res['id'])}（{res['id']}）"
                   for res in scenario.get("resources", [])])))
    user = ("这是本刻世界回合的输入（json）。请只输出那一个 json 对象；"
            "allowed 是允许使用的范围写法与 id：\n"
            + json.dumps({**payload, "allowed": allowed}, ensure_ascii=False))
    return {"system": system, "user": user, "tick": run["tick"], "payload": payload}


# ------------------------------------------------------------------ 校验


def _check_text(value, limit: int, field: str) -> str:
    if value is None:
        return ""
    if not isinstance(value, str):
        raise ProviderSchemaError(f"{field} 必须是字符串，收到 {type(value).__name__}")
    return value.strip()[:limit]


def _check_location_changes(raw, location_ids: set[str]) -> dict:
    if raw in (None, {}):
        return {}
    if not isinstance(raw, dict):
        raise ProviderSchemaError("event.location_changes 必须是对象")
    clean: dict = {}
    for loc_id, fields in raw.items():
        if loc_id not in location_ids:
            raise ProviderSchemaError(f"event.location_changes 指向了不存在的地点：{loc_id}")
        if not isinstance(fields, dict):
            raise ProviderSchemaError(f"event.location_changes[{loc_id}] 必须是对象")
        unknown = sorted(set(fields) - {"state_description", "moment"})
        if unknown:
            raise ProviderSchemaError(
                f"event.location_changes[{loc_id}] 不支持这些字段：{'、'.join(unknown)}"
                "（只能改现场描述与时刻）")
        values = {key: _check_text(value, MAX_EVENT_TEXT, f"location_changes[{loc_id}].{key}")
                  for key, value in fields.items()}
        values = {key: value for key, value in values.items() if value}
        if values:
            clean[loc_id] = values
    return clean


def validate_turn(raw, scenario: dict, character_ids: set[str],
                  location_ids: set[str]) -> dict:
    """校验一次世界回合的返回。

    结构、范围与引用错误按输出校验错误处理（整步回滚）；世界回合**没有**「世界内失败」
    这一层——它要么给出一份可用的局面，要么这一步不提交。
    """
    if not isinstance(raw, dict):
        raise ProviderSchemaError(f"世界回合输出必须是对象，收到 {type(raw).__name__}")

    open_questions = _check_text(raw.get("open_questions"), MAX_OPEN_QUESTIONS, "open_questions")

    focus_raw = raw.get("focus") or {}
    if not isinstance(focus_raw, dict):
        raise ProviderSchemaError("focus 必须是对象")
    actors, locations = [], []
    for key, ids, known in (("actors", actors, character_ids),
                            ("locations", locations, location_ids)):
        values = focus_raw.get(key) or []
        if not isinstance(values, list):
            raise ProviderSchemaError(f"focus.{key} 必须是数组")
        for value in values:
            if not isinstance(value, str) or value not in known:
                raise ProviderSchemaError(f"focus.{key} 引用了不存在的 id：{value!r}")
            if value not in ids:
                ids.append(value)
    turn: dict = {"open_questions": open_questions,
                  "focus": {"actors": actors[:MAX_FOCUS], "locations": locations[:MAX_FOCUS]},
                  "event": None,
                  "source": "模型世界回合"}

    event = raw.get("event")
    if event in (None, {}, []):
        return turn
    if not isinstance(event, dict):
        raise ProviderSchemaError(f"event 必须是对象或 null，收到 {type(event).__name__}")
    scope = event.get("scope")
    if not isinstance(scope, str) or not scope.strip():
        raise ProviderSchemaError("event 缺少 scope")
    try:
        scenario_mod.check_scope(scenario, scope.strip())
    except scenario_mod.ScenarioError as exc:
        raise ProviderSchemaError(f"event.scope 不合法：{exc}") from exc
    description = _check_text(event.get("description"), MAX_EVENT_TEXT, "event.description")
    if not description:
        raise ProviderSchemaError("event 缺少 description（这件外界变化本身）")
    claim = _check_text(event.get("claim"), MAX_EVENT_TEXT, "event.claim")
    source_actor = event.get("claim_source_actor")
    if source_actor is not None:
        if not isinstance(source_actor, str) or source_actor not in character_ids:
            raise ProviderSchemaError(
                f"event.claim_source_actor 必须是 null 或已知人物 id：{source_actor!r}")
    if claim and not source_actor:
        source_actor = None
    if not claim and source_actor:
        raise ProviderSchemaError("event 没有 claim 时不应给出 claim_source_actor")
    turn["event"] = {
        "scope": scope.strip(),
        "description": description,
        "claim": claim or None,
        "claim_source_actor": source_actor,
        "location_changes": _check_location_changes(event.get("location_changes"), location_ids),
        "basis": _check_text(event.get("basis"), MAX_BASIS, "event.basis"),
    }
    return turn


# ------------------------------------------------------------------ 叙述侧重

# 局面焦点只用来组织篇幅，不改变事实域。焦点与实际事件不符时以事件为准。
FOCUS_RULE = ("局面焦点（如果输入给了 focus）只用来安排这一段的轻重：围绕真正改变局面的行动、"
              "反应与结果写，次要的等待与移动一句带过。它**不是事实清单**：focus 里提到的"
              "可能、计划或还没发生的变化，一个字都不许写成已经发生；"
              "焦点与本刻事件对不上时，以事件为准。")


def focus_for_narration(turn: dict | None, world: dict) -> dict | None:
    """把局面记录换成叙述能用的说法：id 一并给名字，避免模型猜。"""
    if not turn:
        return None
    focus = turn.get("focus") or {}
    characters = world.get("characters") or {}
    locations = world.get("locations") or {}
    actors = [{"id": cid, "name": characters.get(cid, {}).get("name", cid)}
              for cid in focus.get("actors") or []]
    places = [{"id": lid, "name": locations.get(lid, {}).get("name", lid)}
              for lid in focus.get("locations") or []]
    questions = (turn.get("open_questions") or "").strip()
    if not questions and not actors and not places:
        return None
    return {"open_questions": questions, "actors": actors, "locations": places,
            "note": "这是本刻的局面焦点，只用于安排篇幅；事实以 scene_log 为准。"}


__all__ = ["CONFIG_KEY", "SUB_FLAGS", "TABLE", "FOCUS_RULE", "WORLD_SYSTEM",
           "loop_config", "is_enabled", "has_table", "ensure_table", "load_turns",
           "load_turn", "save_turn", "turn_view", "build_world_request", "validate_turn",
           "focus_for_narration"]
