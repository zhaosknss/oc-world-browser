"""SQLite 连接与事务工具。

首阶段只使用标准库 sqlite3；事务策略见 schema.sql 顶部说明。
"""
from __future__ import annotations

import contextlib
import os
import sqlite3
import time
from datetime import datetime

SCHEMA_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "schema.sql")


def now() -> str:
    return datetime.now().isoformat(timespec="seconds")


def now_ms() -> int:
    """单调性更好的毫秒时间戳，用于租约心跳（同一台机器内比较即可）。"""
    return int(time.time() * 1000)


def connect(db_path: str) -> sqlite3.Connection:
    """打开一个连接。每个连接自管事务（isolation_level=None 走显式 BEGIN）。"""
    parent = os.path.dirname(os.path.abspath(db_path))
    if parent:
        os.makedirs(parent, exist_ok=True)
    conn = sqlite3.connect(db_path, timeout=5.0, isolation_level=None)
    conn.row_factory = sqlite3.Row
    # 保留正常日志与同步设置，首版不为性能关闭持久性保护。
    conn.execute("PRAGMA journal_mode=DELETE")
    conn.execute("PRAGMA synchronous=FULL")
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


def init_schema(conn: sqlite3.Connection) -> None:
    with open(SCHEMA_PATH, "r", encoding="utf-8") as fh:
        conn.executescript(fh.read())
    _migrate(conn)


def _migrate(conn: sqlite3.Connection) -> None:
    """幂等迁移：给已存在的库补上新增列（CREATE TABLE IF NOT EXISTS 不会改旧表）。

    首阶段只有 step_request 的一对租约列需要补；旧登记的 owner_id/heartbeat_ms 为 NULL，
    按「无租约信息即视为失效」处理，可由启动/恢复清理。
    演示层给 run 补了四个可空列（开场条件与结束信息），旧库补上后为 NULL，语义等同「没有条件、未结束」。

    索引必须在这里建，不能放在 schema.sql：旧库执行整个脚本时那两列还不存在，
    先建索引会在 CREATE INDEX 处直接报 no such column。
    """
    columns = {row[1] for row in conn.execute("PRAGMA table_info(step_request)")}
    for name, ddl in (("owner_id", "ALTER TABLE step_request ADD COLUMN owner_id TEXT"),
                      ("heartbeat_ms", "ALTER TABLE step_request ADD COLUMN heartbeat_ms INTEGER")):
        if name not in columns:
            conn.execute(ddl)
    conn.execute("CREATE INDEX IF NOT EXISTS idx_step_status ON step_request(status, heartbeat_ms)")

    run_columns = {row[1] for row in conn.execute("PRAGMA table_info(run)")}
    for name, ddl in (("if_condition", "ALTER TABLE run ADD COLUMN if_condition TEXT"),
                      ("if_patch", "ALTER TABLE run ADD COLUMN if_patch TEXT"),
                      ("prose_style", "ALTER TABLE run ADD COLUMN prose_style TEXT"),
                      ("ended_at", "ALTER TABLE run ADD COLUMN ended_at TEXT"),
                      ("ending_note", "ALTER TABLE run ADD COLUMN ending_note TEXT")):
        if name not in run_columns:
            conn.execute(ddl)

    seg_columns = {row[1] for row in conn.execute("PRAGMA table_info(prose_segment)")}
    if "prose_style" not in seg_columns:
        conn.execute("ALTER TABLE prose_segment ADD COLUMN prose_style TEXT")
    if "owner_id" not in seg_columns:
        conn.execute("ALTER TABLE prose_segment ADD COLUMN owner_id TEXT")


@contextlib.contextmanager
def write_txn(conn: sqlite3.Connection):
    """写事务：整组写入整体提交，异常整体回滚。

    BEGIN IMMEDIATE 让第二个并发写者在拿锁时就失败，而不是写到一半才发现冲突。
    """
    conn.execute("BEGIN IMMEDIATE")
    try:
        yield conn
    except BaseException:
        conn.execute("ROLLBACK")
        raise
    else:
        conn.execute("COMMIT")


def integrity_ok(conn: sqlite3.Connection) -> bool:
    row = conn.execute("PRAGMA integrity_check").fetchone()
    return bool(row) and row[0] == "ok"
