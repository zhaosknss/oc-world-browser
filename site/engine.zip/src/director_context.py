"""Lossless source-event indexing for the director's existing knowledge view.

No observation text, reliability, ownership, causal field, or world fact is
removed. Only equal source_event objects are stored once and referenced by the
observation's existing source_event_id. Conflicting or missing IDs stay inline.
"""
from __future__ import annotations

import copy
import json


def _id_key(value):
    if type(value) is int and value > 0:
        return str(value)
    if isinstance(value, str) and value:
        return value
    return None


def compact_knowledge(payload: dict) -> dict:
    """Deep-copy and index only character_knowledge[*][*].source_event.

    Reconstruct an indexed observation's source_event by looking up its
    source_event_id in source_event_index; an existing inline value takes
    precedence. The index is current data and does not widen actor knowledge.
    Existing index fields are left intact, making repeated calls safe and
    avoiding overwriting fields supplied by an older or independent caller.
    """
    result = copy.deepcopy(payload)
    knowledge = result.get("character_knowledge")
    if "source_event_index" in result or not isinstance(knowledge, dict):
        return result

    groups = {}
    conflicts = set()
    for observations in knowledge.values():
        if not isinstance(observations, list):
            continue
        for observation in observations:
            if not isinstance(observation, dict):
                continue
            event = observation.get("source_event")
            if not isinstance(event, dict):
                continue
            key = _id_key(observation.get("source_event_id"))
            if key is None or _id_key(event.get("event_id")) != key:
                continue
            try:
                # JSON equality distinguishes true/1 and 1/1.0, unlike Python's
                # value equality. Key insertion order is not a semantic change.
                fingerprint = json.dumps(event, ensure_ascii=False, sort_keys=True,
                                         separators=(",", ":"), allow_nan=False)
            except (TypeError, ValueError):
                conflicts.add(key)
                continue
            group = groups.setdefault(key, {"event": event, "fingerprint": fingerprint,
                                            "observations": []})
            if fingerprint != group["fingerprint"]:
                conflicts.add(key)
            group["observations"].append(observation)

    index = {}
    for key, group in groups.items():
        if key in conflicts:
            continue
        index[key] = group["event"]
        for observation in group["observations"]:
            observation.pop("source_event")
    if index:
        result["source_event_index"] = index
    return result
