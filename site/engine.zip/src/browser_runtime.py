"""Local browser dispatch for the existing library and complete chapter engine.

Only this adapter replaces transport/leases while dispatching. No desktop entry
point imports it. API credentials are memory-only and never read from host config.
"""
from __future__ import annotations

from contextlib import contextmanager
import json
from pathlib import Path
import shutil
import sqlite3
from urllib.parse import parse_qs, quote, urlsplit

from . import chapter_store, chapters, db, demo, engine, intervention, library as library_mod
from . import models, narrate, scenario
from .browser_lease import BrowserLease, close_active
from .browser_provider import BrowserDeepSeekProvider
from .deepseek import DEFAULT_BASE_URL, DEFAULT_MODEL
from .models import EngineError, ProviderError, StepBusy, scrub_secrets
from .provider import FakeProvider

BUILTIN_ID = "browser-sample"
RECOVERY_NOTE = ("上次操作中断。已保存的正式节点、推演检查点和完整章节草稿保留；请主动继续或重试。"
                 "未完成的一轮可能需要重新演绎，模型重试可能再次计费。")
MISSING_KEY_NOTE = "请先在「API 与存档」中填写自己的 DeepSeek API 密钥；已保存的正文仍可阅读。"
PUBLIC_API_ERRORS = {
    "auth": "API 认证失败。请检查密钥是否正确或已失效，再重新保存设置。",
    "quota": "API 账户余额或额度不足。请检查账户余额与用量额度，再决定是否重试。",
    "rate_limit": "API 请求受限。请稍后手动重试；本次没有自动重发。",
    "network": ("未能连接或读取 API 响应。请检查网络、API 地址，以及服务是否允许浏览器跨域访问。"
                "请求可能已被服务受理，重试可能再次计费。"),
    "timeout": "等待 API 响应超时。请求可能已被服务受理；请稍后决定是否手动重试，重试可能再次计费。",
    "service": "API 服务暂时不可用。请稍后手动重试；本次没有自动重发。",
    "request_rejected": "API 拒绝了请求参数。请核对模型名称和兼容 API 地址；若配置正确仍失败，请反馈此问题。",
    "config": "API 配置尚未就绪。请检查 API 密钥、模型与地址，再重新保存设置。",
}


class BrowserRuntime:
    def __init__(self, root="/app", data_root="/data", request=None, checkpoint=None):
        self.root, self.data_root = Path(root).resolve(), Path(data_root).resolve()
        self.data_root.mkdir(parents=True, exist_ok=True)
        self._request_bridge = request
        self._checkpoint_bridge = checkpoint
        self._key = ""
        self._settings_path = self.data_root / "browser-settings.json"
        self._drafts_path = self.data_root / "drafts.json"
        self._settings = {"provider": "deepseek", "model": DEFAULT_MODEL,
                          "base_url": DEFAULT_BASE_URL, "prepare_chapters": 1}
        if self._settings_path.exists():
            value = json.loads(self._settings_path.read_text(encoding="utf-8"))
            if not isinstance(value, dict):
                raise EngineError("本地浏览器设置不是合法对象")
            self._settings.update({k: value[k] for k in self._settings if k in value})
        self._validate_settings(self._settings)
        self._check_storage()
        with self._adapt():
            # Start with a no-network adapter, then use our explicit factory.
            self.library = library_mod.Library(self.data_root, "fake", project_root=self.root)
            self.library.provider_name = self._settings["provider"]
            self.library.import_provider = self._make_provider(self.library.provider_name, self.library.builtin)
        if self._drafts_path.exists():
            drafts = json.loads(self._drafts_path.read_text(encoding="utf-8"))
            if not isinstance(drafts, dict):
                raise EngineError("本地资料预览存档不是合法对象")
            for draft in drafts.values():
                if not isinstance(draft, dict) or not isinstance(draft.get("scenario"), dict):
                    raise EngineError("本地资料预览存档缺少世界资料")
                library_mod.validate_pack(draft["scenario"])
            self.library.drafts = drafts
        self.recovered_requests = self._recover_interrupted()
        self._discard_orphans()
        self._save_public_settings()
        self._save_drafts()

    def _make_provider(self, name, world, faults=None, options=None):
        if name == "fake":
            provider = FakeProvider(world, faults)
            provider.config = {"prepare_chapters": self._settings["prepare_chapters"]}
            return provider
        if name not in ("deepseek", "deepseek-api", "real"):
            raise EngineError("浏览器版提供方只支持 DeepSeek 或模拟模式")
        explicit = {"model": self._settings["model"], "base_url": self._settings["base_url"],
                    "api_key": self._key, "max_tokens": 8192, "settle_max_tokens": 16384,
                    "narrate_max_tokens": 8192, "interpret_max_tokens": 8192,
                    "chapter_max_tokens": 16384, "world_max_tokens": 8192,
                    "prepare_chapters": self._settings["prepare_chapters"]}
        return BrowserDeepSeekProvider(world, explicit, self._request_bridge, self._checkpoint)

    @contextmanager
    def _adapt(self):
        # The Worker is single-threaded; restore every module reference on exit so
        # CPython tests and the original desktop service keep their implementations.
        replacements = [(library_mod, "build_provider", self._make_provider),
                        (library_mod, "BUILTIN_ID", BUILTIN_ID),
                        (library_mod, "BUILTIN_PACK", self.root / "scenarios" / "browser-sample.json"),
                        (library_mod, "LEGACY", ()),
                        (chapters, "StepLease", BrowserLease), (engine, "StepLease", BrowserLease)]
        previous = [(module, name, getattr(module, name)) for module, name, _ in replacements]
        for module, name, value in replacements:
            setattr(module, name, value)
        redactor = lambda value: str(value).replace(self._key, "[REDACTED]") if self._key else str(value)
        models.register_secret_scrubber(redactor)
        try:
            yield
        finally:
            if redactor in models._SECRET_SCRUBBERS:
                models._SECRET_SCRUBBERS.remove(redactor)
            for module, name, value in reversed(previous):
                setattr(module, name, value)

    def _check_storage(self):
        for path in self.data_root.rglob("*.db"):
            if not path.resolve().is_relative_to(self.data_root):
                raise EngineError("存档文件不在浏览器数据目录内")
            uri = "file:" + quote(path.as_posix(), safe="/:") + "?mode=ro"
            conn = sqlite3.connect(uri, uri=True)
            try:
                if conn.execute("PRAGMA integrity_check").fetchone()[0] != "ok":
                    raise EngineError("本地数据库完整性核查未通过：" + path.name)
                if path == self.data_root / "catalog.db":
                    columns = {r[1] for r in conn.execute("PRAGMA table_info(stories)")}
                    if "db_path" not in columns:
                        raise EngineError("故事目录缺少存档路径")
                    working = "working_path" if "working_path" in columns else "NULL"
                    for row in conn.execute(f"SELECT db_path,{working} FROM stories"):
                        for value in row:
                            if value and not Path(value).resolve().is_relative_to(self.data_root):
                                raise EngineError("导入目录引用了浏览器数据目录以外的存档")
            finally:
                conn.close()

    def _recover_interrupted(self):
        recovered = []
        for path in self.data_root.glob("stories/*/world.db"):
            conn = db.connect(str(path))
            try:
                tables = {r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
                with db.write_txn(conn):
                    for table in ("chapter_request", "step_request"):
                        if table not in tables:
                            continue
                        rows = list(conn.execute(f"SELECT request_id FROM {table} WHERE status='in_progress'"))
                        recovered.extend({"story_id": path.parent.name, "request_id": r[0]} for r in rows)
                        conn.execute(f"UPDATE {table} SET status='failed',owner_id=NULL,heartbeat_ms=NULL,error=?,updated_at=? "
                                     "WHERE status='in_progress'", (RECOVERY_NOTE, db.now()))
                    if "prose_segment" in tables:
                        conn.execute("UPDATE prose_segment SET status='failed',owner_id=NULL,error=?,updated_at=? "
                                     "WHERE status='generating'", (RECOVERY_NOTE, db.now()))
            finally:
                conn.close()
        return recovered

    def _discard_orphans(self):
        # A crashed, incomplete simulation is speculative. Fully saved chapter
        # drafts live in world.db and remain available for a writing-only retry.
        for workspace in self.data_root.glob("stories/*/.chapter-work"):
            for path in workspace.glob("request-*"):
                if path.is_dir() and path.resolve().is_relative_to(self.data_root):
                    shutil.rmtree(path)

    @staticmethod
    def _validate_settings(settings):
        count = settings.get("prepare_chapters")
        if type(count) is not int or count not in (1, 2):
            raise EngineError("章节准备范围需要为 1 或 2")
        if settings.get("provider") not in ("fake", "deepseek"):
            raise EngineError("提供方需要为 deepseek 或 fake")
        model = settings.get("model")
        if not isinstance(model, str) or not 1 <= len(model.strip()) <= 100:
            raise EngineError("模型名称需要 1–100 字")
        base = settings.get("base_url")
        parsed = urlsplit(base) if isinstance(base, str) else None
        if not parsed or parsed.scheme != "https" or not parsed.hostname or parsed.username or parsed.password or parsed.query or parsed.fragment:
            raise EngineError("浏览器 API 地址需要不含凭据或查询参数的 HTTPS 地址")

    def settings(self, body=None):
        if body is not None:
            next_settings = dict(self._settings)
            if "mode" in body and "provider" not in body:
                body = {**body, "provider": body["mode"]}
            next_settings.update({k: body[k] for k in next_settings if k in body})
            self._validate_settings(next_settings)
            if "api_key" in body:
                key = body["api_key"]
                if not isinstance(key, str) or len(key) > 1024:
                    raise EngineError("API 密钥需要不超过 1024 字的文字")
                self._key = key.strip()
            self._settings = next_settings
            self.library.provider_name = next_settings["provider"]
            self.library.import_provider = self._make_provider(next_settings["provider"], self.library.builtin)
            self.library.runtimes.clear()
            self._save_public_settings()
        return {**self._settings, "mode": self._settings["provider"],
                "thinking": "enabled", "reasoning_effort": "high",
                "has_api_key": bool(self._key), "storage": "browser-local",
                "recovery_note": RECOVERY_NOTE if self.recovered_requests else "",
                "recovered_requests": list(self.recovered_requests)}

    def _save_public_settings(self):
        self._settings_path.write_text(json.dumps(self._settings, ensure_ascii=False), encoding="utf-8")

    def _save_drafts(self):
        self._drafts_path.write_text(json.dumps(self.library.drafts, ensure_ascii=False), encoding="utf-8")

    def _checkpoint(self):
        self._save_drafts()
        if self._checkpoint_bridge is not None:
            self._checkpoint_bridge()
            return
        try:
            from js import ocBrowserCheckpoint
        except ImportError:
            return
        ocBrowserCheckpoint()

    def dispatch(self, method, path, body=None):
        """Return the existing JSON body; errors include http_status for fetch."""
        body = {} if body is None else body
        if not isinstance(body, dict):
            return {"error": "请求体必须是 JSON 对象", "code": "engine", "http_status": 400}
        with self._adapt():
            try:
                result = self._dispatch(str(method).upper(), path, body)
                # The shared chapter engine deliberately hides review details.
                # Map only infrastructure types to fixed public instructions;
                # never consult private API, director, review or draft text.
                if result.get("action") == "advance_failed":
                    failed = result.get("advanced", {})
                    error_type = failed.get("error_type")
                    if error_type in PUBLIC_API_ERRORS:
                        failed["error"] = PUBLIC_API_ERRORS[error_type]
                        if error_type in ("auth", "config"):
                            result["api_key_required"] = True
                        if (error_type == "config" and not self._key
                                and self._settings["provider"] == "deepseek"):
                            failed["error"] = MISSING_KEY_NOTE
            except StepBusy as exc:
                result = {"error": scrub_secrets(exc), "code": "busy", "http_status": 409}
            except ProviderError as exc:
                result = {"error": scrub_secrets(exc), "code": exc.error_type, "http_status": 502}
            except (EngineError, scenario.ScenarioError, demo.DemoError, intervention.InterventionError) as exc:
                result = {"error": scrub_secrets(exc), "code": "engine", "http_status": 400}
            except Exception as exc:
                result = {"error": scrub_secrets(f"{type(exc).__name__}: {exc}"), "code": "browser", "http_status": 500}
            finally:
                close_active()
                self._save_drafts()
        return result

    def _dispatch(self, method, path, body):
        parsed = urlsplit(path)
        route, query = parsed.path, parse_qs(parsed.query)
        sid = (query.get("story") or [""])[0]
        if route == "/api/settings" and method in ("GET", "POST"):
            return self.settings(body if method == "POST" else None)
        if method == "GET":
            if route == "/api/health":
                return {"ok": True, "mode": "browser", "provider": self.library.import_provider.describe()}
            if route == "/api/library/stories":
                return {"stories": self.library.list_stories()}
            if route == "/api/library/worlds":
                return {"worlds": self.library.list_worlds()}
            if route == "/api/library/world":
                return self.library.world_detail((query.get("world_id") or [""])[0])
            if route == "/api/library/workbench":
                return self.library.workbench()
            if route == "/api/library/setting-guide":
                return self.library.setting_guide()
            if route == "/api/state" and not sid:
                return self.library.active_state()
            bound = self.library.open_story(sid)
            if route == "/api/reading":
                value = narrate.reading_view(bound.db_path, bound.provider)
                value["story_title"] = self.library.story_title(sid)
                value["browser_recovery_note"] = RECOVERY_NOTE if self.recovered_requests else ""
                return value
            if route == "/api/result":
                return bound.runner.get_result((query.get("request_id") or [""])[0])
            if route == "/api/state":
                return bound.runner.get_state()
        if method == "POST":
            if route == "/api/library/story":
                return self.library.create_story(body.get("world_id") or "", body.get("title") or "")
            if route == "/api/library/rename":
                return self.library.rename(body.get("story_id") or "", body.get("title") or "")
            if route == "/api/library/remove":
                return self.library.remove(body.get("story_id") or "")
            if route == "/api/library/restore":
                return self.library.restore(body.get("story_id") or "")
            if route == "/api/library/analyze":
                return self.library.analyze(body.get("filename") or "", body.get("data_base64") or "")
            if route == "/api/library/workbench":
                return self.library.workbench(body)
            if route == "/api/library/discuss-world":
                return self.library.discuss_world(body.get("materials", ""), body.get("messages", []),
                                                  body.get("current_scenario"))
            if route == "/api/library/organize-world":
                return self.library.organize_world(body.get("materials", ""), body.get("messages", []),
                                                   body.get("current_scenario"), body.get("fill_missing", False))
            if route == "/api/library/validate-world":
                return self.library.validate_world(body.get("scenario"), body.get("evidence"),
                                                   body.get("materials"), body.get("messages"))
            if route == "/api/library/save-world":
                return self.library.save_draft(body.get("draft_id") or "", body.get("edits") or {})
            if route == "/api/library/update-world":
                return self.library.update_world(body.get("world_id") or "", body.get("expected_version"), body.get("edits") or {})
            bound = self.library.begin_story(sid)
            try:
                if route == "/api/style":
                    return narrate.set_prose_style(bound.db_path, body.get("style") or "")
                if route == "/api/start":
                    return demo.start_run(bound.db_path, bound.provider, body.get("if_text") or "")
                if route in ("/api/continue", "/api/continue-stream"):
                    return narrate.continue_reading(bound.db_path, bound.provider, bound.runner, body.get("request_id") or "")
                if route == "/api/intervene":
                    return intervention.queue_intervention(bound.db_path, bound.provider, body.get("text") or "")
                if route == "/api/end":
                    return demo.end_run(bound.db_path, body.get("note"))
                if route == "/api/recover":
                    return bound.runner.recover()
                if route == "/api/events":
                    preset = body.get("preset_key") or ""
                    eid = scenario.queue_external(bound.db_path, preset)
                    return {"queued": True, "event_id": eid, "preset_key": preset}
                if route == "/api/narrate":
                    if body.get("missing"):
                        return narrate.narrate_missing(bound.db_path, bound.provider, int(body.get("limit") or 6))
                    tick = body.get("tick")
                    if type(tick) is not int:
                        raise EngineError("补写正文需要 tick")
                    segment, stats = narrate.narrate_tick(bound.db_path, bound.provider, tick, force=bool(body.get("force")))
                    return {"segment": segment, "accounting": stats}
            finally:
                self.library.end_story(sid)
        return {"error": "未找到浏览器接口", "code": "not_found", "http_status": 404}
