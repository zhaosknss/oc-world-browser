"""推进请求的租约与心跳。

一个 run 一次只允许一个推进请求。判断「这个在途登记还算不算数」需要一个
进程存活的判据，本阶段用最小方案：**租约 + 心跳**。

- 登记时写入 owner_id 和 heartbeat_ms。
- 推进期间由后台线程按 HEARTBEAT_MS 刷新 heartbeat_ms（自身独立连接）。
- 只要心跳没超过 LEASE_MS，登记就被视为「仍由某个活着的实例持有」，
  恢复接口与启动清理都不会碰它；心跳过期才允许清理。

心跳线程的失败处理（本轮修复）：
- 建立连接与更新心跳都在错误处理之内。一次瞬时 SQLite/连接错误只是「这一次
  没续上」，线程继续在租约窗口内重试，不会静默结束续租。
- 只有在两种情况下才判定租约失效，并把失效原因显式交给引擎：
  1. 心跳更新命中 0 行——登记已不属于本实例（被别的实例接管）；
  2. 连续失败累计到距上次成功续租已超过 LEASE_MS——租约已经保不住。
- 失效后 `raise_if_dead()` 让当前推进进入取消/失败路径，迟到结果不得提交；
  即使这里漏判，提交时的所有权复核仍是最后一道闸门。
- 诊断信息（心跳次数、失败次数、最后一次错误、心跳年龄）留在实例上，
  并进入抛出的失效原因，随 error_log 落库。

边界（明确写出，不假装是完备的进程存活检测）：
- 进程被 SIGSTOP/宿主挂起超过租约时长后，别的进程可以合法接管，本实例随后
  必须靠提交时的所有权复核失败退出，不会覆盖别人的提交。
- 时钟回拨可能让心跳看起来过期；同一台机器上按毫秒时间戳比较，风险已知。
"""
from __future__ import annotations

import sqlite3
import threading

from . import db
from .models import LeaseLost

DEFAULT_LEASE_MS = 10_000
DEFAULT_HEARTBEAT_MS = 2_000


def lease_alive(heartbeat_ms, now_ms: int, lease_ms: int) -> bool:
    """心跳在租约窗口内视为存活；没有心跳信息的旧登记视为失效。"""
    if heartbeat_ms is None:
        return False
    return (now_ms - int(heartbeat_ms)) < int(lease_ms)


class StepLease:
    """推进期间刷新 step_request.heartbeat_ms 的后台心跳。"""

    def __init__(self, db_path: str, request_id: str, owner_id: str,
                 interval_ms: int = DEFAULT_HEARTBEAT_MS,
                 lease_ms: int = DEFAULT_LEASE_MS, table: str = "step_request"):
        if table not in ("step_request", "chapter_request"):
            raise ValueError("unsupported lease table")
        self.table = table
        self.db_path = db_path
        self.request_id = request_id
        self.owner_id = owner_id
        self.interval_ms = max(int(interval_ms), 0)
        self.lease_ms = max(int(lease_ms), 0)
        self._stop = threading.Event()
        self._dead = threading.Event()
        self.dead_reason: str | None = None
        # 诊断信息：心跳线程结束或判定失效后仍可读取。
        self.beats = 0
        self.failures = 0
        self.last_error: str | None = None
        # 登记刚刚写入 heartbeat_ms=now，构造时刻即最后一次成功续租的近似值。
        self._last_ok_ms = db.now_ms()
        self._thread: threading.Thread | None = None

    # ------------------------------------------------------------ 状态查询
    def is_dead(self) -> bool:
        return self._dead.is_set()

    def diagnostics(self) -> dict:
        return {
            "request_id": self.request_id,
            "owner_id": self.owner_id,
            "beats": self.beats,
            "failures": self.failures,
            "last_error": self.last_error,
            "heartbeat_age_ms": db.now_ms() - self._last_ok_ms,
            "lease_ms": self.lease_ms,
            "dead": self.is_dead(),
            "dead_reason": self.dead_reason,
        }

    def raise_if_dead(self) -> None:
        """租约失效时中止当前推进；正常时不做任何事。"""
        if self._dead.is_set():
            raise LeaseLost(self.dead_reason or "推进租约已失效")

    # ------------------------------------------------------------ 生命周期
    def start(self) -> None:
        if self.interval_ms <= 0:
            return
        self._thread = threading.Thread(target=self._beat, name="oc-world-lease",
                                        daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        if self._thread is not None:
            self._thread.join(timeout=2.0)
            self._thread = None

    def _beat(self) -> None:
        while not self._stop.wait(self.interval_ms / 1000.0):
            self.refresh()
            if self._dead.is_set():
                return           # 已判定失效：继续续租没有意义，交给引擎收尾

    # ------------------------------------------------------------ 续租
    def refresh(self) -> bool:
        """续租一次，返回是否成功；失败时按需判定租约失效。

        连接建立与心跳更新都在错误处理之内：瞬时错误只记一次失败，线程会在
        租约窗口内继续重试。只有登记被接管或租约已经保不住时才置失效位。
        """
        try:
            conn = db.connect(self.db_path)
        except sqlite3.Error as exc:
            return self._on_failure(f"建立连接失败：{type(exc).__name__}: {exc}")
        try:
            try:
                cur = conn.execute(
                    f"UPDATE {self.table} SET heartbeat_ms=? WHERE request_id=?"
                    " AND owner_id=? AND status='in_progress'",
                    (db.now_ms(), self.request_id, self.owner_id))
                changed = cur.rowcount
            except sqlite3.Error as exc:
                return self._on_failure(f"更新心跳失败：{type(exc).__name__}: {exc}")
        finally:
            try:
                conn.close()
            except sqlite3.Error:
                pass
        if changed == 1:
            self.beats += 1
            self.failures = 0
            self.last_error = None
            self._last_ok_ms = db.now_ms()
            return True
        # 命中 0 行：登记已经不在本实例名下（被接管），或已不是 in_progress。
        # 这是所有权丢失，不必等租约过期——继续跑下去只会产生迟到结果。
        self._die(f"续租失败：登记 {self.request_id} 已不属于本实例 {self.owner_id}"
                  f"（可能已被其他实例接管），当前推进的租约失效")
        return False

    def _on_failure(self, error: str) -> bool:
        """记一次续租失败；失败累积到超出租约窗口就判定失效。"""
        self.failures += 1
        self.last_error = error
        age = db.now_ms() - self._last_ok_ms
        if age >= self.lease_ms:
            self._die(f"续租失败：连续 {self.failures} 次错误，"
                      f"距上次成功续租 {age}ms 已超过租约 {self.lease_ms}ms，"
                      f"无法再保住登记 {self.request_id}；最后一次错误：{error}")
        return False

    def _die(self, reason: str) -> None:
        self.dead_reason = reason
        self._dead.set()
        self._stop.set()
