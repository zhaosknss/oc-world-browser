"""Retain validated model results for the current, unpublished exchange.

The saved world stays at the previous complete exchange. On retry, deterministic
settlement is replayed from that world, using a result only when its input still
matches. Responses contain no model reasoning or credentials.
"""
from __future__ import annotations

from copy import deepcopy
import hashlib
import json


class BeatReplay:
    def __init__(self, entries, checkpoint):
        self.entries = entries
        self.checkpoint = checkpoint
        self.cursor = 0

    def run(self, kind, payload, operation):
        key = hashlib.sha256(json.dumps([kind, payload], ensure_ascii=False,
            sort_keys=True, separators=(",", ":")).encode("utf-8")).hexdigest()
        index = self.cursor
        self.cursor += 1
        if index < len(self.entries) and self.entries[index]["key"] == key:
            return deepcopy(self.entries[index]["result"])
        result = operation()  # Only a fully validated result is retained.
        del self.entries[index:]
        self.entries.append({"key": key, "result": deepcopy(result)})
        self.checkpoint()
        return result

    def discard_from(self, index):
        """A structurally impossible action batch needs a fresh actor response."""
        del self.entries[index:]
        self.checkpoint()
