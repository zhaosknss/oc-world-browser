-- oc-world 首阶段运行状态库
-- 单个 SQLite 数据库是运行状态的正式保存位置。
-- 事务策略：回滚日志（journal_mode=DELETE）+ synchronous=FULL，保留持久性保护。

CREATE TABLE IF NOT EXISTS meta (
  key   TEXT PRIMARY KEY,
  value TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS run (
  run_id           INTEGER PRIMARY KEY CHECK (run_id = 1),
  scenario_id      TEXT    NOT NULL,
  scenario_version TEXT    NOT NULL,
  tick             INTEGER NOT NULL DEFAULT 0,
  status           TEXT    NOT NULL DEFAULT 'paused',  -- paused | running | error | ended
  world_revision   INTEGER NOT NULL DEFAULT 0,
  actor_cursor     INTEGER NOT NULL DEFAULT 0,
  provider_mode    TEXT    NOT NULL DEFAULT 'fake',
  last_error       TEXT,
  if_condition     TEXT,   -- 开场 IF 原文（演示层；NULL = 还没写条件）
  if_patch         TEXT,   -- IF 的结构化补丁（json：范围、落地方式与开局调整）
  prose_style      TEXT,   -- 正文详略：brief=简洁 | 其它/NULL=正常
  ended_at         TEXT,   -- 手动结束时间（非空即已结束）
  ending_note      TEXT,   -- 结束说明（演示层写，不假装自然收束）
  created_at       TEXT    NOT NULL,
  updated_at       TEXT    NOT NULL
);

CREATE TABLE IF NOT EXISTS location (
  id                TEXT PRIMARY KEY,
  name              TEXT NOT NULL,
  description       TEXT NOT NULL,
  connections       TEXT NOT NULL DEFAULT '[]',   -- JSON: [location_id]
  moment            TEXT NOT NULL DEFAULT '',
  state_description TEXT NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS character (
  id               TEXT PRIMARY KEY,
  name             TEXT NOT NULL,
  description      TEXT NOT NULL,
  goals            TEXT NOT NULL DEFAULT '[]',    -- JSON: [str]
  current_tendency TEXT NOT NULL DEFAULT '',
  change_reason    TEXT NOT NULL DEFAULT '',
  location_id      TEXT NOT NULL,
  status_text      TEXT NOT NULL DEFAULT '正常',
  updated_tick     INTEGER NOT NULL DEFAULT 0
);

-- 已结算世界事实。消息的“发送”是事实，消息里的说法未必真实。
CREATE TABLE IF NOT EXISTS event (
  event_id          INTEGER PRIMARY KEY AUTOINCREMENT,
  tick              INTEGER NOT NULL,
  seq               INTEGER NOT NULL,             -- 本 tick 内的结算顺序
  kind              TEXT    NOT NULL,             -- external | move | speak | act | wait
  actor_id          TEXT,
  target_id         TEXT,
  location_id       TEXT,
  text              TEXT    NOT NULL,
  success           INTEGER NOT NULL DEFAULT 1,
  reason            TEXT    NOT NULL DEFAULT '',
  witnesses         TEXT    NOT NULL DEFAULT '[]',-- JSON: [actor_id]
  external_event_id INTEGER,
  created_at        TEXT    NOT NULL
);

-- 角色认知 / 观察。owner 是获得这条认知的角色。
CREATE TABLE IF NOT EXISTS observation (
  obs_id          INTEGER PRIMARY KEY AUTOINCREMENT,
  owner_id        TEXT    NOT NULL,
  tick            INTEGER NOT NULL,
  content         TEXT    NOT NULL,
  source_type     TEXT    NOT NULL,               -- direct | message | inference
  source_event_id INTEGER,
  source_actor_id TEXT,                           -- 来源人物（适用时）
  first_hand      INTEGER NOT NULL DEFAULT 1,     -- 0 = 转述/听闻
  reliable        INTEGER NOT NULL DEFAULT 1,     -- 0 = 未获证实的说法
  created_at      TEXT    NOT NULL
);

CREATE TABLE IF NOT EXISTS external_event (
  event_id         INTEGER PRIMARY KEY AUTOINCREMENT,
  preset_key       TEXT NOT NULL,
  scope            TEXT NOT NULL,                 -- all | location:<id> | actor:<id>
  description      TEXT NOT NULL,
  payload          TEXT NOT NULL DEFAULT '{}',
  status           TEXT NOT NULL DEFAULT 'pending',  -- pending | consumed
  created_tick     INTEGER NOT NULL,
  consumed_tick    INTEGER,
  consumed_event_id INTEGER,
  created_at       TEXT NOT NULL
);

-- 世界资源。unique_item=1 表示唯一物件：同一时刻只能由一个持有者取得。
CREATE TABLE IF NOT EXISTS resource (
  id           TEXT PRIMARY KEY,
  name         TEXT NOT NULL,
  description  TEXT NOT NULL DEFAULT '',
  location_id  TEXT,                              -- 所在地点；被取走后为 NULL
  holder_id    TEXT,                              -- 持有者；未被取走时为 NULL
  unique_item  INTEGER NOT NULL DEFAULT 1,
  updated_tick INTEGER NOT NULL DEFAULT 0
);

-- 一个 run 一次只允许一个推进请求；request_id 去重并保存已提交结果。
--
-- 在途登记带「实例所有权 + 租约心跳」：
--   owner_id     本次推进所属的 Runner 实例；
--   heartbeat_ms 最近一次心跳的毫秒时间戳（推进期间由后台心跳持续刷新）。
-- 只有心跳超过租约时长的登记才算失效，恢复/启动清理只处理失效登记；
-- 进程存活期间心跳是新的，因此另一进程的启动或恢复不会释放它的请求。
CREATE TABLE IF NOT EXISTS step_request (
  request_id   TEXT PRIMARY KEY,
  tick         INTEGER NOT NULL,
  status       TEXT    NOT NULL,                  -- in_progress | committed | failed
  result       TEXT,
  error        TEXT,
  owner_id     TEXT,
  heartbeat_ms INTEGER,
  created_at   TEXT NOT NULL,
  updated_at   TEXT NOT NULL
);

-- 独立运行错误记录，供重试和排查；不参与世界状态。
CREATE TABLE IF NOT EXISTS error_log (
  error_id   INTEGER PRIMARY KEY AUTOINCREMENT,
  request_id TEXT,
  tick       INTEGER,
  stage      TEXT NOT NULL,
  error_type TEXT NOT NULL,
  message    TEXT NOT NULL,
  created_at TEXT NOT NULL
);

-- 阅读正文。一段 = 一个 tick（分段粒度见 scenarios/*.json 的 narration 段），
-- 与它来源的事件范围一起保存：世界推进已经提交、正文生成失败时只补这一段，不重复推进。
-- 状态：pending（尚未生成）| generating（正在生成，带心跳）| committed | failed。
CREATE TABLE IF NOT EXISTS prose_segment (
  seg_id        INTEGER PRIMARY KEY AUTOINCREMENT,
  tick          INTEGER NOT NULL UNIQUE,
  status        TEXT    NOT NULL DEFAULT 'pending',
  pov_actor_id  TEXT,
  from_event_id INTEGER,
  to_event_id   INTEGER,
  prose         TEXT    NOT NULL DEFAULT '',
  digest        TEXT    NOT NULL DEFAULT '',   -- 事实提要，供下一段衔接
  error         TEXT,
  request_id    TEXT,
  owner_id      TEXT,
  heartbeat_ms  INTEGER,
  prose_style   TEXT,   -- 写这一段时用的详略（brief=简洁 | 其它/NULL=正常），便于回看
  created_at    TEXT NOT NULL,
  updated_at    TEXT NOT NULL
);

-- 角色个人状态（会随经历变化的那一层）。原始人设与稳定目标仍在 character 表，
-- 这张表只放角色本人写下的短期内容：当前在意的事与打算、对处境的理解、
-- 试过的结果、还没做完的事。一行一个角色，空串表示这一项还没写下。
-- 只进本人的决策/结算输入，不进叙述与阅读页；技术失败整步回滚时不写入。
CREATE TABLE IF NOT EXISTS character_note (
  actor_id     TEXT PRIMARY KEY,
  focus        TEXT NOT NULL DEFAULT '',
  situation    TEXT NOT NULL DEFAULT '',
  lessons      TEXT NOT NULL DEFAULT '',
  pending      TEXT NOT NULL DEFAULT '',
  updated_tick INTEGER NOT NULL DEFAULT 0,
  updated_at   TEXT NOT NULL
);

-- 世界回合（剧情体验改造）：每刻一条短局面记录。
-- 它只服务两件事：给叙述安排篇幅轻重、给自动外界变化留下来源。
-- 它**不进角色决策输入**，也不是世界事实——开场 IF 里的传言不因为没有记录在这里
-- 就变成事实。只有新运行包（场景快照里显式打开 story_loop）才会写下这张表；
-- 旧存档没有这张表时读路径按「还没有局面记录」处理，不报错。
CREATE TABLE IF NOT EXISTS story_turn (
  tick              INTEGER PRIMARY KEY,
  open_questions    TEXT NOT NULL DEFAULT '',   -- 本刻还没有解决的问题（一句话）
  focus_actors      TEXT NOT NULL DEFAULT '[]', -- JSON: [actor_id]，只给叙述排轻重
  focus_locations   TEXT NOT NULL DEFAULT '[]', -- JSON: [location_id]
  event_scope       TEXT,                       -- 非空表示这刻落了一件自动外界变化
  event_description TEXT,
  event_basis       TEXT,
  auto_event_id     INTEGER,                    -- 对应的 external_event.event_id（已消费）
  source            TEXT NOT NULL DEFAULT '',
  created_at        TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_prose_status   ON prose_segment(status, tick);
CREATE INDEX IF NOT EXISTS idx_event_tick     ON event(tick);
CREATE INDEX IF NOT EXISTS idx_obs_owner_tick ON observation(owner_id, obs_id);
CREATE INDEX IF NOT EXISTS idx_ext_status     ON external_event(status, event_id);
-- step_request 的租赁索引依赖迁移补上的 owner_id/heartbeat_ms 两列，
-- 旧库必须先补列再建索引，因此这一条由 src/db.py::_migrate 负责创建。
