"""Lossless prompt layout, using only the caller's already-filtered data.

Stable facts come before live state. No world lookup, cross-role memory or
reasoning content is added here. Arrays of settlement requests merge by index;
all other arrays remain intact in one section.
"""
from __future__ import annotations

import copy
import json

STATIC_ENTITY = {"id", "name", "description", "public_description", "goals", "pronouns",
                 "voice", "dialogue_examples", "relationships", "expression_note"}
STATIC_SELF = STATIC_ENTITY | {"state_note", "situational_cues", "situational_cues_note", "profile_note"}


def _stable(path):
    # Descend through an editor's allowed projection or a settlement context.
    while path and path[0] in ("allowed", "context"):
        path = path[1:]
    if not path:
        return False
    if path[0] in ("world", "public_background", "cast", "rule", "output_schema", "narration", "director_profiles"):
        return True
    if path[0] == "self" and len(path) >= 2:
        return path[1] in STATIC_SELF
    if path[0] in ("characters", "locations", "resources") and len(path) >= 3:
        return path[2] in STATIC_ENTITY | ({"connections"} if path[0] == "locations" else set())
    if path[0] == "chapter_budget" and len(path) >= 2:
        return path[1] in ("max_scenes", "max_rounds_per_scene", "stage_goal")
    if path[0] == "world_constraints" and len(path) >= 2:
        return path[1] == "rules" or _stable(path[1:])
    return False


def split_payload(payload, path=()):
    """Return disjoint fixed/current trees. Neither the values nor input mutate."""
    fixed, current = {}, {}
    for key, value in payload.items():
        child_path = path + (key,)
        if _stable(child_path):
            fixed[key] = copy.deepcopy(value)
        elif key == "requests" and not path and isinstance(value, list) and all(isinstance(v, dict) for v in value):
            pairs = [split_payload(v) for v in value]
            fixed[key] = [a for a, _ in pairs]
            current[key] = [b for _, b in pairs]
        elif isinstance(value, dict) and value:
            a, b = split_payload(value, child_path)
            if a:
                fixed[key] = a
            if b:
                current[key] = b
        else:
            current[key] = copy.deepcopy(value)
    return fixed, current


def merge_payload(fixed, current):
    """Reference semantics for the prompt; used to verify exact round trips."""
    out = copy.deepcopy(fixed)
    for key, value in current.items():
        if key in out and isinstance(out[key], dict) and isinstance(value, dict):
            out[key] = merge_payload(out[key], value)
        elif key == "requests" and key in out and isinstance(value, list):
            out[key] = [merge_payload(a, b) for a, b in zip(out[key], value)]
        else:
            out[key] = copy.deepcopy(value)
    return out


def render_payload(payload):
    fixed, current = split_payload(payload)
    priority = {"world_constraints": 0, "rules": 1, "world": 1, "public_background": 2,
                "locations": 3, "resources": 4, "characters": 5, "cast": 5,
                "self": 6, "context": 7}
    def ordered(value, *, current_root=False, event_ids=False):
        if isinstance(value, dict):
            # Settled history is chronological and only appends until its existing
            # window fills. Put it before changing positions, budgets and plans,
            # so those fields do not invalidate the reusable history prefix.
            live_priority = {"recent_settled": -3, "source_event_index": -2,
                             "character_knowledge": -1} if current_root else {}
            def order_key(key):
                if event_ids:
                    return (0, int(key)) if str(key).isdecimal() else (1, str(key))
                return (live_priority.get(key, priority.get(key, 10)), key)
            return {key: ordered(value[key], event_ids=key == "source_event_index")
                    for key in sorted(value, key=order_key)}
        if isinstance(value, list):
            return [ordered(item) for item in value]
        return value
    dump = lambda value, **kwargs: json.dumps(ordered(value, **kwargs), ensure_ascii=False, separators=(",", ":"))
    return ("输入资料分为 fixed 固定资料与 current 当前资料（json），合起来是同一份输入。"
            "同名对象字段递归合并，requests 数组按相同下标合并对象；其他数组原样使用。"
            "固定资料只指设定与规则；当前位置、状态、消息和已经发生的事以当前资料为准。\n"
            '{"fixed":' + dump(fixed) + ',"current":' + dump(current, current_root=True) + '}')
