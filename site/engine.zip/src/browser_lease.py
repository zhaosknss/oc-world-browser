"""Single-worker leases without native threads. Desktop leases are untouched."""
from __future__ import annotations

from . import db
from .lease import DEFAULT_HEARTBEAT_MS, DEFAULT_LEASE_MS
from .models import LeaseLost


class BrowserLease:
    active: list["BrowserLease"] = []

    def __init__(self, db_path, request_id, owner_id,
                 interval_ms=DEFAULT_HEARTBEAT_MS, lease_ms=DEFAULT_LEASE_MS,
                 table="step_request"):
        if table not in ("step_request", "chapter_request"):
            raise ValueError("unsupported lease table")
        self.db_path, self.request_id, self.owner_id = db_path, request_id, owner_id
        self.table = table
        self.interval_ms, self.lease_ms = interval_ms, lease_ms
        self.closed = False
        self.dead_reason = None
        self.beats = 0

    def start(self):
        if self not in self.active:
            self.active.append(self)
        self.refresh()

    def refresh(self):
        if self.closed:
            return True
        conn = db.connect(self.db_path)
        try:
            changed = conn.execute(
                f"UPDATE {self.table} SET heartbeat_ms=? WHERE request_id=? "
                "AND owner_id=? AND status='in_progress'",
                (db.now_ms(), self.request_id, self.owner_id)).rowcount
        finally:
            conn.close()
        if changed != 1:
            self.dead_reason = "浏览器生成请求已不属于本次操作，迟到结果不会保存"
            raise LeaseLost(self.dead_reason)
        self.beats += 1
        return True

    def raise_if_dead(self):
        if self.dead_reason:
            raise LeaseLost(self.dead_reason)
        if not self.closed:
            self.refresh()

    def stop(self):
        self.closed = True
        if self in self.active:
            self.active.remove(self)

    def diagnostics(self):
        return {"request_id": self.request_id, "owner_id": self.owner_id,
                "beats": self.beats, "dead": bool(self.dead_reason),
                "dead_reason": self.dead_reason, "lease_ms": self.lease_ms}


def refresh_active():
    # The dedicated Worker processes one dispatch at a time. Refresh on both
    # sides of a blocking model request instead of creating unavailable threads.
    for lease in list(BrowserLease.active):
        lease.raise_if_dead()


def close_active():
    for lease in list(BrowserLease.active):
        lease.stop()
