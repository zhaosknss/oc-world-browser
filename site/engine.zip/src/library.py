"""One local library: reusable world snapshots and independently bound story archives."""
from __future__ import annotations

import base64
import binascii
import copy
from contextlib import contextmanager
import io
import json
import os
import re
import sqlite3
import threading
import uuid
import zipfile
from pathlib import Path, PurePosixPath
from urllib.parse import quote

from . import db, scenario as scenario_mod
from .engine import Runner
from .models import EngineError, StepBusy
from .provider import build_provider

ROOT = Path(__file__).resolve().parent.parent
BUILTIN_ID = "boonie-early-story"
BUILTIN_PACK = ROOT / "scenarios" / "boonie-early-story.json"
LEGACY = (
    ("原始试跑", "local-data/deepseek-live/smoke-20260916-224238/world.db"),
    ("熊出没旧故事", "local-data/boonie-demo/archives/boonie-demo/world.db"),
    ("熊出没另一份旧故事", "local-data/boonie-demo/archives/boonie-demo-2/world.db"),
    ("熊出没新版试读", "local-data/boonie-demo/archives/boonie-story/world.db"),
    ("模拟阅读记录", "local-data/reading-observer/reader-20260920/world.db"),
)
MAX_UPLOAD = 1024 * 1024
MAX_TEXT = 48 * 1024
MAX_FILES = 24
FORBIDDEN = {"provider_script", "complex_rules", "world_script", "chapter_script", "fake_overlay"}
ID_PATTERN = re.compile(r"^[a-zA-Z0-9_-]{1,80}$")


class LibraryError(EngineError):
    pass


def _json(value):
    return json.dumps(value, ensure_ascii=False)


@contextmanager
def _readonly(path: Path):
    conn = sqlite3.connect("file:" + quote(str(path).replace("\\", "/"), safe="/:") + "?mode=ro", uri=True)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
    finally:
        conn.close()


def _archive_info(path: Path):
    try:
        with _readonly(path) as conn:
            scenario = json.loads(conn.execute("SELECT value FROM meta WHERE key='scenario_json'").fetchone()[0])
            run = conn.execute("SELECT * FROM run WHERE run_id=1").fetchone()
            if run is None:
                return None
            return {"scenario": scenario, "tick": run["tick"], "status": run["status"],
                    "mode": run["provider_mode"],
                    "if_condition": (run["if_condition"] or "") if "if_condition" in run.keys() else ""}
    except (sqlite3.Error, ValueError, TypeError, AttributeError):
        return None


def validate_pack(value: dict) -> dict:
    """Validate the fields bootstrap and the current prompts actually consume."""
    if not isinstance(value, dict):
        raise LibraryError("世界包必须是 JSON 对象")
    if FORBIDDEN.intersection(value):
        raise LibraryError("正式世界包不能包含预写行动或模拟结算脚本")
    for field in ("scenario_id", "title", "summary"):
        if not isinstance(value.get(field), str) or not value[field].strip():
            raise LibraryError(f"世界包缺少 {field}")
    if not isinstance(value.get("version"), (str, int)):
        raise LibraryError("世界包需要 version")
    world = value.get("world")
    if not isinstance(world, dict) or not isinstance(world.get("description"), str):
        raise LibraryError("world.description 需要文字")
    if "public_description" in world and not isinstance(world["public_description"], str):
        raise LibraryError("world.public_description 需要文字")
    places, people = value.get("locations"), value.get("characters")
    if not isinstance(places, list) or not 1 <= len(places) <= 16:
        raise LibraryError("地点需为 1–16 个")
    if not isinstance(people, list) or not 1 <= len(people) <= 12:
        raise LibraryError("人物需为 1–12 个")
    if not isinstance(value.get("sources", []), list):
        raise LibraryError("sources 必须是数组")
    if len(_json(value).encode("utf-8")) > 240000:
        raise LibraryError("世界包超过 240 KB，请精简后重试")
    for kind, items in (("地点", places), ("人物", people)):
        ids = []
        for item in items:
            if not isinstance(item, dict) or not isinstance(item.get("id"), str) or not ID_PATTERN.fullmatch(item["id"]):
                raise LibraryError(f"{kind}需要字母/数字/短横线组成的 id")
            if not isinstance(item.get("name"), str) or not item["name"].strip():
                raise LibraryError(f"{kind} {item['id']} 缺少名称")
            if not isinstance(item.get("description"), str):
                raise LibraryError(f"{kind} {item['id']} 缺少 description")
            for optional in ("public_description", "pronouns"):
                if optional in item and not isinstance(item[optional], str):
                    raise LibraryError(f"{kind} {item['id']} 的 {optional} 必须是文字")
            ids.append(item["id"])
        if len(ids) != len(set(ids)):
            raise LibraryError(f"{kind} id 重复")
    for loc in places:
        if not isinstance(loc.get("connections", []), list):
            raise LibraryError(f"地点 {loc['id']} 的 connections 必须是数组")
        for field in ("moment", "state_description"):
            if field in loc and not isinstance(loc[field], str):
                raise LibraryError(f"地点 {loc['id']} 的 {field} 必须是文字")
    for ch in people:
        goals = ch.get("goals", [])
        if not isinstance(goals, list) or any(not isinstance(goal, str) for goal in goals):
            raise LibraryError(f"人物 {ch['id']} 的 goals 必须是文字数组")
        if not isinstance(ch.get("location_id"), str):
            raise LibraryError(f"人物 {ch['id']} 缺少初始地点")
        for field in ("current_tendency", "change_reason", "status_text"):
            if field in ch and not isinstance(ch[field], str):
                raise LibraryError(f"人物 {ch['id']} 的 {field} 必须是文字")
    for res in value.get("resources", []):
        if not isinstance(res, dict) or not isinstance(res.get("id"), str) or not ID_PATTERN.fullmatch(res["id"]):
            raise LibraryError("物品需要字母/数字/短横线组成的 id")
        for field in ("name", "description"):
            if field in res and not isinstance(res[field], str):
                raise LibraryError(f"物品 {res['id']} 的 {field} 必须是文字")
    for link in value.get("sources", []):
        if not isinstance(link, dict) or any(not isinstance(link.get(key), str) for key in ("field", "doc", "note")):
            raise LibraryError("sources 条目需要 field、doc、note 文字")
    try:
        scenario_mod.validate_scenario(value)
    except (scenario_mod.ScenarioError, KeyError, TypeError, ValueError) as exc:
        raise LibraryError(f"世界包结构不合引擎要求：{exc}") from exc
    return value


def apply_world_edits(base: dict, edits: dict) -> dict:
    if not isinstance(edits, dict):
        raise LibraryError("修改内容必须是对象")
    scenario = copy.deepcopy(base)
    changed = []
    for key in ("title", "summary"):
        if key in edits:
            value = str(edits[key]).strip()
            if value != scenario.get(key):
                scenario[key] = value
                changed.append(key)
    if "world_description" in edits:
        value = str(edits["world_description"]).strip()
        if value != scenario["world"].get("description"):
            scenario["world"]["description"] = value
            changed.append("world.description")
    for kind in ("characters", "locations"):
        values = edits.get(kind)
        if values is None:
            continue
        if not isinstance(values, dict):
            raise LibraryError(f"{kind} 修改需按 id 给出")
        by_id = {item["id"]: item for item in scenario[kind]}
        for item_id, description in values.items():
            if item_id not in by_id:
                raise LibraryError(f"未知 {kind} id：{item_id}")
            value = str(description).strip()
            if value != by_id[item_id].get("description"):
                by_id[item_id]["description"] = value
                changed.append(f"{kind}.{item_id}.description")
    if changed:
        scenario.setdefault("sources", [])
        for field in changed:
            scenario["sources"].append({"field": field, "doc": "用户编辑",
                                        "note": "用户核对后修改，覆盖此前整理值"})
    return validate_pack(scenario)


def _decode_text(raw: bytes) -> tuple[str, str]:
    for encoding in ("utf-8-sig", "gb18030"):
        try:
            return raw.decode(encoding), encoding
        except UnicodeDecodeError:
            pass
    raise LibraryError("资料不是可读取的 UTF-8 或 GB18030 文本")


def read_upload(filename: str, data_b64: str) -> tuple[list[dict], list[str]]:
    if not isinstance(filename, str) or not filename or not isinstance(data_b64, str):
        raise LibraryError("请选择 TXT、Markdown、JSON 或 ZIP 文件")
    try:
        raw = base64.b64decode(data_b64, validate=True)
    except (binascii.Error, ValueError, TypeError) as exc:
        raise LibraryError("上传编码无效") from exc
    if len(raw) > MAX_UPLOAD:
        raise LibraryError("上传文件超过 1 MB；请拆成较小资料包")
    docs, skipped = [], []
    def add(name: str, content: bytes):
        suffix = Path(name).suffix.lower()
        if suffix not in (".txt", ".md", ".markdown", ".json"):
            skipped.append(name)
            return
        if len(content) > MAX_TEXT:
            raise LibraryError(f"{name} 超过 48 KB；本轮不截断，请拆分资料")
        text, encoding = _decode_text(content)
        docs.append({"name": name, "text": text, "encoding": encoding, "kind": suffix})
    if filename.lower().endswith(".zip"):
        try:
            with zipfile.ZipFile(io.BytesIO(raw)) as archive:
                members = archive.infolist()
                if len(members) > MAX_FILES:
                    raise LibraryError("ZIP 最多 24 项，请拆分")
                total = 0
                seen_names = set()
                for member in members:
                    name = member.filename.replace("\\", "/")
                    parts = PurePosixPath(name).parts
                    if name.startswith("/") or ".." in parts or ":" in name or member.flag_bits & 0x1:
                        raise LibraryError("ZIP 含越界路径或加密文件")
                    if member.is_dir():
                        continue
                    if name in seen_names:
                        raise LibraryError(f"ZIP 中有重名文件：{name}")
                    seen_names.add(name)
                    if Path(name).suffix.lower() not in (".txt", ".md", ".markdown", ".json"):
                        skipped.append(name)
                        continue
                    if member.file_size > MAX_TEXT:
                        raise LibraryError(f"{name} 超过 48 KB；本轮不截断")
                    total += member.file_size
                    if total > MAX_TEXT:
                        raise LibraryError("ZIP 文本总量超过 48 KB；请拆分资料")
                    add(name, archive.read(member))
        except (zipfile.BadZipFile, RuntimeError) as exc:
            raise LibraryError(f"ZIP 无法读取：{exc}") from exc
    else:
        add(Path(filename).name, raw)
    if not docs:
        raise LibraryError("没有找到支持的 TXT、Markdown 或 JSON 资料")
    if sum(len(item["text"].encode("utf-8")) for item in docs) > MAX_TEXT:
        raise LibraryError("文字总量超过 48 KB；请拆分资料，本轮不截断")
    return docs, skipped


ORGANIZE_SYSTEM = """你整理用户提供的虚构世界资料，输出可运行的文字世界配置。只输出一个 JSON 对象，格式为 {"scenario": {...}, "evidence": {"confirmed": [], "unknown": [], "conflicts": [], "defaults": []}}。scenario 必须含 scenario_id（简短英文 id）、version=1、title、summary、world:{description,initial_moment}、locations:[{id,name,description,connections,moment,state_description}]、characters:[{id,name,description,goals,current_tendency,change_reason,location_id,status_text}]、resources:[{id,name,description,location_id 或 holder_id,unique_item}]、sources:[{field,doc,note}]。只登记资料中确有的关键物品；没有则 resources 为空。每个资源必须恰好有所在地点或持有者。至少一处地点、一位人物。不要写预设行动、固定剧情或推测为事实。资料没给地图连通、初始位置等运行必需项时，可补保守默认值，并逐项写在 evidence.defaults；资料矛盾或缺失时写在 conflicts/unknown。sources 的 doc 对应输入文件名，世界、人物、地点和物品尽量分别关联来源；运行默认项写入 evidence.defaults，不能伪造原文。人物有独立目标与办法，但不预写本次 IF 的反应。"""


ORGANIZE_SYSTEM += """ 新章节引擎区分后台设定与对外介绍：world.public_description 只放共同背景，
幕后规则或秘密保留在 world.description／hidden_facts，不能写进 public_description。
人物与地点添加 public_description，只写读者可以先知道的简短介绍，不揭露私密目标、计划、
身份或隐藏线索；人物完整 description、goals 和 situational_cues 保留给本人及导演。
没有明确公开介绍时 public_description 可为空。不得凭空补秘密或把未知项当隐藏真相。"""


class Library:
    def __init__(self, data_root: str | Path, provider_name: str = "deepseek", provider_options: dict | None = None,
                 project_root: str | Path = ROOT):
        self.root = Path(project_root).resolve()
        self.data_root = Path(data_root).resolve()
        self.stories_dir = self.data_root / "stories"
        self.legacy_copies_dir = self.data_root / "legacy-copies"
        self.data_root.mkdir(parents=True, exist_ok=True)
        self.stories_dir.mkdir(parents=True, exist_ok=True)
        self.legacy_copies_dir.mkdir(parents=True, exist_ok=True)
        self.catalog_path = self.data_root / "catalog.db"
        self.provider_name = provider_name
        self.provider_options = provider_options or {}
        self.lock = threading.RLock()
        self.active: set[str] = set()
        self.runtimes: dict[str, object] = {}
        self.drafts: dict[str, dict] = {}
        self.builtin = validate_pack(scenario_mod.load_scenario(str(BUILTIN_PACK)))
        self.import_provider = build_provider(provider_name, self.builtin, None, self.provider_options)
        self._init_catalog()
        self._seed_legacy()

    @contextmanager
    def _conn(self):
        conn = sqlite3.connect(self.catalog_path, timeout=5)
        conn.row_factory = sqlite3.Row
        try:
            yield conn
            conn.commit()
        except BaseException:
            conn.rollback()
            raise
        finally:
            conn.close()

    def _init_catalog(self):
        with self._conn() as conn:
            conn.executescript("""
                CREATE TABLE IF NOT EXISTS worlds(id TEXT PRIMARY KEY, title TEXT NOT NULL,
                  scenario_json TEXT NOT NULL, materials_json TEXT NOT NULL, evidence_json TEXT NOT NULL,
                  created_at TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS stories(id TEXT PRIMARY KEY, world_id TEXT,
                  title TEXT NOT NULL, db_path TEXT NOT NULL UNIQUE, created_at TEXT NOT NULL,
                  removed_at TEXT, legacy INTEGER NOT NULL DEFAULT 0, working_path TEXT);
            """)
            columns = {row[1] for row in conn.execute("PRAGMA table_info(stories)")}
            if "working_path" not in columns:
                conn.execute("ALTER TABLE stories ADD COLUMN working_path TEXT")

    def _seed_legacy(self):
        with self.lock, self._conn() as conn:
            for label, relative in LEGACY:
                path = (self.root / relative).resolve()
                if not path.is_file() or not _archive_info(path):
                    continue
                sid = "legacy-" + uuid.uuid5(uuid.NAMESPACE_URL, relative).hex[:16]
                conn.execute("INSERT OR IGNORE INTO stories(id,world_id,title,db_path,created_at,legacy) "
                             "VALUES(?,?,?,?,?,1)", (sid, None, label, str(path), db.now()))

    def _story_row(self, story_id: str, include_removed=False):
        if not ID_PATTERN.fullmatch(str(story_id)):
            raise LibraryError("故事 ID 不合法")
        with self._conn() as conn:
            row = conn.execute("SELECT * FROM stories WHERE id=?", (story_id,)).fetchone()
        if row is None or (row["removed_at"] and not include_removed):
            raise LibraryError("故事不存在或已移入最近移除")
        return row

    def _path(self, row):
        path = Path(row["working_path"] or row["db_path"]).resolve()
        legacy_paths = {(self.root / relative).resolve() for _, relative in LEGACY}
        if path not in legacy_paths and self.stories_dir not in path.parents and self.legacy_copies_dir not in path.parents:
            raise LibraryError("故事存档路径不在允许目录")
        if not path.is_file():
            raise LibraryError("故事存档文件不存在")
        return path

    def list_stories(self):
        with self._conn() as conn:
            rows = conn.execute("SELECT * FROM stories ORDER BY created_at DESC,id DESC").fetchall()
        with self.lock:
            active_ids = set(self.active)
        out = []
        for row in rows:
            try:
                info = _archive_info(self._path(row))
            except LibraryError:
                info = None
            out.append({"id": row["id"], "world_id": row["world_id"], "title": row["title"],
                        "legacy": bool(row["legacy"]), "working_copy": bool(row["working_path"]),
                        "removed": bool(row["removed_at"]),
                        "created_at": row["created_at"], "available": bool(info),
                        "world_title": (info or {}).get("scenario", {}).get("title", "存档不可读"),
                        "tick": (info or {}).get("tick", 0), "status": (info or {}).get("status", "unavailable"),
                        "in_progress": row["id"] in active_ids,
                        "mode": (info or {}).get("mode", ""),
                        "if_condition": (info or {}).get("if_condition", "")})
        return out

    def list_worlds(self):
        with self._conn() as conn:
            rows = conn.execute("SELECT id,title,scenario_json,created_at FROM worlds ORDER BY created_at DESC").fetchall()
        return [{"id": BUILTIN_ID, "title": self.builtin["title"], "summary": self.builtin["summary"],
                 "kind": "preset", "characters": [ch["name"] for ch in self.builtin["characters"]]}] + [
                 {"id": row["id"], "title": row["title"], "summary": json.loads(row["scenario_json"]).get("summary", ""),
                  "kind": "import", "characters": [ch["name"] for ch in json.loads(row["scenario_json"])["characters"]]}
                 for row in rows]

    def world_detail(self, world_id: str):
        if world_id == BUILTIN_ID:
            return {"id": BUILTIN_ID, "editable": False, "scenario": copy.deepcopy(self.builtin)}
        with self._conn() as conn:
            row = conn.execute("SELECT scenario_json,evidence_json FROM worlds WHERE id=?", (world_id,)).fetchone()
        if row is None:
            raise LibraryError("世界不存在")
        return {"id": world_id, "editable": True,
                "scenario": json.loads(row["scenario_json"]),
                "evidence": json.loads(row["evidence_json"])}

    def update_world(self, world_id: str, expected_version, edits: dict):
        if world_id == BUILTIN_ID:
            raise LibraryError("内置预设不在这里修改；可导入自己的世界包")
        with self.lock, self._conn() as conn:
            row = conn.execute("SELECT scenario_json FROM worlds WHERE id=?", (world_id,)).fetchone()
            if row is None:
                raise LibraryError("世界不存在")
            old = json.loads(row["scenario_json"])
            if str(old["version"]) != str(expected_version):
                raise LibraryError("世界已被其他页面修改，请刷新后再编辑")
            scenario = apply_world_edits(old, edits)
            version = old["version"]
            scenario["version"] = version + 1 if isinstance(version, int) else str(version) + "-edit-" + uuid.uuid4().hex[:6]
            conn.execute("UPDATE worlds SET title=?,scenario_json=? WHERE id=?",
                         (scenario["title"], _json(scenario), world_id))
        return {"world_id": world_id, "title": scenario["title"], "version": scenario["version"]}

    def create_story(self, world_id: str, title: str):
        title = str(title or "").strip()
        if not 1 <= len(title) <= 80:
            raise LibraryError("故事名称需为 1–80 字")
        if world_id == BUILTIN_ID:
            scenario = copy.deepcopy(self.builtin)
        else:
            with self._conn() as conn:
                row = conn.execute("SELECT scenario_json FROM worlds WHERE id=?", (world_id,)).fetchone()
            if row is None:
                raise LibraryError("世界不存在")
            scenario = json.loads(row["scenario_json"])
        scenario["provider_mode"] = self.provider_name
        sid = uuid.uuid4().hex
        path = self.stories_dir / sid / "world.db"
        scenario_mod.bootstrap(str(path), scenario)
        with self.lock, self._conn() as conn:
            conn.execute("INSERT INTO stories(id,world_id,title,db_path,created_at) VALUES(?,?,?,?,?)",
                         (sid, world_id, title, str(path), db.now()))
        return {"id": sid, "title": title, "world_id": world_id}

    def rename(self, story_id: str, title: str):
        title = str(title or "").strip()
        if not 1 <= len(title) <= 80:
            raise LibraryError("故事名称需为 1–80 字")
        with self.lock:
            self._story_row(story_id)
            with self._conn() as conn:
                conn.execute("UPDATE stories SET title=? WHERE id=?", (title, story_id))
        return {"id": story_id, "title": title}

    def remove(self, story_id: str):
        with self.lock:
            row = self._story_row(story_id)
            if story_id in self.active:
                raise StepBusy("这份故事正在处理请求；等本步结束后再移除")
            with self._conn() as conn:
                conn.execute("UPDATE stories SET removed_at=? WHERE id=?", (db.now(), story_id))
            return {"id": story_id, "title": row["title"], "removed": True}

    def restore(self, story_id: str):
        with self.lock:
            self._story_row(story_id, include_removed=True)
            with self._conn() as conn:
                conn.execute("UPDATE stories SET removed_at=NULL WHERE id=?", (story_id,))
        return {"id": story_id, "removed": False}

    def _legacy_working_copy(self, row):
        """First open makes a managed copy; original archive stays byte-for-byte untouched."""
        source = self._path(row)
        target = self.legacy_copies_dir / row["id"] / "world.db"
        target.parent.mkdir(parents=True, exist_ok=True)
        if not target.exists():
            with _readonly(source) as source_conn:
                target_conn = sqlite3.connect(target)
                try:
                    source_conn.backup(target_conn)
                finally:
                    target_conn.close()
        if not _archive_info(target):
            raise LibraryError("旧档工作副本未能完成；原档未改变")
        with self._conn() as conn:
            conn.execute("UPDATE stories SET working_path=? WHERE id=? AND working_path IS NULL",
                         (str(target), row["id"]))
        return target

    def story_title(self, story_id: str) -> str:
        return self._story_row(story_id)["title"]

    def open_story(self, story_id: str):
        with self.lock:
            row = self._story_row(story_id)
            path = self._legacy_working_copy(row) if row["legacy"] and not row["working_path"] else self._path(row)
            if story_id not in self.runtimes:
                info = _archive_info(path)
                if not info:
                    raise LibraryError("故事存档无法读取")
                mode = info["mode"] if row["legacy"] else self.provider_name
                if mode not in ("fake", "deepseek"):
                    mode = self.provider_name
                # Only the managed story or legacy working copy is migrated.
                scenario_mod.bootstrap(str(path), info["scenario"])
                from .chapter_store import enable
                enable(str(path))
                provider = build_provider(mode, info["scenario"], None, self.provider_options)
                runner = Runner(str(path), provider)
                runner.reset_stale_on_start()
                self.runtimes[story_id] = type("StoryRuntime", (), {"db_path": str(path),
                    "provider": provider, "runner": runner})()
            return self.runtimes[story_id]

    def begin_story(self, story_id: str):
        with self.lock:
            runtime = self.open_story(story_id)
            if story_id in self.active:
                raise StepBusy("这份故事正在处理另一项操作；请等它完成")
            self.active.add(story_id)
            return runtime

    def end_story(self, story_id: str):
        with self.lock:
            self.active.discard(story_id)

    def active_state(self):
        return {"requests": [{"request_id": sid, "status": "in_progress", "lease_alive": True}
                             for sid in sorted(self.active)]}

    def analyze(self, filename: str, data_b64: str):
        docs, skipped = read_upload(filename, data_b64)
        json_docs = [item for item in docs if item["kind"] == ".json"]
        if json_docs:
            if len(json_docs) != 1:
                raise LibraryError("ZIP 中有多份 JSON 世界包；请只保留一份")
            try:
                scenario = json.loads(json_docs[0]["text"])
            except json.JSONDecodeError as exc:
                raise LibraryError(f"JSON 世界包解析失败：{exc}") from exc
            validate_pack(scenario)
            evidence = {"confirmed": ["结构化世界包已通过引擎字段校验；内容真实性尚未核实。"],
                        "unknown": ["未自动核实人物资料与世界规则来源。"], "conflicts": [], "defaults": []}
            method = "structured"
            accounting = None
        else:
            if self.provider_name != "deepseek":
                raise LibraryError("自由文档整理需要真实 DeepSeek 提供方；模拟模式只支持结构化 JSON 世界包")
            payload = [{"file": item["name"], "text": item["text"]} for item in docs]
            request = {"system": ORGANIZE_SYSTEM,
                       "user": "请依据以下资料整理世界。JSON 中的 file 是来源名，text 是内容：\n" + _json(payload)}
            # A fresh adapter keeps accounting isolated between concurrent imports
            # and failed previews; it still reads the same local configuration.
            organizer = build_provider(self.provider_name, self.builtin, None, self.provider_options)
            raw = organizer.organize_world(request)
            scenario = raw.get("scenario", raw) if isinstance(raw, dict) else raw
            evidence = raw.get("evidence", {}) if isinstance(raw, dict) else {}
            if not isinstance(evidence, dict):
                evidence = {}
            if not isinstance(scenario, dict):
                raise LibraryError("模型没有返回世界对象；资料仍在本次页面，可重试")
            scenario = copy.deepcopy(scenario)
            scenario["scenario_id"] = "import-" + uuid.uuid4().hex[:12]
            scenario["version"] = 1
            scenario["story_loop"] = {"enabled": True}
            scenario.setdefault("resources", [])
            scenario.setdefault("sources", [])
            validate_pack(scenario)
            source_names = {item["name"] for item in docs}
            if not scenario["sources"]:
                raise LibraryError("整理结果缺少资料来源关联；未保存世界，可重试")
            for link in scenario["sources"]:
                if not isinstance(link, dict) or not link.get("field") or link.get("doc") not in source_names:
                    raise LibraryError("整理结果中的来源文件不在本次资料里；未保存世界，可重试")
            for name in ("confirmed", "unknown", "conflicts", "defaults"):
                if not isinstance(evidence.get(name), list):
                    evidence[name] = []
            method = "deepseek"
            accounting = organizer.take_stats()
        draft_id = uuid.uuid4().hex
        draft = {"scenario": scenario, "materials": docs, "evidence": evidence,
                 "skipped": skipped, "method": method}
        with self.lock:
            self.drafts[draft_id] = draft
        return {"draft_id": draft_id, "scenario": scenario, "evidence": evidence,
                "files": [{"name": item["name"], "encoding": item["encoding"]} for item in docs],
                "skipped": skipped, "method": method, "accounting": accounting}

    def save_draft(self, draft_id: str, edits: dict):
        with self.lock:
            draft = self.drafts.get(str(draft_id))
        if draft is None:
            raise LibraryError("预览已失效；请重新选择资料并分析")
        scenario = apply_world_edits(draft["scenario"], edits)
        world_id = uuid.uuid4().hex
        with self.lock, self._conn() as conn:
            conn.execute("INSERT INTO worlds(id,title,scenario_json,materials_json,evidence_json,created_at) "
                         "VALUES(?,?,?,?,?,?)", (world_id, scenario["title"], _json(scenario),
                         _json({"files": draft["materials"], "skipped": draft["skipped"], "method": draft["method"]}),
                         _json(draft["evidence"]), db.now()))
            self.drafts.pop(str(draft_id), None)
        return {"world_id": world_id, "title": scenario["title"]}
