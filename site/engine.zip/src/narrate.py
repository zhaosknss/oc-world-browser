"""小说叙述层：把已结算事件改写成可以连续读下去的正文。

职责边界（写法自写，模块边界参考了同类实现的思路，没有复制任何外部代码）：

- 输入：某一刻的已结算事件 + 必要世界设定 + 上一段正文尾段与本段事实提要；
- 输出：一段面向读者的正文。它**不参与角色决策**，也不改动世界状态；
- 正文与它来源的事件范围一起写进 `prose_segment`：刷新、重开都能接着读；
  世界已经推进、正文没生成出来时，只补这一段正文，不重复推进。

两件必须守住的事：

1. 失败的行动不能被写成成功，也不能替世界新增事实里没有的决定性结果——所以
   事实日志里保留了「这次没有成功，原因：…」，提示词里把它写成硬性约束。
2. 面向读者的正文与角色决策输入分开：叙述提示词只拿得到公开设定和 POV 本人
   的信息，其它角色的私有目标不进这里；而角色决策仍然只走 observation 那份
   受限上下文（见 src/context.py），读者知道什么不会自动变成角色知道什么。

另外（剧情体验改造）：本刻的世界回合局面（`focus`，见 src/story.py）一并给旁白，
但只用来安排篇幅轻重——哪些行动真正改变了局面就多写，次要的等待与移动一句带过。
局面里的可能性、计划与还没生效的变化**不是事实**，一个字都不许写成已经发生；
焦点与 scene_log 对不上时，以 scene_log 为准。
"""
from __future__ import annotations

import json
import time

from . import db, scenario as scenario_mod, story as story_mod
from .engine import KIND_LABEL
from .models import (EngineError, ProviderError, ProviderSchemaError, scrub_secrets,
                     stage_label)

# 正在生成的段落超过这个时长没有心跳，就允许重新生成（进程被杀后不会永久卡住）。
GENERATING_STALE_MS = 120_000

# 文风与衔接属于「以后要换掉的世界材料」，所以放在场景 JSON 的 narration 段里，
# 这里只是缺省值（旧存档的场景快照里没有这一段，就按这里的默认值走）。
DEFAULT_NARRATION = {
    "pov": "auto",                 # auto = 本刻被提到最多的人；也可以写角色 id 固定视角
    "person": "第三人称限知",
    "tense": "过去时",
    "tone": "直观、清楚、顺畅，稍微有点场景感：写清谁做了什么、结果如何，"
            "用具体的动作、声音、光线和环境带出气氛；不堆比喻，不抒情",
    "paragraphs": "2 到 4 个自然段",
    "prev_tail_chars": 320,
    "digest_chars": 180,
    "extra_rules": [],
}

SYSTEM_TEMPLATE = """你要把一段已经结算的世界事实，写成小说里接着上一段往下读的正文。

读起来要直观、清楚、顺畅，有一点场景感就够了，不追求华丽：把谁做了什么、结果如何写明白，
用具体的动作和环境带出气氛。不要堆比喻，不要抒情，不要为了好看加戏。

只写正文本身：不要标题、不要小标题、不要列表、不要括号里的说明，也不要出现
「第几刻」「事件」「结算」「角色」「模型」这类技术词。不要向读者解释规则，不要写免责声明，
不要与读者对话，不要自称 AI。

怎么写：
1. 先把这一刻真正发生的事写清楚，先后顺序按给定顺序来，不打乱、不倒叙。
2. 行动和结果都要写出来；行动没有成立时，用一句话交代原因就够了，不要展开解释。
3. 只写事实里确实发生的事。没有出现的动作、人物和结论不要补出来。同一个细节不要写两遍。
4. 人物说的话只能引用事实里给出的原话；不要替人物编造新的关键决定或结论。
5. 环境、动作和语气可以补；人物心里怎么想只用动作和细节暗示，不要直接宣布。
6. 开头接着上一段的场面往下走，不要复述上一段已经写过的话。
7. 不要写「这说明」「也就是说」「在场的人」这类解释性或说明性的句子；因果交给动作本身，
   不要用「因为……所以……」的条款式写法，也不要照抄事实里的「原因：」字样。
8. 不要假定不同地点的人在同一处；谁在哪里以给定的事实为准。
9. 篇幅 {paragraphs}，不要分小节。按事件的多少写：事情少就写短，不要为了凑篇幅加描写。
10. 上一段正文只用来接语言和场面（措辞、语气、正在进行的事），不能覆盖这一段给定的事实：
    不要因为它写了什么就跟着写什么；接得上就行，不要新增行动、决定、物品转移或结果。
11. 如果输入里说明「当时的场面没有可靠记录」，就不要写人物当时在哪、环境当时是什么样，
    也不要用后来才知道的状态代替；把笔墨放在这一段时间里确实发生的事上。
{extra}
文风：{tone}。
{pov_line}"""

# 正文详略：正常沿用现有写法；简洁只压缩表达（省掉重复环境、无关动作与移动过程），
# 每个人物的行动、关键对白、结果与必要原因都要保留。
PROSE_STYLES = ("normal", "brief")
DEFAULT_PROSE_STYLE = "normal"
STYLE_LABELS = {"normal": "正常", "brief": "简洁"}
BRIEF_PARAGRAPHS = "1 到 2 个自然段，能一句写完就一句"
BRIEF_RULE = (
    "简洁模式：只写这一刻真正发生的行动、关键对白与结果（含必要原因），"
    "不复述已经写过的环境与场面，不铺陈气氛，不写与推进无关的动作和移动过程。"
    "每个人物的行动与关键对白一个都不能少，对白可以转述但意思不能改；"
    "也不要把两件事合成一件写。")

# 视角写法：默认跟一个人（第三人称限知）；narration.pov="scene" 时是全局观察，
# 在场每个人的行动都可以写，但不进入任何人的内心（展示用运行包走这一种）。
POV_LINE_FOLLOW = "视角：{person}，主要跟随「{pov_name}」能看到、听到和想到的范围；时态：{tense}。"
POV_LINE_SCENE = "视角：{person}；时态：{tense}。"

# 上面写死的规则条数：场景自己的额外规则接着往下编号（见 build_narration_system）。
BUILTIN_RULE_COUNT = 11


def _has_column(conn, table: str, column: str) -> bool:
    try:
        return any(row["name"] == column for row in conn.execute(f"PRAGMA table_info({table})"))
    except Exception:                                    # 表还不存在等情况
        return False


def prose_style(conn) -> str:
    """当前存档的正文详略：brief=简洁，其余（含 NULL/没有该列）＝正常。

    老接口不传值时就是「正常」，所以缺列或缺失值都不会改变已有行为。
    """
    if not _has_column(conn, "run", "prose_style"):
        return DEFAULT_PROSE_STYLE
    row = conn.execute("SELECT prose_style FROM run WHERE run_id=1").fetchone()
    value = (row["prose_style"] or "").strip().lower() if row is not None else ""
    return value if value in PROSE_STYLES else DEFAULT_PROSE_STYLE


def set_prose_style(db_path: str, style: str) -> dict:
    """写入本次故事的正文详略。只影响此后生成，不动已保存的段落，也不调用模型。"""
    value = (style or "").strip().lower()
    if value not in PROSE_STYLES:
        raise EngineError(f"正文详略只支持 {' / '.join(PROSE_STYLES)}，收到 {style!r}")
    conn = db.connect(db_path)
    try:
        row = conn.execute("SELECT status FROM run WHERE run_id=1").fetchone()
        if row is None:
            raise EngineError("数据库尚未初始化")
        # 老档第一次设置时补齐新增列（与启动时的迁移同一份逻辑，幂等）
        if not _has_column(conn, "run", "prose_style"):
            db.init_schema(conn)
        with db.write_txn(conn):
            conn.execute("UPDATE run SET prose_style=?, updated_at=? WHERE run_id=1",
                         (value, db.now()))
    finally:
        conn.close()
    return {"style": value, "label": STYLE_LABELS[value]}


def conventions_for(scenario: dict) -> list[str]:
    """本世界的用语约定（称呼等），来自运行包；熊出没演示另有按包 id 兜底的一份。

    兜底是为了让**用户当前那份存档**（快照里没有这段）继续生成时也能拿到同样的约束，
    不需要 reset，也不改库。
    """
    from . import demo as demo_mod
    return demo_mod.conventions_for(scenario)


def narration_config(scenario: dict, style: str = DEFAULT_PROSE_STYLE,
                     conventions: list[str] | None = None) -> dict:
    """取本场景的叙述设置：场景里写了就用场景的，没写就用默认值。

    style='brief' 时只调整**表达**（段落数与省去的铺陈），不动事实要求；
    conventions 是本世界的用语约定（例如称呼直接用名字），作为额外规则进提示词。
    """
    cfg = dict(DEFAULT_NARRATION)
    raw = scenario.get("narration") if isinstance(scenario, dict) else None
    if isinstance(raw, dict):
        for key, value in raw.items():
            if key == "extra_rules":
                if isinstance(value, list):
                    cfg["extra_rules"] = [str(item) for item in value if str(item).strip()]
            elif key in cfg and value not in (None, ""):
                cfg[key] = value
    rules = list(cfg.get("extra_rules") or [])
    used: list[str] = []
    for item in (conventions if conventions is not None else conventions_for(scenario)):
        text = str(item or "").strip()
        if text:
            used.append(text)
            if text not in rules:
                rules.append(text)
    if style == "brief":
        cfg["paragraphs"] = BRIEF_PARAGRAPHS
        rules.append(BRIEF_RULE)
    cfg["extra_rules"] = rules
    cfg["conventions"] = used
    cfg["prose_style"] = style if style in PROSE_STYLES else DEFAULT_PROSE_STYLE
    return cfg


def build_narration_system(cfg: dict, pov_name: str) -> str:
    # 场景自己的额外规则接着系统规则的编号往下排，编号不用手写死。
    rules = cfg.get("extra_rules") or []
    extra = "".join(f"{BUILTIN_RULE_COUNT + index + 1}. {rule}\n"
                    for index, rule in enumerate(rules))
    person = cfg.get("person") or DEFAULT_NARRATION["person"]
    tense = cfg.get("tense") or DEFAULT_NARRATION["tense"]
    if pov_name:
        pov_line = POV_LINE_FOLLOW.format(person=person, pov_name=pov_name, tense=tense)
    else:
        pov_line = POV_LINE_SCENE.format(person=person, tense=tense)
    return SYSTEM_TEMPLATE.format(
        paragraphs=cfg.get("paragraphs") or DEFAULT_NARRATION["paragraphs"],
        tone=cfg.get("tone") or DEFAULT_NARRATION["tone"],
        pov_line=pov_line,
        extra=extra)


# --------------------------------------------------------------------- 读取


def _has_table(conn, name: str) -> bool:
    row = conn.execute("SELECT name FROM sqlite_master WHERE type='table' AND name=?",
                       (name,)).fetchone()
    return row is not None


def read_world(conn) -> dict:
    """读出叙述需要的那部分世界：场景快照、当前刻、人物与地点。

    run 里带上 last_error：阅读页要能把「推进失败」和「本段文字尚未生成」分开说清楚。
    """
    scenario = scenario_mod.read_scenario(conn)
    run = conn.execute("SELECT tick, status, world_revision, last_error FROM run"
                       " WHERE run_id=1").fetchone()
    characters = {row["id"]: dict(row)
                  for row in conn.execute("SELECT * FROM character ORDER BY id")}
    locations = {row["id"]: dict(row)
                 for row in conn.execute("SELECT * FROM location ORDER BY id")}
    return {"scenario": scenario, "run": dict(run) if run is not None else {},
            "characters": characters, "locations": locations}


def load_events(conn, tick: int) -> list[dict]:
    rows = conn.execute(
        "SELECT event_id, tick, seq, kind, actor_id, target_id, location_id, text, success,"
        " reason, witnesses, external_event_id FROM event WHERE tick=? ORDER BY seq, event_id",
        (tick,))
    events = []
    for row in rows:
        item = dict(row)
        item["witnesses"] = json.loads(item["witnesses"] or "[]")
        item["success"] = bool(item["success"])
        events.append(item)
    return events


def scene_log(events: list[dict], characters: dict) -> list[str]:
    """本刻事实日志：一条事件一行，按结算顺序。这是叙述的唯一事实来源。

    写法上刻意「像人话」：不加 `[行动]` 这类标签，也不附「在场的人」名单——
    事件里的感知者常常分布在不同地点，合并成一张统一名单会让叙述误以为大家在一起。
    「谁在哪」由 `present_by_place()` 按地点分开给，不在这里混着说。

    每一刻的每一条事件都要留在这里：文字看起来重复也不合并、不删。
    """
    lines = []
    for ev in events:
        line = str(ev["text"]).strip()
        if not ev["success"]:
            reason = str(ev.get("reason") or "").strip()
            line += f"原因：{reason}。" if reason else "这件事没有成立。"
        if ev["kind"] == "external":
            line += "（这是外部发生的事，不是在场人物做的）"
        lines.append(line)
    return lines


def present_by_place(world: dict, events: list[dict]) -> list[dict]:
    """按地点分别列出「此刻谁在这里」。

    绝不把不同地点的人并成一张统一的在场名单：本刻涉及哪几个地点就分开列哪几组，
    移动之后的位置以本刻结束时为准（与事件里写的动向一致）。

    注意：这个函数读的是 character 表里的**当前**位置，只对「最新一刻」成立。
    补写更早的刻时不要调用它（见 dynamic_state_is_known）。
    """
    out, seen = [], set()
    for ev in events:
        location_id = ev.get("location_id")
        if not location_id or location_id in seen:
            continue
        location = world["locations"].get(location_id)
        if location is None:
            continue
        seen.add(location_id)
        people = sorted(ch["name"] for ch in world["characters"].values()
                        if ch["location_id"] == location_id)
        if people:
            out.append({"place": location["name"], "people": people})
    return out


def dynamic_state_is_known(world: dict, tick: int) -> bool:
    """这一刻的「动态状态」能不能当真用。

    动态状态 = 谁在哪（角色位置）、角色的状态与当前倾向、地点的现场描述与时刻。
    库里 `character` / `location` 两表只保存**最新**的一份，所以它们只在
    「正在写的就是最新一刻」时等于那一刻结束时的样子：

    - 正常推进：先提交第 N 刻，再写第 N 刻 → 表里的状态就是第 N 刻末的状态 ✓
    - 补写历史：世界已经到第 8 刻，回头补第 1 刻 → 表里是第 8 刻的状态 ✗

    历史段落一律不带这些字段：没有可靠记录就省略，绝不拿后来的状态冒充当时的状态。
    这不是要建历史回放系统，只是**不乱用现在**。
    """
    current = (world.get("run") or {}).get("tick")
    return current is not None and int(current) == int(tick)


HISTORICAL_STATE_NOTE = ("这一段是回头补写的历史情节：当时谁在哪、状态如何、现场环境是什么样，"
                         "都没有可靠记录。不要写这些，也不要用后来才知道的状态代替；"
                         "只写这一段时间里确实发生的事。")


def pick_pov(events: list[dict], characters: dict, preferred=None):
    """选本段的视角人物：按本刻被卷入的程度挑，不额外调用模型。

    行动者权重高于旁观者；同分时取 id 靠前的，保证同样的输入给出同样的结果。
    """
    if preferred and preferred in characters:
        return preferred
    score: dict[str, int] = {}
    for ev in events:
        actor_id = ev["actor_id"]
        if actor_id in characters:
            score[actor_id] = score.get(actor_id, 0) + 2
        for witness in ev["witnesses"]:
            if witness in characters:
                score[witness] = score.get(witness, 0) + 1
    if not score:
        return sorted(characters)[0] if characters else None
    return sorted(score.items(), key=lambda item: (-item[1], item[0]))[0][0]


def digest_text(events: list[dict], limit: int = 180) -> str:
    """事实提要：给下一段做衔接用，直接来自已结算事实，不额外调用模型。"""
    text = "；".join(ev["text"] for ev in events)
    if len(text) > limit:
        text = text[:limit].rstrip("；，,。 ") + "……"
    return text


def prose_tail(prose: str, chars: int) -> str:
    """取上一段正文的尾段（按空行切段，取最后一段）。"""
    if not prose:
        return ""
    blocks = [block.strip() for block in prose.replace("\r\n", "\n").split("\n\n")]
    blocks = [block for block in blocks if block]
    tail = blocks[-1] if blocks else prose.strip()
    return tail[-chars:] if chars and len(tail) > chars else tail


def places_of(events: list[dict], locations: dict) -> list[dict]:
    """本刻涉及的地点（按出现顺序去重）。"""
    out, seen = [], set()
    for ev in events:
        location_id = ev.get("location_id")
        if not location_id or location_id in seen:
            continue
        location = locations.get(location_id)
        if location is None:
            continue
        seen.add(location_id)
        out.append({"name": location["name"], "state_description": location["state_description"],
                    "moment": location["moment"]})
    return out


# --------------------------------------------------------------------- 组装


def places_basic(events: list[dict], locations: dict) -> list[dict]:
    """只取地点名与静态描述（不含现场状态、不含这一刻的时刻）。

    补写历史情节时用这个：地点名与设定不会随时间变，现场状态会。
    """
    out, seen = [], set()
    for ev in events:
        location_id = ev.get("location_id")
        if not location_id or location_id in seen:
            continue
        location = locations.get(location_id)
        if location is None:
            continue
        seen.add(location_id)
        out.append({"name": location["name"], "description": location["description"]})
    return out


def build_payload(world: dict, events: list[dict], pov_id: str | None, cfg: dict,
                  previous: dict | None, state_known: bool = True,
                  turn: dict | None = None) -> dict:
    """叙述输入。只装事实与已写出的正文，不装任何「还没发生的事」。

    state_known=False 表示写的是历史情节：此时**不提供任何随世界变化的状态**
    （角色位置、角色状态、当前倾向、地点现场描述与时刻），只给
    「这一刻的事件 + 不变的静态设定（世界、人物、地点的名称与描述）」。
    上一段正文只作语言衔接（提示词里另有交代），不参与状态判断。

    turn 是**目标刻自己**的世界回合记录（src/story.py）：只取该刻那一行，因此
    补写历史时拿到的是当时的局面，不是现在的。它作为 `focus` 进载荷，只用来安排
    篇幅轻重；事实仍以 scene_log 为准（见 story.FOCUS_RULE）。
    """
    scenario = world["scenario"]
    characters = world["characters"]
    pov = characters.get(pov_id) if pov_id else None

    pov_view = None
    if pov is not None:
        pov_view = {"name": pov["name"], "description": pov["description"]}
        if state_known:
            pov_view["status_text"] = pov["status_text"]
            pov_view["current_tendency"] = pov["current_tendency"]

    characters_view = []
    for ch in characters.values():
        item = {"name": ch["name"], "description": ch["description"]}
        if state_known:
            item["location_name"] = world["locations"].get(ch["location_id"], {}).get("name", "")
        characters_view.append(item)

    scene: dict = {"tick_label": f"第 {events[0]['tick']} 刻" if events else ""}
    if state_known:
        scene["places"] = places_of(events, world["locations"])
        # 按地点分开的「谁在哪里」；不要把它读成一张统一的在场名单。
        scene["present_by_place"] = present_by_place(world, events)
    else:
        scene["places"] = places_basic(events, world["locations"])
        scene["state_at_the_time"] = HISTORICAL_STATE_NOTE

    payload = {
        "world": {
            "title": scenario.get("title", ""),
            "summary": scenario.get("summary", ""),
            "description": (scenario.get("world") or {}).get("description", ""),
        },
        "scene": scene,
        "pov": pov_view,
        "characters": characters_view,
        "previous": previous or None,
        "scene_log": scene_log(events, characters),
        "fact_digest": digest_text(events, int(cfg.get("digest_chars") or 180)),
    }
    # 详略与用语约定也进载荷：事后能看出这一段是按哪种要求写的。
    if cfg.get("prose_style"):
        payload["prose_style"] = cfg["prose_style"]
    conventions = [str(item) for item in (cfg.get("conventions") or []) if str(item).strip()]
    if conventions:
        payload["conventions"] = conventions
    focus = story_mod.focus_for_narration(turn, world)
    if focus:
        payload["focus"] = focus
    if not state_known:
        payload["historical"] = True
    return payload


def build_user(payload: dict) -> str:
    return ("这是本段的输入（json）。请只输出这一段正文：\n"
            + json.dumps(payload, ensure_ascii=False))


def previous_context(conn, tick: int, cfg: dict) -> dict | None:
    """衔接的唯一来源：上一段已经写出来的正文尾段 + 上一段的事实提要。

    两样都是**已经发生**的东西（前者是已存正文，后者取自已结算事件）。
    """
    row = conn.execute(
        "SELECT tick, prose, digest FROM prose_segment WHERE tick<? AND status='committed'"
        " ORDER BY tick DESC LIMIT 1", (tick,)).fetchone()
    if row is None:
        return None
    return {"tick": row["tick"],
            "tail": prose_tail(row["prose"], int(cfg.get("prev_tail_chars") or 320)),
            "digest": row["digest"]}


# 明确不把「还没生效的外部事件」交给叙述（曾用 open_threads 字段传过，已撤掉）：
# 那是下一步开始时才生效的事，此刻还不是世界事实；交给模型写正文，等于让正文提前
# 把没发生的事写出来，也会让读者以为它已经发生。待生效的外部事件仍然在阅读页上
# 单独显示（/api/reading 的 pending_external，页面提示「下一步生效」），那是给读者的
# 队列状态，不参与写正文。


# --------------------------------------------------------------------- 段落存取


def segment_view(row) -> dict:
    item = dict(row)
    item["prose"] = item.get("prose") or ""
    item["has_prose"] = bool(item["prose"].strip())
    return item


def _claim(conn, tick: int, events: list[dict], request_id: str | None,
           force: bool, stale_ms: int = GENERATING_STALE_MS, owner_id: str | None = None) -> bool:
    """抢占「这一段正在生成」。同一段不会被两次点击同时生成（白花一次调用）。"""
    stamp = db.now()
    now_ms = db.now_ms()
    first_id = events[0]["event_id"] if events else None
    last_id = events[-1]["event_id"] if events else None
    with db.write_txn(conn):
        if not _has_column(conn, "prose_segment", "owner_id"):
            conn.execute("ALTER TABLE prose_segment ADD COLUMN owner_id TEXT")
        row = conn.execute("SELECT status, heartbeat_ms FROM prose_segment WHERE tick=?",
                           (tick,)).fetchone()
        if row is None:
            conn.execute(
                "INSERT INTO prose_segment(tick, status, from_event_id, to_event_id,"
                " request_id, owner_id, heartbeat_ms, created_at, updated_at)"
                " VALUES(?,?,?,?,?,?,?,?,?)",
                (tick, "generating", first_id, last_id, request_id, owner_id, now_ms, stamp, stamp))
            return True
        if row["status"] == "committed" and not force:
            return False
        if row["status"] == "generating":
            heartbeat = row["heartbeat_ms"]
            if heartbeat is not None and heartbeat > now_ms - stale_ms:
                return False
        conn.execute(
            "UPDATE prose_segment SET status='generating', heartbeat_ms=?, request_id=?, owner_id=?,"
            " from_event_id=?, to_event_id=?, updated_at=? WHERE tick=?",
            (now_ms, request_id, owner_id, first_id, last_id, stamp, tick))
        return True


def _finish(conn, tick: int, status: str, prose: str, digest: str,
            pov_id: str | None, error: str | None = None,
            style: str | None = None, owner_id: str | None = None) -> None:
    """落库这一段的结果。style 记下写它时用的详略，便于回看「哪段是简洁」。

    没有 prose_style 列的老档（还没在启动时迁移过）就不写这一列：宁可少记元数据，
    也不能让正文因为一个附加字段写不进去。
    """
    has_style = _has_column(conn, "prose_segment", "prose_style")
    with db.write_txn(conn):
        if has_style:
            cur = conn.execute(
                "UPDATE prose_segment SET status=?, prose=?, digest=?, pov_actor_id=?, error=?,"
                " prose_style=?, heartbeat_ms=NULL, updated_at=? WHERE tick=? AND owner_id IS ? AND status='generating'",
                (status, prose, digest, pov_id, error, style, db.now(), tick, owner_id))
        else:
            cur = conn.execute(
                "UPDATE prose_segment SET status=?, prose=?, digest=?, pov_actor_id=?, error=?,"
                " heartbeat_ms=NULL, updated_at=? WHERE tick=? AND owner_id IS ? AND status='generating'",
                (status, prose, digest, pov_id, error, db.now(), tick, owner_id))
        if cur.rowcount != 1:
            raise EngineError("正文生成所有权已变化，迟到结果没有覆盖已保存正文")


def get_segment(conn, tick: int):
    return conn.execute("SELECT * FROM prose_segment WHERE tick=?", (tick,)).fetchone()


def list_segments(db_path: str, ticks: list[int] | None = None) -> list[dict]:
    conn = db.connect(db_path)
    try:
        if not _has_table(conn, "prose_segment"):
            return []
        if ticks:
            marks = ",".join("?" for _ in ticks)
            rows = conn.execute(
                f"SELECT * FROM prose_segment WHERE tick IN ({marks}) ORDER BY tick", ticks)
        else:
            rows = conn.execute("SELECT * FROM prose_segment ORDER BY tick")
        return [segment_view(row) for row in rows]
    finally:
        conn.close()


def committed_ticks(conn) -> list[int]:
    return [row["tick"] for row in conn.execute(
        "SELECT DISTINCT tick FROM event ORDER BY tick")]


def missing_ticks(conn) -> list[int]:
    """已经推进过、但还没有成稿正文的刻。"""
    done = {row["tick"] for row in conn.execute(
        "SELECT tick FROM prose_segment WHERE status='committed'")}
    from . import chapter_store
    cutover = (chapter_store.state_row(conn)["cutover_tick"]
               if chapter_store.enabled(conn) else None)
    return [tick for tick in committed_ticks(conn)
            if tick not in done and (cutover is None or tick <= cutover)]


def failed_segments(conn) -> list[dict]:
    return [segment_view(row) for row in conn.execute(
        "SELECT * FROM prose_segment WHERE status='failed' ORDER BY tick")]


# --------------------------------------------------------------------- 生成


def narrate_tick(db_path: str, provider, tick: int, force: bool = False,
                 request_id: str | None = None, on_chunk=None) -> tuple[dict, dict]:
    """生成第 tick 刻的正文。

    世界状态在这里完全不改：只读事件、调一次叙述、写回正文。世界推进已经提交、
    正文生成失败时再打一次这个入口，就是「只补这一段」。
    返回 (段落, 本次 provider 记账)。
    """
    conn = db.connect(db_path)
    try:
        from . import chapter_store
        if chapter_store.enabled(conn) and tick > chapter_store.state_row(conn)["cutover_tick"]:
            raise EngineError("章节内部演绎不能逐刻补写；请从当前阅读节点继续完整章节")
        if not _has_table(conn, "prose_segment"):
            raise EngineError(
                "这个存档里还没有正文表。请用 Open-OC-World.cmd 重新打开一次程序"
                "（启动时会自动补建，旧数据不受影响）。")
        row = get_segment(conn, tick)
        if row is not None and row["status"] == "committed" and not force:
            return segment_view(row), {}

        events = load_events(conn, tick)
        if not events:
            raise EngineError(f"第 {tick} 刻没有已结算事件，没有可写的正文。")

        world = read_world(conn)
        # 详略在该段开始时读定：生成途中改选择，不影响正在写的这一段，下一段才用新值。
        style = prose_style(conn)
        cfg = narration_config(world["scenario"], style)
        # 视角：auto = 按本刻卷入程度挑一个人；scene = 全局观察（不挑人，也不进内心）；
        # 其他写法按固定角色 id 处理（未知 id 会退回 auto，不会静默变成错误的人）。
        pov_mode = cfg.get("pov")
        if pov_mode == "scene":
            pov_id = None
        elif not pov_mode or pov_mode == "auto":
            pov_id = pick_pov(events, world["characters"], None)
        else:
            pov_id = pick_pov(events, world["characters"], pov_mode)
        pov_name = world["characters"].get(pov_id, {}).get("name") if pov_id else ""
        # 时间边界：只有正在写最新一刻时，人物位置/状态/倾向与地点现场才是「当时的」。
        # 补写更早的刻时这些一律不给（见 dynamic_state_is_known）。
        state_known = dynamic_state_is_known(world, tick)
        # 局面焦点只取**目标刻自己**那条记录，而且要这一档真的开着 focus_hint：
        # 没有记录或没开就照原路径走，补写历史绝不拿现在的局面。
        turn = story_mod.load_turn(conn, tick)
        if turn is not None and story_mod.loop_config(world["scenario"]).get("focus_hint"):
            cfg["extra_rules"] = list(cfg.get("extra_rules") or []) + [story_mod.FOCUS_RULE]
        else:
            turn = None
        payload = build_payload(world, events, pov_id, cfg,
                                previous_context(conn, tick, cfg), state_known, turn)

        timeout = getattr(provider, "config", {}).get("total_timeout_s", 0)
        try:
            stale_ms = max(GENERATING_STALE_MS, int(float(timeout) * 1000) + 30_000)
        except (TypeError, ValueError):
            stale_ms = GENERATING_STALE_MS
        import uuid
        owner_id = uuid.uuid4().hex
        if not _claim(conn, tick, events, request_id, force, stale_ms, owner_id):
            raise EngineError(f"第 {tick} 刻的正文正在生成中，请稍候。")
        digest = payload["fact_digest"]
        try:
            request = {
                "system": build_narration_system(cfg, pov_name),
                "user": build_user(payload),
                "tick": tick,
                "pov_actor_id": pov_id,
                "payload": payload,
            }
            # Only the explicit streaming route uses a streaming provider call.
            # Old callers retain the full-response path and saved-text semantics.
            if on_chunk is not None and callable(getattr(provider, "narrate_stream", None)):
                prose = provider.narrate_stream(request, on_chunk)
            else:
                prose = provider.narrate(request)
                if on_chunk is not None:
                    on_chunk(prose)
        except ProviderError as exc:
            _finish(conn, tick, "failed", "", digest, pov_id,
                    scrub_secrets(str(exc)), style, owner_id)
            raise
        if not isinstance(prose, str) or not prose.strip():
            message = "正文叙述返回了空内容"
            _finish(conn, tick, "failed", "", digest, pov_id, message, style, owner_id)
            raise ProviderSchemaError(f"[{stage_label('narrate')}（第 {tick} 刻）] {message}")
        stats = provider.take_stats()
        _finish(conn, tick, "committed", prose.strip(), digest, pov_id, None, style, owner_id)
        return segment_view(get_segment(conn, tick)), stats
    finally:
        conn.close()


def narrate_missing(db_path: str, provider, limit: int = 6) -> dict:
    """把「已推进但没有正文」的刻逐段补上；每段独立成败，不重复推进世界。"""
    conn = db.connect(db_path)
    try:
        ticks = missing_ticks(conn)
    finally:
        conn.close()
    done, failures = [], []
    stats_taken = {}
    for tick in ticks[:max(1, int(limit))]:
        try:
            segment, stats = narrate_tick(db_path, provider, tick)
            done.append(segment)
            stats_taken = stats
        except (ProviderError, EngineError) as exc:
            failures.append({"tick": tick, "error": scrub_secrets(str(exc))})
            stats_taken = provider.take_stats()
            break            # 目的地是「补写」不是「重试」：一次失败就停手，交用户决定
    return {"segments": done, "failures": failures, "accounting": stats_taken,
            "remaining": max(0, len(ticks) - len(done) - len(failures))}


# --------------------------------------------------------------------- 阅读视图


def tick_places(conn) -> dict[int, list[str]]:
    """每一刻涉及的地名，用来在正文上方标出「故事内时间 + 地点」。"""
    out: dict[int, list[str]] = {}
    for row in conn.execute(
            "SELECT tick, location_id, MIN(seq) AS first_seq FROM event"
            " WHERE location_id IS NOT NULL GROUP BY tick, location_id"
            " ORDER BY tick, first_seq"):
        out.setdefault(row["tick"], []).append(row["location_id"])
    return out


def reading_view(db_path: str, provider) -> dict:
    from .demo import batch_limit, demo_state, if_help
    from .engine import provider_view
    from .intervention import hints
    from .provider import FAKE_PROSE_BANNER
    conn = db.connect(db_path)
    try:
        from . import chapter_store, chapter_view
        if chapter_store.enabled(conn):
            return chapter_view.reading_view(conn, db_path, provider)
        world = read_world(conn)
        segments = [] if not _has_table(conn, "prose_segment") else [
            segment_view(row) for row in conn.execute("SELECT * FROM prose_segment ORDER BY tick")]
        characters = world["characters"]
        places = tick_places(conn)
        for segment in segments:
            names = [world["locations"][lid]["name"] for lid in places.get(segment["tick"], [])
                     if lid in world["locations"]]
            segment["place_names"] = names
        mode = getattr(provider, "mode", "unknown")
        scenario = world["scenario"]
        sources = scenario.get("sources") or []
        return {
            "mode": mode,
            "provider": provider_view(provider),
            # 模拟标注只在这里给一次，页面统一展示；段落文字里不再重复声明。
            "prose_banner": FAKE_PROSE_BANNER if mode == "fake" else None,
            # 演示层：开演信息（真正载入的包与来源）、IF 说明与批次上限。
            "pack": {
                "scenario_id": scenario.get("scenario_id", ""),
                "version": scenario.get("version", ""),
                "title": scenario.get("title", ""),
                "summary": scenario.get("summary", ""),
                "world_description": (scenario.get("world") or {}).get("description", ""),
                "source_entries": len(sources),
                "source_docs": sorted({item.get("doc", "") for item in sources if item.get("doc")}),
                "overlay_used": (scenario.get("demo") or {}).get("overlay_used", ""),
            },
            "if_options": if_help(scenario),
            "limits": {"max_batch_ticks": batch_limit(scenario)},
            # 正文详略：当前值 + 两个可选值（页面据此渲染紧凑选择器）
            "prose_styles": [{"value": value, "label": STYLE_LABELS[value]}
                             for value in PROSE_STYLES],
            "world": {
                "title": world["scenario"].get("title", ""),
                "summary": world["scenario"].get("summary", ""),
                "description": (world["scenario"].get("world") or {}).get("description", ""),
                "moment": (world["scenario"].get("world") or {}).get("initial_moment", ""),
            },
            "run": {**world["run"], **demo_state(db_path),
                    "prose_style": prose_style(conn)},
            "characters": [
                {"id": ch["id"], "name": ch["name"], "description": ch["description"],
                 "status_text": ch["status_text"],
                 "location_name": world["locations"].get(ch["location_id"], {}).get("name", "")}
                for ch in characters.values()],
            "places": [
                {"id": loc["id"], "name": loc["name"], "description": loc["description"],
                 "moment": loc["moment"], "state_description": loc["state_description"]}
                for loc in world["locations"].values()],
            "segments": segments,
            "tick_places": {str(tick): [world["locations"][lid]["name"] for lid in ids
                                        if lid in world["locations"]]
                            for tick, ids in places.items()},
            "missing_ticks": (missing_ticks(conn) if _has_table(conn, "prose_segment") else []),
            "failed_segments": (failed_segments(conn) if _has_table(conn, "prose_segment") else []),
            "pending_external": [
                {"event_id": row["event_id"], "preset_key": row["preset_key"],
                 "scope": row["scope"], "description": row["description"],
                 "created_tick": row["created_tick"]}
                for row in conn.execute(
                    "SELECT * FROM external_event WHERE status='pending' ORDER BY event_id")],
            "hints": hints(world["scenario"]),
            "intervention_note": ("输入会被理解成当前场景里的一件外部事件：范围只能是全场、"
                                  "某个地点或某个人；不能新增人物，也不能改写已经发生的事。"),
        }
    finally:
        conn.close()


def _run_status(db_path: str) -> str:
    conn = db.connect(db_path)
    try:
        row = conn.execute("SELECT status FROM run WHERE run_id=1").fetchone()
        return row["status"] if row is not None else ""
    finally:
        conn.close()


def continue_reading(db_path: str, provider, runner, request_id: str,
                     force_narrate: bool = False, on_advanced=None,
                     on_chunk=None) -> dict:
    """「继续」按钮的完整动作。

    先看有没有「世界已经推进、正文还没生成」的刻：有就只补那一段正文，**不推进世界**。
    全部成稿之后才推进一刻，再为新的一刻生成正文。两段结果分开返回，
    页面才能分别说明「推进失败」和「本段文字尚未生成」。
    """
    from . import chapter_store, chapters
    conn = db.connect(db_path)
    try:
        chapter_mode = chapter_store.enabled(conn)
        use_chapters = chapter_mode and not missing_ticks(conn)
    finally:
        conn.close()
    if use_chapters:
        return chapters.continue_chapter(db_path, provider, request_id, on_advanced, on_chunk)
    if chapter_mode:
        force_narrate = False
    started = time.perf_counter()
    result = {"action": None, "advanced": None, "prose": None, "recovered": None,
              "accounting": None, "advance_accounting": None, "timing": {}}

    def delta(text):
        if not text:
            return
        result["timing"].setdefault("first_prose_ms", round(
            (time.perf_counter() - started) * 1000, 3))
        if on_chunk is not None:
            on_chunk(text)

    def finish():
        result["timing"]["complete_ms"] = round(
            (time.perf_counter() - started) * 1000, 3)
        return result

    ended = _run_status(db_path) == "ended"
    if ended:
        # 已结束的故事：不再推进，也不再自动补写（正文可以单独补写，但故事本身冻结）
        result["action"] = "ended"
        result["message"] = "这次故事已经结束，不再推进；可以继续阅读，要换条件请新开一个存档。"
        return finish()
    if not force_narrate:
        conn = db.connect(db_path)
        try:
            pending = missing_ticks(conn) if _has_table(conn, "prose_segment") else []
        finally:
            conn.close()
        if pending:
            tick = pending[0]
            try:
                segment, stats = narrate_tick(db_path, provider, tick,
                                               on_chunk=delta if on_chunk else None)
                result["action"] = "recovered"
                result["recovered"] = segment
                result["accounting"] = stats
            except (ProviderError, EngineError) as exc:
                result["action"] = "recovered_failed"
                result["prose"] = {"ok": False, "tick": tick,
                                   "error": scrub_secrets(str(exc)), "kind": "recovered"}
                result["accounting"] = provider.take_stats()
            return finish()

    try:
        report = runner.step(request_id)
    except (ProviderError, EngineError) as exc:
        result["action"] = "advance_failed"
        result["advanced"] = {"ok": False, "error": scrub_secrets(str(exc)),
                              "error_type": getattr(exc, "error_type", type(exc).__name__),
                              "request_id": request_id}
        result["accounting"] = provider.take_stats()
        return finish()

    tick = report["tick"]
    result["advance_accounting"] = report.get("accounting")
    result["timing"]["world_committed_ms"] = round(
        (time.perf_counter() - started) * 1000, 3)
    result["action"] = "advanced"
    result["advanced"] = {"ok": True, "tick": tick, "request_id": request_id,
                          "events": len(report.get("events", [])),
                          "deduped": bool(report.get("deduped")),
                          "display_text": report.get("display_text", "")}
    if on_advanced is not None:
        on_advanced(result["advanced"], result["advance_accounting"])
    try:
        segment, stats = narrate_tick(db_path, provider, tick, request_id=request_id,
                                      on_chunk=delta if on_chunk else None)
        result["prose"] = {"ok": True, "segment": segment}
        result["accounting"] = stats
    except (ProviderError, EngineError) as exc:
        result["action"] = "advance_prose_failed"
        result["prose"] = {"ok": False, "tick": tick, "error": scrub_secrets(str(exc)),
                           "kind": "new"}
        result["accounting"] = provider.take_stats()
    return finish()


__all__ = ["DEFAULT_NARRATION", "GENERATING_STALE_MS", "narration_config",
           "build_narration_system", "build_payload", "build_user", "scene_log",
           "pick_pov", "digest_text", "prose_tail", "read_world", "load_events",
           "list_segments", "missing_ticks", "narrate_tick", "narrate_missing",
           "reading_view", "continue_reading", "segment_view", "get_segment"]
