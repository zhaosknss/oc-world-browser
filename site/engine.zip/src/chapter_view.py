"""Reader projection. No live world/actor state or speculative prose is returned."""
from __future__ import annotations

import json

from . import chapter_store as store, db, scenario as scenario_mod


def last_failure(conn, checkpoint, run):
    row = conn.execute("SELECT * FROM chapter_request WHERE status='failed' AND tick=? AND updated_at>=? "
                       "ORDER BY updated_at DESC,rowid DESC LIMIT 1",
                       (run["tick"], checkpoint["updated_at"])).fetchone()
    if row is None:
        return None
    public = {}
    try:
        result = json.loads(row["result"] or "{}")
        if isinstance(result, dict) and isinstance(result.get("advanced"), dict):
            public = result["advanced"]
    except (ValueError, TypeError):
        pass
    if public.get("revision", checkpoint["revision"]) != checkpoint["revision"]:
        return None
    category = public.get("failure_category")
    stage = public.get("failure_stage")
    if not isinstance(category, str) or category not in store.FAILURE_CATEGORIES:
        # Legacy failures have no safe projection. Match only known error classes,
        # never return the private director/editor response or error-log message.
        error = conn.execute("SELECT message FROM error_log WHERE request_id=? ORDER BY error_id DESC LIMIT 1",
                             (row["request_id"],)).fetchone()
        message = error["message"] if error is not None else ""
        category = ("round_limit" if "超过演绎保护轮数" in message else
                    "scene_limit" if "超过场景保护上限" in message else "engine")
        stage = "director_review" if category in ("round_limit", "scene_limit") else "simulation"
    if not isinstance(stage, str) or stage not in store.FAILURE_STAGES:
        stage = "simulation"
    params = (checkpoint["revision"], checkpoint["cursor"] + 1)
    mode = "restart"
    if conn.execute("SELECT 1 FROM chapter WHERE revision=? AND number=? AND status='draft'", params).fetchone():
        mode = "writing"
    elif conn.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='chapter_work'").fetchone():
        if conn.execute("SELECT 1 FROM chapter_work WHERE revision=? AND number=?", params).fetchone():
            mode = "simulation"
    return {"failure_category": category, "failure_stage": stage, "recovery_mode": mode,
            "recovery_available": mode != "restart", "error": store.failure_message(category, stage, mode)}


def reading_view(conn, db_path, provider) -> dict:
    from .demo import demo_state, if_help
    from .engine import provider_view
    from .narrate import failed_segments, missing_ticks, segment_view
    from .provider import FAKE_PROSE_BANNER
    scenario = scenario_mod.read_scenario(conn)
    checkpoint = store.state_row(conn)
    run = dict(conn.execute("SELECT * FROM run WHERE run_id=1").fetchone())
    published = list(conn.execute("SELECT * FROM chapter WHERE status='published' ORDER BY number"))
    segments = [segment_view(row) for row in conn.execute(
        "SELECT * FROM prose_segment WHERE tick<=? ORDER BY tick", (checkpoint["cutover_tick"],))]
    segments += [store.segment(row) for row in published]
    known_places = {}
    for row in published:
        for scene in json.loads(row["projection"])["scenes"]:
            known_places[scene["place"]["id"]] = scene["place"]
    world = scenario.get("world", {})
    public = world.get("public_description", scenario.get("summary", ""))
    mode = getattr(provider, "mode", "unknown")
    prepared = conn.execute("SELECT COUNT(*) n FROM chapter WHERE status='prepared' AND revision=? AND number>?",
                           (checkpoint["revision"], checkpoint["cursor"])).fetchone()["n"]
    help_options = if_help(scenario)
    help_options["locations"] = [{"id": place["id"], "name": place["name"]} for place in known_places.values()]
    help_options["resources"] = []
    return {"engine_mode": "chapters", "mode": mode, "provider": provider_view(provider),
        "prose_banner": FAKE_PROSE_BANNER if mode == "fake" else None,
        "pack": {"scenario_id": scenario["scenario_id"], "version": scenario["version"],
                 "title": scenario.get("title", ""), "summary": scenario.get("summary", ""),
                 "world_description": public, "source_entries": len(scenario.get("sources") or []),
                 "source_docs": [], "overlay_used": ""},
        "world": {"title": scenario.get("title", ""), "summary": scenario.get("summary", ""),
                  "description": public, "moment": world.get("initial_moment", "")},
        "run": {"tick": run["tick"], "status": run["status"], **demo_state(db_path),
                "chapter_number": checkpoint["cursor"], "prepared_count": prepared,
                "at_checkpoint": True, "prose_style": "normal"},
        "if_options": help_options, "limits": {"max_batch_ticks": 1},
        "prose_styles": [],
        "characters": [{"id": ch["id"], "name": ch["name"],
                        "description": ch.get("public_description", ""),
                        "status_text": "", "location_name": ""} for ch in scenario["characters"]],
        "places": [{"id": place["id"], "name": place["name"], "description": place["description"],
                    "moment": place["moment"], "state_description": ""}
                   for place in known_places.values()],
        "segments": segments, "last_failure": last_failure(conn, checkpoint, run),
        "tick_places": {str(seg["tick"]): seg.get("place_names", []) for seg in segments},
        "missing_ticks": missing_ticks(conn), "failed_segments": failed_segments(conn),
        "pending_external": [{"event_id": row["event_id"], "preset_key": row["preset_key"],
            "scope": row["scope"], "description": row["description"], "created_tick": row["created_tick"]}
            for row in conn.execute("SELECT * FROM external_event WHERE status='pending' ORDER BY event_id")],
        "hints": ["天气或现场条件发生变化", "有人接到一条尚未核实的消息"],
        "intervention_note": "从当前章节停顿处投入一件事；已读正文与已发生事实保留，未读后续会按新条件重新组织。"}
